/*
 * switch_demo.cpp
 *
 *  Created on: Jul 27, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int main () {
	string word;
	cout << "enter hello or bye: ";
	cin >> word;
	switch (word) {
		case "hello":
			cout << "hello hello" << endl;
			break;
		case "bye":
			cout << "bye bye";
			break;
		default:
			cout << "sorry. no option for " << word << endl;
	}
	return 0;
}



