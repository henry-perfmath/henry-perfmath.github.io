/*
 * op_overloading_1.cpp
 *
 *  Created on: Aug 17, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

class account {
	double balance;
	int num_access;
public:
	account (double balance=0, int num_access = 0) {
		this->balance =balance;
		this->num_access = num_access;
	}
	double get_balance () {return balance;}
	void set_balance (double balance) { this->balance = balance;}
	void show_account () {
		cout << "\nbalance: " << balance;
		cout << "\nnum_access: " << num_access << endl;
	}
	account operator+ (account accnt);
	account operator= (account accnt);
	account operator++ ();
	account operator++ (int dummy);
};
account account::operator+ (account accnt) {
	account temp;
	temp.balance = this->balance + accnt.balance;
	return temp;
}
account account::operator= (account accnt) {
	this->set_balance (accnt.balance);
	return *this;
}
account account::operator++ () { // prefix
	num_access++;
	return *this;
}
account account::operator++ (int dummy) { // postfix
	account tmp = *this;
	num_access++;
	return tmp;
}
int main () {
	account savings (500, 0), checking (200, 0), accnt0;
	savings.show_account ();
	checking.show_account ();

	account super_savings = ++savings;
	super_savings.show_account();

	account free_checking = checking++;
	free_checking.show_account ();
	return 0;
}



