/*
 * op_overloading_1.cpp
 *
 *  Created on: Aug 17, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

class account {
	double balance;
public:
	account (double balance=0) {
		this->balance =balance;
	}
	double get_balance () {return balance;}
	void set_balance (double balance) { this->balance = balance;}
	account operator+ (account accnt);
	account operator= (account accnt);
};
account account::operator+ (account accnt) {
	account temp;
	temp.balance = this->balance + accnt.balance;
	return temp;
}
account account::operator= (account accnt) {
	this->set_balance (accnt.balance);
	return *this;
}
int main () {
	account savings (500), checking (200), accnt0;
	cout <<"\nsavings balance: " << savings.get_balance();
	cout <<"\nchecking balance: " << savings.get_balance();
	accnt0 = savings + checking;
	cout <<"\ncombined balance: " << accnt0.get_balance();

	return 0;
}



