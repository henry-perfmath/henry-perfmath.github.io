/*
 * op_overloading_3.cpp
 *
 *  Created on: Aug 17, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

class account {
	double balance;
	int num_access;
public:
	account (double balance=0, int num_access = 0) {
		this->balance =balance;
		this->num_access = num_access;
	}
	double get_balance () {return balance;}
	void set_balance (double balance) { this->balance = balance;}
	void show_account () {
		cout << "\nbalance: " << balance;
		cout << "\nnum_access: " << num_access << endl;
	}
	friend account operator+ (account accnt1, account accnt2);
	account operator= (account accnt);
	friend account operator++ (account &op1);
	friend account operator++ (account &op1, int dummy);
};
account operator+ (account accnt1, account accnt2) {
	account temp;
	temp.balance = accnt1.balance + accnt2.balance;
	return temp;
}
account account::operator= (account accnt) {
	this->set_balance (accnt.balance);
	return *this;
}
account operator++ (account &op1) { // prefix
	op1.num_access++;
	return op1;
}
account operator++ (account &op1, int dummy) { // postfix
	account tmp = op1;
	op1.num_access++;
	return tmp;
}
int main () {
	account savings (500, 0), checking (200, 0), accnt0;
	savings.show_account ();
	checking.show_account ();

	account super_savings = ++savings;
	super_savings.show_account();

	account free_checking = checking++;
	free_checking.show_account ();
	return 0;
}



