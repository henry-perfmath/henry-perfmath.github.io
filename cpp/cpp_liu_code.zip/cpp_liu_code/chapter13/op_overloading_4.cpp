/*
 * op_overloading_4.cpp
 *
 *  Created on: Aug 17, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

class account {
	double balance;
	int num_access;
public:
	account (double balance=0, int num_access = 0) {
		this->balance =balance;
		this->num_access = num_access;
	}
	double get_balance () {return balance;}
	void set_balance (double balance) { this->balance = balance;}
	void show_account () {
		cout << "\nbalance: " << balance;
		cout << "\nnum_access: " << num_access << endl;
	}
	bool operator> (account accnt);
};

bool account::operator> (account accnt) {
	return (this->balance > accnt.balance);
}

int main () {
	account savings (500, 0), checking (200, 0);
	savings.show_account ();
	checking.show_account ();

	cout << "savings account has higher balance than checking account? "
			<< (savings > checking) << endl;
	return 0;
}



