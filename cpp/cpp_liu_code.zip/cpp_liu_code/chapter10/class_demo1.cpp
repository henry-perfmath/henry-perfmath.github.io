/*
 * class_demo1.cpp
 *
 *  Created on: Aug 10, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

class x {
	int i;
	char ch;
public:
	x ();		// constructor
	~x ();		// destructor
	int get_i ();
	char get_ch ();
	void set_i (int i);
	void set_ch (char ch);
};
x::x () {
	i = 0;
	ch = '\0';
	cout << "x has been initialized\n";
}
x::~x () {
	cout << "x has been destroyed\n";
}
int x::get_i () {
	return i;
}
char x::get_ch () {
	return ch;
}
void x::set_i (int k) {
	i = k;
}
void x::set_ch (char c) {
	ch = c;
}

int main () {
	x x0;
	x0.set_i (100);
	x0.set_ch ('a');
	cout << x0.get_i () << " " << x0.get_ch() << endl;
	return 0;
}
