/*
 * arrays_of_objects.cpp
 *
 *  Created on: Aug 10, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

class x {
	int i;
	char ch;
public:
	x (int k = 0, char c = 'x') {		// constructor
		set_i (k);
		set_ch (c);
		cout << "x has been initialized with i = " << i
			 << " and ch = " << ch << endl;
	}
	~x () {		// destructor
		cout << "x has been destroyed\n";
	}
	int get_i () {return i;}
	char get_ch () {return ch;}
	void set_i (int k) {i = k;}
	void set_ch (char c) {ch = c;}
};

int main () {
	x x_array [3] = {x (0, 'a'), x (1, 'b'), x (2, 'c')};
	for (int i = 0; i < 3; i++) {
		x_array [i].set_i (x_array [i].get_i () + i);
		x_array [i].set_ch (x_array [i].get_ch () + i);
	}
	for (int i = 0; i < 3; i++) {
		cout << "x_array[" << i << "]: " << x_array [i].get_i ()
			 << " " << x_array [i].get_ch() << endl;
	}
	return 0;
}
