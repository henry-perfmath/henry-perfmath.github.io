/*
 * this_pointer.cpp
 *
 *  Created on: Aug 10, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

class x {
	int i;
	char ch;
public:
	x (int i = 0, char ch = 'x') {		// constructor
		this->i =i;
		this->ch = ch;
		cout << "x has been initialized with i = " << this->i
			 << " and ch = " << this->ch << endl;
	}
	~x () {		// destructor
		cout << "x has been destroyed\n";
	}
	int get_i () {return i;}
	char get_ch () {return ch;}
	void set_i (int i) {this->i = i;}
	void set_ch (char ch) {this->ch = ch;}
};

int main () {
	x x0;
	x x1 (101, 'b');
	x x2 = x (102, 'c');
	x1.set_i (103);
	x1.set_ch ('d');
	cout << x0.get_i () << " " << x0.get_ch() << endl;
	cout << x1.get_i () << " " << x1.get_ch() << endl;
	cout << x2.get_i () << " " << x2.get_ch() << endl;
	return 0;
}
