/*
 * friend_demo.cpp
 *
 *  Created on: Aug 10, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

class x {
	int i;
	char ch;
public:
	x (int i = 0, char ch = 'x') {		// constructor
		this->i = i;
		this->ch = ch;
		cout << "x has been initialized with i = " << this->i
			 << " and ch = " << this->ch << endl;
	}
	~x () {		// destructor
		cout << "x has been destroyed\n";
	}
	int get_i () {return i;}
	char get_ch () {return ch;}
	void set_i (int k) {i = k;}
	void set_ch (char c) {ch = c;}
	friend void print_x (x obj_x);
};
void print_x (x obj_x) {
	cout << "obj_x: i = " << obj_x.i
		 << " ch = " << obj_x.ch<< endl;
}
int main () {
	x x0 (100, 'a');
	print_x (x0);
	return 0;
}
