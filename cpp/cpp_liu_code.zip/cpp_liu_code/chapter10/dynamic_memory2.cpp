/*
 * dynamic_memory2.cpp
 *
 *  Created on: Aug 11, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstring>
using namespace std;

struct istr {
	int i;
	char str [80];
};

class y {
	istr *p;
public:
	y (int i, char []);
	y (const y &y0);
	~y ();
	istr get_ich () {return *p;}
	int get_i () {return p->i;}
	char *get_str () {return p->str;}
};
y::y (int i, char s[]) {
	 cout << "calling constructor to allocate memory for p" << endl;
	 p = new istr;
	 p->i = i;
	 strcpy (p->str, s);
 }
y::y (const y &y0) {
	p = new istr;
	*p = *y0.p;
	cout << "copy constructor called" << endl;
}
y::~y () {
	cout << "calling destructor to delete p" << endl;
	delete p;
}
void print_y (y y0) {
	cout << y0.get_i () << " " << y0.get_str () << endl;
}
y make_y () {
	char s [80];
	y new_y (999, strcpy(s, "making a new y object"));
	return new_y;
}
int main () {
	char s0 [80];
	strcpy (s0, "This is a test");
	y y0 (100, s0);
	print_y (y0);

	cout << "\ninitializing an object with another ..." << endl;
	y y1 = y0;		// initialization
	print_y (y1);

	cout << "\ncalling a function that returns a y object ..." << endl;
	y y2 = make_y ();
	print_y (y2);

//	cout << "\nobject assignment ..." << endl;
//	y y3 (200, s0);
//	y1 = y3;  	// assignment
	return 0;
}
