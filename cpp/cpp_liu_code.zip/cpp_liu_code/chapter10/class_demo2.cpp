/*
 * class_demo1.cpp
 *
 *  Created on: Aug 10, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

class x {
	int i;
	char ch;
public:
	x ();
	x (int i, char ch);		// constructor
	~x ();		// destructor
	int get_i ();
	char get_ch ();
	void set_i (int i);
	void set_ch (char ch);
};

x::x () {
	i = 100;
	ch = 'a';
	cout << "x has been initialized with i = " << i
		 << " and ch = " << ch << endl;
}

//x::x (int i = 0, char ch = 'x') {
x::x (int i, char ch) {
	set_i (i);
	set_ch (ch);
	cout << "x has been initialized with i = " << i
		 << " and ch = " << ch << endl;
}
x::~x () {
	cout << "x has been destroyed\n";
}
int x::get_i () {
	return i;
}
char x::get_ch () {
	return ch;
}
void x::set_i (int k) {
	i = k;
}
void x::set_ch (char c) {
	ch = c;
}

int main () {
	x x0;
	x x1 (101, 'b');
	x x2 = x (102, 'c');
	x1.set_i (103);
	x1.set_ch ('d');
	cout << x0.get_i () << " " << x0.get_ch() << endl;
	cout << x1.get_i () << " " << x1.get_ch() << endl;
	cout << x2.get_i () << " " << x2.get_ch() << endl;
	return 0;
}
