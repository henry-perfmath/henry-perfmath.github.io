/*
 * exception_demo1.cpp
 *
 *  Created on: Aug 20, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib> // for calling exit
using namespace std;

int main() {
	int x = 10;
	int y;
	while (true) {
		cout << "Enter a non-zero number or zero: ";
		cin >> y;
		try {
			if (!y) throw y;
			cout << x << " / " << y << " = " << x / y << endl;
		} catch (int i) {
			cout << "Exception: divide by " << i;
			cout << ". Please re-enter a non-zero #" << endl;
			//exit(-1);
		}
	}
	return 0;
}



