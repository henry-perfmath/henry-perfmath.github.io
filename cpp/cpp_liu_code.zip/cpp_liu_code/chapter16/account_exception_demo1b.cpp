/*
 * account_exception_demo1b.cpp
 *
 *  Created on: Aug 29, 2013
 *      Author: henry
 */
#include<cstring>
#include<iostream>
#include<cstdlib>
using namespace std;

class account {
protected:
	double balance;
	int status;
	char exception [80];
public:
	double get_balance () {return balance;}
	int get_status () {return status;}
	void set_balance (double b) {
		balance = b;
		if (balance < 0) {
			set_exception ( "account balance cannot be negative\n");
			throw this;
		}
	}
	void set_status (int i) {
		status = i;
		if (status < 0) {
			set_exception ( "account status cannot be negative\n");
			throw this;
		}
	}
	char *get_exception () {return exception;}
	void set_exception (const char *s) {strcpy (exception, s);}
};
class savings_account : public account{
	double interest_rate;
public:
	double get_interest_rate () {return interest_rate;}
	void set_interest_rate (double rate) {interest_rate = rate;}
	friend ostream &operator<< (ostream &stream, savings_account savings);
	friend istream &operator>> (istream &stream, savings_account &savings);
};
ostream &operator<< (ostream &stream, savings_account savings) {
		stream << "status: " << savings.status;
		stream << "\nbalance: " << savings.balance;
		stream << "\ninterest rate: " << savings.interest_rate<< endl;
		return stream;
	}

istream &operator>>(istream &stream, savings_account &savings) {
	int status;
	double balance, interest_rate;
	cout << "Enter status, balance and interest_rate: ";
	stream >> status >> balance >> interest_rate;
	savings.set_status(status);
	savings.set_balance(balance);
	savings.interest_rate = interest_rate;
	if (interest_rate < 0) {
		savings.set_exception("account interest_rate cannot be negative\n");
		savings.interest_rate = 0.0;
		throw &savings;
	}
	return stream;
}

int main () {
	savings_account savings;
	savings.set_status (1);
	savings.set_balance (100.0);
	savings.set_interest_rate (0.001);
	cout << savings;

	try {
		cin >> savings;
	} catch (account *a) {
		cout << "caught from base: " << a->get_exception ();
	} catch (savings_account *sa) {
		cout << "caught from derived: " << sa->get_exception ();
	}

	/*
	try {
		cin >> savings;
	} catch (savings_account *sa) {
		cout << "caught from derived: " << sa->get_exception ();
	} catch (account *a) {
		cout << "caught from base: " << a->get_exception ();
	}
	*/
	cout << savings;
	return 0;
}

