/*
 * account_exception_demo0.cpp
 *
 *  Created on: Aug 29, 2013
 *      Author: henry
 */
#include<cstring>
#include<iostream>
#include<cstdlib>
using namespace std;

class AccountException {
public:
	char exception[80];
	AccountException () { *exception = 0;}
	AccountException (const char *s) {
		strcpy (exception, s);}
};

class account {
protected:
	double balance;
	int status;
public:
	double get_balance () {return balance;}
	int get_status () {return status;}
	void set_balance (double b) {balance = b;}
	void set_status (int i) {status = i;}
};
class savings_account : public account {
	double interest_rate;
public:
	double get_interest_rate () {return interest_rate;}
	void set_interest_rate (double rate) {interest_rate = rate;}
	friend ostream &operator<< (ostream &stream, savings_account savings);
	friend istream &operator>> (istream &stream, savings_account &savings);
};
ostream &operator<< (ostream &stream, savings_account savings) {
		stream << "status: " << savings.status;
		stream << "\nbalance: " << savings.balance;
		stream << "\ninterest rate: " << savings.interest_rate<< endl;
		return stream;
	}

istream &operator>> (istream &stream, savings_account &savings) {
	cout << "Enter status, balance and interest_rate: ";
	stream >> savings.status >> savings.balance >> savings.interest_rate;
	if (savings.status < 0) {
		throw AccountException ("account status cannot be negative\n");
	} else if (savings.balance < 0) {
		throw AccountException ("account balance cannot be negative\n");
	} else if (savings.interest_rate < 0) {
		throw AccountException ("account interest_rate cannot be negative\n");
	}
	return stream;
}

int main () {
	savings_account savings;
	savings.set_status (1);
	savings.set_balance (100.0);
	savings.set_interest_rate (0.001);
	cout << savings;
	try {
		cin >> savings;
	} catch (AccountException &ae) {
		cout << ae.exception;
		exit (-1);
	}
	cout << savings;
	return 0;
}

