/*
 * exception_demo3.cpp
 *
 *  Created on: Aug 20, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>
using namespace std;
void throw_it(int number) {
	int i = 99;
	float f = 123.123;
	const char str[80] = "This is a test!";
	cout << "number = " << number << ". ";

	if (number == 1) {
		throw i;
	} else if (number == 2) {
		throw f;
	} else if (number == 3) {
		throw str;
	} else {
		throw false;
	}
}
int main() {
	int number;
	srand (time(NULL));
	while (true) {
		number = rand() % 4 + 1;
		cout << "number = " << number << ". ";
		try {
			throw_it (number);
		} catch (int i) {
			cout << "Caught an integer " << i;
			cout << ". Trying again ... " << endl;
		} catch (float f) {
			cout << "Caught a float " << f;
			cout << ". Trying again ...  " << endl;
		} catch (const char *s) {
			cout << "Caught a string: " << s;
			cout << ". Trying again ...  " << endl;
		} catch (...) {
			cout << "Caught unknown type for number = " << number << ". Game over." <<endl;
			exit(-1);
		}
	}
	return 0;
}

