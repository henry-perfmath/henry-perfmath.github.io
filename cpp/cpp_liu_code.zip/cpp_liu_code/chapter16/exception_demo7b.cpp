/*
 * exception_demo7b.cpp
 *
 *  Created on: Aug 29, 2013
 *      Author: henry
 */
#include <iostream>
#include<cstdlib>
#include <new>
using namespace std;
int main(int argc, char *argv[]) {
	int* int_array;
	int size = atoi(argv[1]);

	int_array = new (nothrow) int[size];
	if (!int_array)
		cerr << "allocating " << size << " int elements failed\n";
	else
		cout << "allocating " << size << " int elements succeeded\n";
	if (!int_array)
		delete[] int_array;
	return 0;
}
