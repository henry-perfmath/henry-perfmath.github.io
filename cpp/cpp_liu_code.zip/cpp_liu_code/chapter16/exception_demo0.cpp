/*
 * exception_demo0.cpp
 *
 *  Created on: Aug 20, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib> // for calling exit
using namespace std;

int main() {
	int x = 10;
	int y;
	while (true) {
		cout << "Enter a number or zero: ";
		cin >> y;
		cout << x << " / " << y << " = " << x / y << endl;
	}
	return 0;
}



