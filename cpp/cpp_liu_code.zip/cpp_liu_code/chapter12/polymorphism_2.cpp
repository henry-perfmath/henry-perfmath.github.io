/*
 * polymorphism_2.cpp
 *
 *  Created on: Aug 13, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;
class account {
	double balance;
	int status;
	bool joint;
protected:
	bool is_joint () {return joint;}
public:
	//account (double balance, int status, bool joint) {
	account (double balance = 0, int status = 0, bool joint = 0) {
		this->balance = balance;
		this->status = status;
		this->joint = joint;
		cout << "base class account's constructor called" << endl;
	}
	~account () {cout << "base class account's destructor called" << endl;}
	double get_balance () {return balance;}
	int get_status () {return status;}
	void set_balance (double b) {balance = b;}
	void set_status (int i) {status = i;}
	void set_joint (bool j) {joint = j;}
};
class savings_account :  virtual public account {
	double interest_rate;
public:
	savings_account (double interest_rate,
		double balance, int status, bool joint) : account (balance, status,joint) {
		this->interest_rate = interest_rate;
		cout << "savings_account: constructor called" << endl;
	}
	virtual ~savings_account () {cout << "savings_account: destructor called" << endl;}
	double get_interest_rate () {return interest_rate;}
	void set_interest_rate (double rate) {interest_rate = rate;}
	virtual void show_savings_account () {
		cout << "\nshow savings account:"
			 << "\n\tstatus: " << get_status ()
			 << "\n\tbalance: " << get_balance ()
			 << "\n\tinterest rate: " << get_interest_rate ()
			 << "\n\tis_joint: " << is_joint () << endl;
	}
};

class checking_account :  virtual public account {
	double monthly_fee;
public:
	checking_account (double monthly_fee,
		double balance, int status, bool joint) : account (balance, status,joint) {
		this->monthly_fee = monthly_fee;
		cout << "checking_account: constructor called" << endl;
	}
	~checking_account () {cout << "checking_account: destructor called" << endl;}
	double get_monthly_fee () {return monthly_fee;}
	void set_monthly_fee (double fee) {monthly_fee = fee;}
	void show_checking_account () {
		cout << "\nshow checking account:"
			 << "\n\tstatus: " << get_status ()
			 << "\n\tbalance: " << get_balance ()
			 << "\n\tmonthly_fee: " << get_monthly_fee ()
			 << "\n\tis_joint: " << is_joint () << endl;
	}
};
class combo_account : public savings_account, public checking_account {
public:
	combo_account (double interest_rate, double monthly_fee,
		double balance, int status, bool joint) : savings_account (interest_rate,
				balance, status, joint), checking_account (monthly_fee,
						balance, status, joint){
		cout << "combo_account: constructor called\n" << endl;}
	~combo_account () {
		cout << "\ncombo_account: destructor called" << endl;
	}
	void show_savings_account () {
		cout << "\nshow_savings_account "
			 << "\ncalled in combo_account" << endl;
	}
};
int main () {
	// 0. Base and derived pointers and derived objects
	account *p;
	savings_account savings (0.01, 150.0, 1, 0), *p_savings;
	checking_account checking (5, 1000.0, 1, 1), *p_checking;
	combo_account combo (0.015, 5, 2000.0, 1, 1), *p_combo;

	// 1. derived class pointers pointing to derived objects
	//    and accessing the functions of derived objects => OK
	p_savings = &savings;
	p_savings->show_savings_account ();

	p_checking = &checking;
	p_checking->show_checking_account ();

	// 2. a base pointer pointing to derived objects
	//    and accessing the inherited functions => OK
	p = &savings;
	cout << "\nsavings balance: " << p->get_balance() << endl;;

	p= &checking;
	cout << "\nchecking balance: " << p->get_balance() << endl;

	// 3. a base pointer pointing to derived objects and accessing
	//    the functions of the derived objects => NOT OK
	p = &savings;
	//p->show_savings_account ();
	p= &checking;
	//p->show_checking_account ();

	// 4. a base pointer must point to its immediate derived objects
	//    to access the inherited members
	p_combo = &combo;
	combo.show_savings_account ();
	combo.show_checking_account ();

	p_savings = &combo;
	p_savings->show_savings_account ();
	p_checking = &combo;
	p_checking->show_checking_account ();

	// 5. polymorphism does not work with a base pointer
	// that points to an indirectly derived object
	p = &combo;
	//p-> show_savings_account ();

}
