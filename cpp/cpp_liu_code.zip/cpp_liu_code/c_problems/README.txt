1. headers and dynamic memory allocation

2. hashtable
	* dynamic memory allocation: type, pointer, and how many
	* double pointer with contiguous memory allocation makes it an array that can be indexed.
3. list: 
	* a node with a next pointer is a linked list
	* a list is a pointer to a node
	* insert: (1) make sure new pointer is created successfully, and (2) check if head is  empty.
4. queue
	* data structure: Node -> Queue
	* enqueue or any function: (a) normal case, (b) any special conditions to check, and (c) any properties to update?
	* traverse: one of the args is: void (* func_ptr) (Item item)

5. tree (bst)
	*insert: always at the leaf level. Use recursive call
	*clear: use recursive.

	* depth_first: inorder, preorder, postorder
	* breadth_first: level-based
		1. for tree_levels function, remember " + 1" as base returns 0
		2. for print_level function, there are 3 cases. node == NULL is the leaf node case.
		   (level - 1) is like a count-down
		3. for BFT function, always pass in "root", followd by num_of_levels. The 2nd param tells 
		   how many levels to do down, while (level - 1) keeps decreasing until hitting 1 to invoke print.

6. sorting
	* insertion sort: 
		1. 
	* quicksort: 
		1. do not forget to check (start < end)
		2. pivot, partition-exchange
		3. complexity: O(nlog(n))
	* mergesort: 
		1. do not forget to check (start < end)
		2. one extra temp array needed
		3. use 3 while-loops
		4. complexity: O(nlog(n))

7. misc
	* intersection_of_2_arrays
	
	* max_subseq_sum
	
	* two_sum_to_k
		1. declare a start and an end int variable and initialize 
		2. use a while loop and work from both ends with one of the indices updated a time
		3. a for-loop with one index will not work
	* sub_string
		1. declare all required variables and initialize them properly
		2. decide the logic and condition to return

	* reverse_string
		1. two versions: pointer version and array version
		2. remember the differnce b/w while (*end) and while (!end)
		3. since the function signature is (char *str), check if (str) {...} 

	* itoa
		1. Keep the original for sign info
		2. Work through the buffer with a cursor using modulo & keeping dividing by 10
		3. Add sign if negative
		4. null-end the string
		5. swap to reverse	