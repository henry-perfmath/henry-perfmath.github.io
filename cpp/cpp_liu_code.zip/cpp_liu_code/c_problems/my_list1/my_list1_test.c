#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "my_list1.h"

void display(Item item); // local

int main(void)
{
    Node *head = NULL;
    const Node *head_const = head;

    Item temp;

    if (is_full ())
    {
        fprintf(stderr,"No memory available! Bye!\n");
        exit(1);
    }
    
    temp.data = 10;
    printf("insert %d\n", temp.data);
    insert(temp, &head);

    temp.data = 20;
    printf("insert %d\n", temp.data);
    insert(temp, &head);

    temp.data = 30;
    printf("insert %d\n", temp.data);
    insert(temp, &head);

    printf("current size of the head:  %d\n", length(&head_const));

    if (is_empty(&head_const))
        printf("No data entered. ");
    else
    {
        printf ("Contents of the data head: ");
        traverse(&head_const, display);
        printf ("\n");
    }

    clear(&head);
    
    return 0;
}

void display(Item item)
{
    printf("%d ", item.data);
}

