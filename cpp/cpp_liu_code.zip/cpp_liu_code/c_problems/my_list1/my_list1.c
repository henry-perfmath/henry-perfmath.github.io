/*
 * (1) This Node is a dynamicly linked Node and has no CAPACITY parameter
 */
#include <stdio.h>
#include <stdlib.h>
#include "my_list1.h"

bool is_empty(const Node **head)
{
    if (head == NULL)
        return true;
    else
        return false;
}

bool is_full()
{
    Node *node_ptr;
    if (!(node_ptr = (Node *) malloc(sizeof(Node))))
    		return true;

    free(node_ptr);
    return false;
}

unsigned int length(const Node **head)
{
    const Node *cursor = *head;

    unsigned int count = 0;
    while (cursor != NULL)
    {
        ++count;
        cursor = cursor->next;
    }
    
    return count;
}

bool insert(Item item, Node **head)
{
	Node *new_node_ptr;
    new_node_ptr = (Node *) malloc(sizeof(Node));
    
    if (!new_node_ptr)
        return false;
    else {
    		new_node_ptr->item = item;
    		new_node_ptr->next = NULL;
    }

    	// do not create a variable until needed
	Node *cursor = *head;
    if (cursor == NULL)
        *head = new_node_ptr;
    else {
        while (cursor->next != NULL)
        		cursor = cursor->next;
        cursor->next = new_node_ptr;
    }
    
    return true;
}

void traverse(const Node **head, void (*func_ptr)(Item item))
{
    const Node *cursor = *head;
    
    while (cursor != NULL)
    {
        (*func_ptr)(cursor->item);
        cursor = cursor->next;
    }
}

void clear(Node **head)
{
	{
	    Node *ptr_save;
	    while (*head != NULL)
	    {
	        ptr_save = (*head)->next;
	        	free(*head);
	        *head = ptr_save;
	    }
	}
}

void clear_circular(Node **head, int length)
{
    Node *ptr_save;
    int count = 0;
    while (count < length && *head != NULL)
    {
        ptr_save = (*head)->next;
        	free(*head);
        *head = ptr_save;
        count++;
    }
}


