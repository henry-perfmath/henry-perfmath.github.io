/*
 * quicksort.cpp
 *
 *  Created on: Sep 5, 2013
 *      Author: henry
 */

#include <stdio.h>
#include <time.h>
#include <stdlib.h>

const int MAX_ARRAY_SIZE = 10;

/* do not forget & when pass in array elements
 * C has no templates, so we have to define our own swap function
 */
void swap (int *x, int *y) {
	int tmp;
	tmp = *x;
	*x = *y;
	*y = tmp;
}

/*
array regions: p + s1 region + s2 region + unpartitioned region
1. notations: m = start, n = end, x = last_s1, z = first_unpartitioned
2. set up to create S1 with values smaller than pivot
3. loop through first_unpartitioned (z) to end, advance x and swap first_unpartitioned with x
4. set pivot and its index (pivot points to the 1st element saved at the beginning)
*/
void partition(int a[], int m, int n, int *pvt_idx) {
	int x = m, pvt_val = a[m];
	for (int z = m + 1; z <= n; z++)
		if (a[z] < pvt_val) swap(&a[z], &a[++x]);
	swap(&a[m], &a[x]);
	*pvt_idx = x;
}

void my_quicksort(int a[], int start, int end) {
	int pvt_idx;

	if (start < end) {
		partition(a, start, end, &pvt_idx);
		my_quicksort (a, start, pvt_idx - 1);
		my_quicksort (a, pvt_idx + 1, end);
	}
}

int main() {
	srand(time(0));
	printf("before sorting:\n");
	int a[MAX_ARRAY_SIZE];
	for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
		a[i] = rand() % 30;
		(i < (MAX_ARRAY_SIZE - 1)) ? printf("%d ", a[i]) : printf("%d \n", a[i]);
	}

	my_quicksort(a, 0, MAX_ARRAY_SIZE - 1);
	printf("after sorting:\n");
	for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
		(i < (MAX_ARRAY_SIZE - 1)) ? printf("%d ", a[i]) : printf("%d \n", a[i]);
	}

	return 0;
}
