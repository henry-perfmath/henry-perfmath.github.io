/*
 * intersection_of_2_arrays.c
 *
 *  Created on: Feb 16, 2018
 *      Author: henryliu
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void get_intersection(int a[], int m, int b[], int n, int c[]) {

	int i = 0, j = 0, k = 0;
	while ((i < m) && (j < n)) {
		if (a[i] < b[j]) {
			i++;
		} else if (a[i] > b[j]) {
			j++;
		} else {
			printf("%d ", a[i]);
			c[k++] = a[i];
			i++;
			j++;
		}
	}
	printf("\n");
}

int main() {
	int a [13] = {1, 4, 8, 15, 20, 35, 46, 50, 60, 70, 80, 90, 100};
	int b [11] = {20, 40, 46, 55, 60, 75, 80, 85, 95, 100, 120};
	int SIZE = 10;
	int c [SIZE];
	for (int i = 0; i < SIZE; i++) {
		c[i] = -1;
	}
	get_intersection(a, 13, b, 11, c);
    for (int i = 0; c[i] > 0 && i < SIZE; i++) {
    		printf("%d ", c[i]);
    }
	printf("\n");
	return 0;
}

