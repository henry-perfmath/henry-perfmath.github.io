/*
 * find_repeated_char_2.c
 *
 *  Created on: Mar 2, 2018
 *      Author: henryliu
 */
// C program to find the fist character that
// is repeated
// https://www.geeksforgeeks.org/find-repeated-character-present-first-string/

#include <stdio.h>
#include <string.h>

// 256 is taken just to ensure nothing is left,
// actual max ASCII limit is 128
#define MAX_CHAR 256

int findRepeatFirst(char* s)
{
    // this is optimized method
    int p = -1, i, k;

    // initialized counts of occurrences of
    // elements as zero
    int hash[MAX_CHAR] = { 0 };

    // initialized positions
    int pos[MAX_CHAR];

    for (i = 0; i < strlen(s); i++) {
        k = (int)s[i];
        if (hash[k] == 0) {
            hash[k]++;
            pos[k] = i;
        } else if (hash[k] == 1)
            hash[k]++;
    }

    for (i = 0; i < MAX_CHAR; i++) {
        if (hash[i] == 2) {
            if (p == -1) // base case
                p = pos[i];
            else if (p > pos[i])
                p = pos[i];
        }
    }

    return p;
}

// Driver code
int main()
{
    char str[] = "geeksforgeeks";
    int pos = findRepeatFirst(str);
    if (pos == -1)
        printf("Not found");
    else
        printf("%c\n"
        		"", str[pos]);
    return 0;
}

