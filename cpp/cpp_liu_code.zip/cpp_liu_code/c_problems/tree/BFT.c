/*
 * bst.c
 *
 *  Created on: Feb 13, 2018
 *      Author: henryliu
 */

#include<stdio.h>
#include<stdlib.h>
#include "bst.h"

int tree_levels(Node *node)
{
    if (node == NULL)
        return 0;
    else
    {
        int left_most = tree_levels(node->left);
        int right_most = tree_levels(node->right);

        if (left_most > right_most)
        		return (left_most + 1);
        	else
        		return (right_most + 1);
    }
}

void print_level(Node *node, int level)
{
    if (node == NULL)
        return;
    if (level == 1)
        printf("%d ", node->key);
    else if (level > 1)
    {
    		//printf("<current level = %d and key = %d>\n", level, node->key);
    		print_level(node->left, level - 1);
    		print_level(node->right, level - 1);
    }
}

void BFT(Node *node)
{
    int num_of_levels = tree_levels(node);

    for (int i = 1; i <= num_of_levels; i++)
    		print_level(node, i);
}

int main()
{
    Node *root = NULL;
    root = insert(root, 50);

    insert(root, 30);
    insert(root, 20);
    insert(root, 40);
    insert(root, 70);
    insert(root, 60);
    insert(root, 80);

    // print depth_first_Traversal traversal of the BST
    printf("inorder... ");
    inorder(root);
    printf("\npreorder... ");
    preorder(root);
    printf("\npostorder... ");
    postorder(root);
    printf("\nBFT ... \n");
    BFT(root);
    printf("\nclear ... ");

    clear(root);
    return 0;
}
