#ifndef _QUEUE_H_
#define _QUEUE_H_
#include <stdbool.h>

 typedef struct item
 {
  int data;
 } Item;

#define MAXQUEUE 100

typedef struct node
{
    Item item;
    struct node *next;
} Node;

typedef struct queue
{
    Node *front;
    Node *rear;
    int length;
} Queue;

void init(Queue * queue);
bool is_full(const Queue *queue);
bool is_empty(const Queue *queue);
int queue_length(const Queue *queue);
void traverse(const Queue *queue, void (* func_ptr)(Item item));
bool enqueue(Item item, Queue *queue);
bool dequeue(Item *item_ptr, Queue *queue);
void clear(Queue *queue);

#endif
