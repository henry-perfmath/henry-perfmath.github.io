#include "my_list2.h"
#include <stdio.h>
#include <stdlib.h>

bool is_empty(const Node *list)
{
    if (list == NULL)
        return true;
    else
        return false;
}

bool is_full()
{
	bool full;

	Node *node_ptr = (Node *) malloc(sizeof(Node));
    if (!node_ptr)
        full = true;
    else
        full = false;
    free(node_ptr);
    
    return full;
}

unsigned int length(const Node *list)
{
    unsigned int count = 0;

    while (list != NULL)
    {
        ++count;
        list = list->next;
    }
    
    return count;
}

Node *insert(Item item, Node *list)
{
    Node *new_node_ptr;
    new_node_ptr = (Node *) malloc(sizeof(Node));
    if (!new_node_ptr)
        return NULL;
    
    new_node_ptr->item = item;
    new_node_ptr->next = NULL;

    Node *cursor = list;
    if (cursor == NULL)
        list = new_node_ptr;
    else {
        while (cursor->next != NULL) {
        		cursor = cursor->next;
        }
        cursor->next = new_node_ptr;
    }
    
    return list;
}

void traverse(const Node *list, void (*func_ptr)(Item item))
{
    while (list != NULL)
    {
        (*func_ptr)(list->item);
        list = list->next;
    }
}

Node * clear(Node *list)
{
    Node *ptr_save;
    while (list != NULL)
    {
        ptr_save = list->next;
        printf("freeing %d\n", list->item.data);
        	free(list);
        list = ptr_save;
    }
    return NULL;
}

Node *clear_circular(Node *list, int length)
{
    Node *ptr_save;
    int count = 0;
    while (count < length && list != NULL)
    {
        ptr_save = list->next;
        //printf("freeing %d\n", (*Node_ptr)->item.data);
        	free(list);
        list = ptr_save;
        count++;
    }
    return NULL;
}


