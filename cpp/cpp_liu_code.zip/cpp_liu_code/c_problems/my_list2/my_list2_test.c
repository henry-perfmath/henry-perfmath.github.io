#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "my_list2.h"
void list_data(Item item); // local
void check_empty (Node *list) {
	if (is_empty(list))
	        printf("Empty list\n");
	    else
	    {
	        printf ("Contents of the data list: ");
	        traverse(list, list_data);
	        printf ("\n");
	    }
}
int main(void)
{
    Node *list = NULL; // initialization
    Item curr;

    if (is_full())
    {
        fprintf(stderr,"No memory available! Bye!\n");
        exit(1);
    }
    
    curr.data = 10;
    printf("insert %d\n", curr.data);
    list = insert(curr, list);
    check_empty(list);

    curr.data = 20;
    printf("insert %d\n", curr.data);
    list = insert(curr, list);
    check_empty(list);

    curr.data = 30;
    printf("insert %d\n", curr.data);
    list = insert(curr, list);

    printf("current size of the list:  %d\n", length(list));

    check_empty(list);

    list = clear(list);
    check_empty(list);
    return 0;
}

void list_data(Item item)
{
    printf("%d ", item.data);
}

