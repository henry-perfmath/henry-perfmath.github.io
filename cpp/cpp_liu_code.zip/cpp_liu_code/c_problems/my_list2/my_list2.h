#ifndef Node_H_
#define Node_H_
#include <stdbool.h>

typedef struct data
{
    int data;
} Item;

typedef struct node
{
    Item item;
    struct node *next;
} Node;

bool is_empty(const Node *list);
bool is_full();
unsigned int length(const Node *list);
Node *insert(Item item, Node *list);
void traverse(const Node *list, void (* func_ptr)(Item item));

Node *clear(Node *list);
Node *clear_circular(Node *list, int length);
#endif
