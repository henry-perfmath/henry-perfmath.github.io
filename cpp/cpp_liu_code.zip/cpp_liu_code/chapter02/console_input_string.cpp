/*
 * console_input_string.cpp
 *
 *  Created on: Jul 21, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;
int main () {
	string name;

	cout << "What's your name? ";
	//cin >> name;
	getline (cin, name);
	cout << "You're " << name << endl;
	return 0;
}
