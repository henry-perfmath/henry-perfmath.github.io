/*
 * block_demo.cpp
 *
 *  Created on: Jul 21, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;
float get_pay (float wage, float hours);

int main () {
	float wage = 62.5; // hourly
	float hours = 0.0;
	float pay;
	bool input_valid = false;

	while (!input_valid) {
		cout << "Enter the number of hours you worked this week: ";
		cin >> hours;
		if (hours >= 0.0) {
			input_valid = true;
		} else {
			cout << "number of hours you worked this week must not be negative\n";
		}
	}

	cout << "hour\t pay\n";
	for (int i = 1; i <= (int) hours; i++) {
		pay = get_pay (wage, i);
		cout << i << "\t " << pay << endl;
	}

	return 0;
}
float get_pay (float wage, float hours) {
	return wage * hours;
}
