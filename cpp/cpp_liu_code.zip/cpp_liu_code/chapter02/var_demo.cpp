/*
 * var_demo.cpp
 *
 *  Created on: Jul 21, 2013
 *      Author: henry
 */
#include <iostream>
using namespace std;

int main() {
	// 1. variables
	int i = 10;
	double d = 99.99;
	string hello = "Hello World!";
	cout << "value of i + 10: " << i + 10 << endl;
	cout << "value of d + 100: " << d + 100 << endl;
	cout << "value of hello string + again: " << hello << " again" << endl;
	cout << endl;

	// 2. expressions
	i = i + 5;
	d = d + 100;
	hello = hello + " again";
	cout << "value of i: " << i << endl;
	cout << "value of d: " << d << endl;
	cout << "value of hello string + again: " << hello << endl;
	cout << endl;

	// 3. expressions again
	i = 5 + 5;
	d = 100 + 99.99;
	//hello = "Hello World!" + " again";
	cout << "value of i: " << i << endl;
	cout << "value of d: " << d << endl;
	//cout << "value of hello string + again: " << hello << endl;
	cout << endl;

	// 4. += assignment operator
	i += 5;
	d += 100;
	hello += " again";
	cout << "value of i: " << i << endl;
	cout << "value of d: " << d << endl;
	cout << "value of hello string + again: " << hello << endl;
	cout << endl;

	// 5. =+ assignment operator
	i =+ 5;
	d =+ 99.99;
	hello =+ " again";
	cout << "value of i: " << i << endl;
	cout << "value of d: " << d << endl;
	cout << "value of hello string: " << hello << endl;
	cout << endl;

	// 6. prefix increment operations
	cout << "value of ++i: " << ++i << endl;
	cout << "value of i: " << i << endl;
	cout << "value of ++d: " << ++d << endl;
	cout << "value of d: " << d << endl;
	cout << endl;

	// 7. postfix increment operations
	cout << "value of i++: " << i++ << endl;
	cout << "value of i: " << i << endl;
	cout << "value of d++: " << d++ << endl;
	cout << "value of d: " << d << endl;
	cout << endl;

	return 0;
}

