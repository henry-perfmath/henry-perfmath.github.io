/*
 * bit_fields.cpp
 *
 *  Created on: Aug 9, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

struct transmit_status_t {
	unsigned ready: 1;
	unsigned wait: 1;
	unsigned blocked: 1;
	unsigned header: 8;
	unsigned sent: 1;
	unsigned received: 1;
	unsigned n_bytes: 15; // try 30 and 105
} tx_status;

int main () {
	tx_status.ready = 1;
	tx_status.wait = 0;
	tx_status.blocked = 0;
	tx_status.header = 7;
	tx_status.sent = 1;
	tx_status.received = 0;
	tx_status.n_bytes = 256;

	cout << tx_status.ready << ' ' << tx_status.header
		 << ' ' << tx_status.n_bytes << endl;
	cout << "sizeof tx_status:" << sizeof (tx_status) << endl;
	return 0;
}


