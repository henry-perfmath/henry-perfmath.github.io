/*
 * union_demo.cpp
 *
 *  Created on: Aug 10, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

union i_ch_u {
	char ch;
	unsigned short i;
};

int main () {
	i_ch_u u_var;
	u_var.ch = 'x';
	cout << "point 1: ch = " << u_var.ch << " and i = " << u_var.i << endl;

	u_var.i = 100;
	cout << "point 2: ch = " << u_var.ch << " and i = " << u_var.i << endl;
	return 0;
}

