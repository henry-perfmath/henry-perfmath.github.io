/*
 * struct_demo0.cpp
 *
 *  Created on: Aug 7, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstring>
using namespace std;

struct account_t {
	char type [12];
	double balance;
	int status;
};
int main() {
	account_t checking;
	strcpy(checking.type, "checking");
	checking.balance = 100.5;
	checking.status = 1;

	cout << checking.type << " " << checking.balance
			<< " " << checking.status << endl;
	return 0;
}
