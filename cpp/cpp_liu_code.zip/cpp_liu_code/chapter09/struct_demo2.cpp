/*
 * struct_demo2.cpp
 *
 *  Created on: Aug 7, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstring>
using namespace std;

struct account_t {
	char type [12];
	double balance;
	int status;
};

account_t &lock_account (account_t &account) {
	account.status = 0;
	return account;
}
int main() {
	account_t checking;
	strcpy(checking.type, "checking");
	checking.balance = 100.5;
	checking.status = 1;

	account_t bad_account = lock_account (checking);
	cout << bad_account.type << " " << bad_account.balance
		 << " " << bad_account.status << endl;
	return 0;
}
