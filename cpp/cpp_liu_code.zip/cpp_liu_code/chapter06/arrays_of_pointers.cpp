/*
 * arrays_of_pointers.cpp
 *
 *  Created on: Jul 30, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdio>
using namespace std;

char str[256];
char *token[20];

int get_milliseconds() {
	return clock() * 1000 / CLOCKS_PER_SEC;
}

void tokenize ( ) {
	char *p;
	int index = 0;
	int counter = 0;
	p = str;
	token [index] = p;
	while (*p) { 								// not end of string
		if ( *p == ' ') { 						// whitespace
			*(token [index] + counter) = '\0';	// end of token
			counter = 0;						// initialize counter
			p++;								// advance string pointer
			token [++index] = p;				// initialize token
		} else { 								// not whitespace
			p++; 								// advance string pointer
			counter++;							// increment counter
		}
	} 											// end of string

}

int main() {
	cout << "enter a string: ";
	gets(str);
	int n_times = 1000000000; // 1 billion
	clock_t start = get_milliseconds();

	for (int i = 0; i < n_times; i++) {
		tokenize ();
	}
	int duration = get_milliseconds() - start;
	cout << "duration = " << duration << " ms" << endl;
	return 0;
}
