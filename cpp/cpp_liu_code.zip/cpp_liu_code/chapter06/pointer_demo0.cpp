/*
 * pointer_demo0.cpp
 *
 *  Created on: Jul 28, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int main () {
	int i = 100;

	int *int_ptr;
	int_ptr = &i;

	cout << int_ptr << ": " << *int_ptr << " at " << &i << endl;

	int k [5] = {33, 43, 62, 29, 0};

	int *int_array_ptr;
	int_array_ptr = k;

	cout << int_array_ptr << ' ' << k << ' '
		 << *int_array_ptr << ' ' << k[0] << ' '
		 << (int_array_ptr + 1) << ' ' << (k + 1) << ' '
		 << *(int_array_ptr + 1) << ' ' << k[1]
		 << endl;
	return 0;
}



