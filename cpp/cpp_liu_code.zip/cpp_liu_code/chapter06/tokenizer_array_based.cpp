/*
 * tokenizer_array_based.cpp
 *
 *  Created on: Jul 30, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdio>
using namespace std;

char str[256];
char token[80];
int get_milliseconds() {
	return clock() * 1000 / CLOCKS_PER_SEC;
}

int get_token(int start_index) {
	int i, j;
	i = start_index;
	for (j = 0; str[i] != ' ' && str[i]; j++, i++) {
		token[j] = str[i];
	}
	if (str[i] == ' ') {
		token[j] = '\0';
		i++;
	}
	//cout << token << endl;
	return i;
}

int main() {
	cout << "enter a string: ";
	gets(str);
	int n_times = 1000000000; // 1 billion
	clock_t start = get_milliseconds();
	for (int k = 0; k < n_times; k++) {
		int i = 0;
		while (str[i]) {
			i = get_token(i);
			//cout << "token  = " << token << endl;
		}
	}

	int duration = get_milliseconds() - start;
	cout << "duration = " << duration << " ms" << endl;
	return 0;
}

