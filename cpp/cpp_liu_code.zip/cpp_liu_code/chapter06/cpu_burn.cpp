/*
 * cpu_burn.cpp
 *
 *  Created on: Jul 30, 2013
 *      Author: henry
 */
/*
 * cpu_burn.cpp
 *
 *  Created on: Jul 30, 2013
 *      Author: hliu
 */
#include <iostream>
#include <cstdlib>
using namespace std;

string current_date_time();

int get_milliseconds () {
	return clock () * 1000 / CLOCKS_PER_SEC;
}

int main( ) {
	int n_times = 1000000000; // 1 billion
	cout << "start time: " << current_date_time() << endl;
	clock_t start = get_milliseconds ();

	for (int i = 0; i < n_times; i++) {
		rand();
		rand();
		rand();
	}

	int duration = get_milliseconds () - start;
	cout << "duration = " << duration << " ms" << endl;
	cout << "end time: " << current_date_time() << endl;
	return 0;
}

// Get current date/time in YYYY-MM-DD.HH:mm:ss
string current_date_time() {
	time_t now = time(0);
	struct tm tstruct;
	char buf[80];
	tstruct = *localtime(&now);
	strftime(buf, sizeof(buf), "%Y-%m-%d %X", &tstruct);

	return buf;
}


