#include <iostream>
using namespace std;

int main ()
{
   int  i = 10;
   int *int_ptr;
   int_ptr = &i;
   cout << *int_ptr << endl;

   double *dbl_ptr;
   //dbl_ptr = &i;
   dbl_ptr = (double *) &i;
   cout << *dbl_ptr;

   return 0;
}
