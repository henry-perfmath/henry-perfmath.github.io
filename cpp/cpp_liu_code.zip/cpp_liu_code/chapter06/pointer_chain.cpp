#include <iostream>
using namespace std;

int main ()
{
   int  i;
   int  *int_ptr;
   int  **int_ptr_ptr;

   i = 123;
   int_ptr = &i;
   int_ptr_ptr = &int_ptr;

   cout << "Value of i :" << i << endl;
   cout << "Value at *int_ptr :" << *int_ptr << endl;
   cout << "Value at **int_ptr_ptr :" << **int_ptr_ptr << endl;

   cout << endl;
   char str[256] = "This is a test";
   char *tkn;
   char **token;
   tkn = str;
   token = &tkn;
   cout << str << ": " << endl;
   cout << tkn << '/' << *tkn << '/' << tkn [1] << tkn [2]<< endl;
   cout << token << '/' << *token << '/' << token [1] << endl;
   cout << *(token + 2) << endl; // Segmentation fault
   return 0;
}
