#include <iostream>
using namespace std;

int main () {
   int *int_ptr2 = 0; // initialize int_ptr2 with 0
   //*int_ptr2 = 1;

   int  i = 10;
   int *int_ptr;
   *int_ptr = i;
   cout << *int_ptr << endl;

   return 0;
}
