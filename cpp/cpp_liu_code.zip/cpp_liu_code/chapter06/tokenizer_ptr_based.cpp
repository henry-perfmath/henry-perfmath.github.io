/*
 * tokenizer_ptr_based.cpp
 *
 *  Created on: Jul 30, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdio>
using namespace std;

char str[256];
char token[80];

int get_milliseconds() {
	return clock() * 1000 / CLOCKS_PER_SEC;
}

char *get_token(char *p) {
	char *q;
	q = token;
	while (*p != ' ' && *p) {
		*q = *p;
		p++;
		q++;
	}
	if (*p == ' ') {
		p++;
		*q = '\0';
	}
	//cout << *q << endl;
	return p;
}

int main() {
	char *p;
	cout << "enter a string: ";
	gets(str);
	int n_times = 1000000000; // 1 billion
	clock_t start = get_milliseconds();
	for (int i = 0; i < n_times; i++) {
		p = str;
		while (*p) {
			p = get_token(p);
			//cout << "token  = " << token << endl;
		}
	}

	int duration = get_milliseconds() - start;
	cout << "duration = " << duration << " ms" << endl;
	return 0;
}
