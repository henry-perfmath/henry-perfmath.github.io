/*
 * new_delete0.cpp
 *
 *  Created on: Aug 4, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int main () {
	int *int_ptr;
	int_ptr = new int;
	*int_ptr = 9;
	cout << *int_ptr << " at " << int_ptr << endl;
	delete int_ptr;
	//cout << *int_ptr << endl;
	return 0;
}



