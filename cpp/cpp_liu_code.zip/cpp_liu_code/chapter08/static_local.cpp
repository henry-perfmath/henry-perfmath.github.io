/*
 * static_local.cpp
 *
 *  Created on: Aug 4, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;
int size = 10;

double compute_avg (double number) {
	static int count = 0;
	static double sum = 0;
	sum += number;
	count++;
	return sum / count;
}
int main () {
	for (int i = 1; i < size; i++ ) {
		cout << " i = " << i << " avg = " << compute_avg (i) << endl;
	}
	return 0;
}



