/*
 * extern2.cpp
 *
 *  Created on: Aug 5, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int main () {
	extern int i;
	//i = 20;
	cout << "i = " << i << endl;
	return 0;
}
int i = 10;


