/*
 * new_delete1.cpp
 *
 *  Created on: Aug 4, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>
using namespace std;

int main () {
	int size = 10;
	//int *int_ptr;
	int *int_ptr = new int [size];

	for (int i = 0; i < size; i++) int_ptr [i] = rand() % 100;
	for (int i = 0; i < size; i++) cout << int_ptr [i] << ' ';
	cout << endl;
	delete [] int_ptr;
	return 0;
}



