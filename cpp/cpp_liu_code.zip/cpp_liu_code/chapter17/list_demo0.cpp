/*
 * list_demo0.cpp
 *
 *  Created on: Aug 30, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>	// for srand and rand
#include<list>	// for list
using namespace std;

int main() {
	int length = 10;
	srand(time(NULL));

	// seg 0: declare a list object
	list<int> lis;

	// seg 1: add elements using push_back function
	for (int i = 0; i < length; i++) {
		lis.push_back(rand() % length);
	}

	// seg 2: use size () function and indexing to access list
	cout << lis.size() << " elements added to lis.\n";
	// seg 3: use iterator to access list
	cout << "\naccessing list using an iterator: ";
	list<int>::iterator it = lis.begin();
	while (it != lis.end()) {
		cout << *it << ' ';
		it++;
	}

	// seg 4: use insert function to add a new element
	//it = lis.begin() + 5;

	it = lis.begin();
	for (int i = 0; i < 5; i++) it++;

	lis.insert(it, rand() % length);
	cout << "\nlist after inserting a new element at index 5: ";
	it = lis.begin();
	while (it != lis.end()) {
		cout << *it << ' ';
		it++;
	}

	// seg 5: use erase function to delete elements in range
	list<int>::iterator start, end;
	start= lis.begin();
	end = lis.end();
	for (int i = 0; i < 3; i++) {start++; end--;}
	lis.erase(start, end);
	cout << "\nlist after deleting 3 at start and 3 at end: ";
	it = lis.begin();
	while (it != lis.end()) {
		cout << *it << ' ';
		it++;
	}

	// seg 6: push_front, pop_back
	lis.push_front (rand() % length);
	lis.pop_back();
	cout << "\nlist after push_front, pop_back: ";
	it = lis.begin();
	while (it != lis.end()) {
		cout << *it << ' ';
		it++;
	}
	return 0;
}

