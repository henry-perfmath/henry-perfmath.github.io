/*
 * less_demo1c.cpp
 *
 *  Created on: Aug 30, 2013
 *      Author: henry
 */
#include <iostream>
#include <functional>   // for less
#include <algorithm>    // for sort and includes
using namespace std;

int main () {
  int int_array1[] = {16, 32, 1 ,8 ,4};
  int int_array2[] = {100, 8, 4};

  sort (int_array1, int_array1 + 5, less<int>());
  sort (int_array2, int_array2 + 3, less<int>());

  if (includes (int_array1, int_array1 + 5, int_array2, int_array2 + 3, less<int>())) {
    cout << "int_array1 includes int_array2.\n";
  } else {
	  cout << "int_array1 does not include int_array2.\n";
  }
  return 0;
}



