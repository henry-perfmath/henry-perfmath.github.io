/*
 * string_demo0.cpp
 *
 *  Created on: Aug 31, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int main () {
	char str1 [80];
	char str2 [] = "This is a test!";
	char str3 [80];

	str1 = "This is another test!";
	str3 = str1 + str2;

	cout << "str1 = " << str1 << endl;
	cout << "str2 = " << str2 << endl;
	cout << "str3 = " << str3 << endl;
 	return 0;
}
