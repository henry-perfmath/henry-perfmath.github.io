/*
 * string_demo2.cpp
 *
 *  Created on: Aug 31, 2013
 *      Author: henry
 */
#include<iostream>
#include<string>
using namespace std;

int main () {
	// seg 0: use of "=" and "+" with string objects
	string str1;
	string str2 = "This is an old test!";
	string str3;

	str1 = "This is a new test!";
	str3 = str1 + str2;

	cout << "str1 = " << str1 << endl;
	cout << "str2 = " << str2 << endl;
	cout << "str3 = " << str3 << endl;

	// seg 1: member function find
    int index1 = str1.find ("test");
    cout << "\nfind index of test in str1: " << index1 << endl;

    int index2 = str3.find ("test");
    cout << "find index of test in str3: " << index2 << endl;

    int index3 = str3.find("test", index2 + 1);
    cout << "find index of the next test in str3: " << index3 << endl;

    // seg 2: substring
    string str4 = str3.substr (index3);
    cout << "\na substring of str3: "  << str4 << endl;

    // seg 3: string comparison using "=="
    string str5 = string ("atest!");
    cout << "\nstr4 = " << str4 << " str5 = " << str5 << endl;
    if (str4 == str5) {
    	cout << "string comparison: str4 and str5 are equal\n";
    }  else {
    	cout << "string comparison: str4 and str5 are not equal\n";
    }

    // seg 4: string subscripting
    cout << "char of str5 at index = 2: " << str5 [2] << endl;
 	return 0;
}
