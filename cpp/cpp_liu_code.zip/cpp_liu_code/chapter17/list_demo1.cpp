/*
 * list_demo1.cpp
 *
 *  Created on: Aug 30, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>	// for srand and rand
#include<list>	// for list
using namespace std;

int main() {
	int length = 10;
	srand(time(NULL));

	// seg 0: declare a list object
	list<int> lis1, lis2;

	// seg 1: add elements using push_back function
	for (int i = 0; i < length; i++) {
		lis1.push_back(rand() % length);
		lis2.push_back(rand() % length);
	}

	// seg 2: use size () function and indexing to access list
	cout << lis1.size() << " elements added to lis1.\n";
	cout << lis2.size() << " elements added to lis2.\n";

	// seg 3: use iterator to access list
	cout << "\naccessing lis1 using an iterator: ";
	list<int>::iterator it1 = lis1.begin();
	while (it1 != lis1.end()) {
		cout << *it1 << ' ';
		it1++;
	}
	cout << "\naccessing lis2 using an iterator: ";
	list<int>::iterator it2 = lis2.begin();
	while (it2 != lis2.end()) {
		cout << *it2 << ' ';
		it2++;
	}

	// seg 4: sort lis1 and lis2;
	lis1.sort();
	lis2.sort();
	cout << "\naccessing lis1 after sorting: ";
	it1 = lis1.begin();
	while (it1 != lis1.end()) {
		cout << *it1 << ' ';
		it1++;
	}
	cout << "\naccessing lis2 after sorting: ";
	it2 = lis2.begin();
	while (it2 != lis2.end()) {
		cout << *it2 << ' ';
		it2++;
	}

	// seg 5: merge lis1 with lis2
	lis1.merge(lis2);
	cout << "\naccessing lis1 after merging with lis2: ";
	it1 = lis1.begin();
	while (it1 != lis1.end()) {
		cout << *it1 << ' ';
		it1++;
	}

	return 0;
}

