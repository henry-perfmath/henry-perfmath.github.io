/*
 * reverse.cpp
 *
 *  Created on: Aug 3, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

void reverse (char *str) {
	char *start, *end;
	start = str;
	end = str;
	while (*end) end++;
	while (end >= start) {
		cout << *end;
		end--;
	}
}
int main (int argc, char *argv []) {
	char str [] = "test";
	reverse (str);
	return 0;
}


