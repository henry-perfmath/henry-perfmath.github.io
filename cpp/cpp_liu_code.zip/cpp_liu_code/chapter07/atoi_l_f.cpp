/*
 * argc_argv.cpp
 *
 *  Created on: Aug 3, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>
using namespace std;

int main (int argc, char *argv []) {
	int i;
	long l;
	double d;

	i = atoi (argv [1]);
	l = atol (argv [2]);
	d = atof (argv [3]);
	cout << "i = " << i << " l = " << l << " d = " << d << endl;
}
