/*
 * call_by_value.cpp
 *
 *  Created on: Aug 3, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

void swap (int x, int y) {
	int temp;
	temp = x;
	x = y;
	y = temp;
	cout << "inside swapping: x = " << x << " y = " << y << endl;
}

int main () {
	int x, y;
	x = 1;
	y = 2;
	cout << "before swapping: x = " << x << " y = " << y << endl;

	swap (x, y);
	cout << "after swapping: x = " << x << " y = " << y << endl;

	return 0;
}


