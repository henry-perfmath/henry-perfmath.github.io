/*
 * argc_argv.cpp
 *
 *  Created on: Aug 3, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int main (int argc, char *argv []) {
	cout << "# of command line arguments: " << argc << endl;
	for (int i = 0; i < argc; i++) {
		cout << "arg " << i << ": " << argv [i] << endl;
	}
}
