/*
 * pass_arrays_to_func.cpp
 *
 *  Created on: Aug 3, 2013
 *      Author: henry
 */
#include<iostream>
#include <cstring> // for strcpy
using namespace std;

char *get_substring (char *sub, char *str) {
	int ch;
	char *p1, *p2, *start;
	for ( ch = 0; str [ch]; ch++) {
		p1 = &str [ch];
		start = p1;
		p2 = sub;
		while (*p2 && *p2 == *p1) {
			p1++;
			p2++;
		}

		if (!*p2) return start;
	}
	return 0;
}
int main () {
	//char *str = "This is a test";
	//char *sub_str = "is";

	//char *str;
	//char *sub_str;

	char *str;
	char *sub_str;
	strcpy (str, "This is a test");
	strcpy (sub_str, "is");

	sub_str = get_substring (sub_str, str);
	//sub_str = get_substring ("is", "This is a test");
	cout << "substring: " << sub_str << endl;
	return 0;
}



