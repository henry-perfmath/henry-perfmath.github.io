/*
 * str_cat0.c
 *
 *  Created on: Sep 19, 2013
 *      Author: henry
 */
#include<stdio.h>

int main () {
	char query [200];

	int startIndex = 10;
	int endIndex = 20;
	sprintf (query, "select * from facility where facility_id > %d AND facility_id < %d", startIndex, endIndex);
	printf ("query: %s\n", query);

	char b[100];
	      int k = 42;
	      float f = 1.1234f;
	      sprintf( b, "Formatted data:  %d / %f", k, f );
	      puts( b );

	return 0;
}



