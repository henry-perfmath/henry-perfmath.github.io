/*
 * max_subseq_sum3.cpp
 *
 *  Created on: Oct 14, 2013
 *      Author: hliu
 */
#include<iostream>
#include<cstdlib>

using namespace std;
int get_ms () {
	return clock () * (1000 / CLOCKS_PER_SEC);
}
int max_subsequence_sum(const int a[], const unsigned int n) {
	int sum = 0, max_sum = 0;
	for (int i = 0; i < n; i++)
		for (int j = i; j < n; j++) {
			sum = 0;
			for (int k = i; k <= j; k++)
				sum += a[k];
			if (sum > max_sum) {
				max_sum = sum;
			}
		}
	return max_sum;
}

int main() {
	int n = 0;
	cout << "enter n: ";
	cin >> n;
	srand(time(NULL));
	int a[n];
	a[0] = -5;
	for (int i = 1; i < n; i++) {
		a[i] = 20 / 2 - rand() % 20;
	}
/*
	for (int i = 0; i < n; i++) {
		cout << a[i] << " ";
	}
	cout << endl;
	*/
	clock_t t0 = get_ms ();
	int result = max_subsequence_sum(a, n);
	clock_t t1 = get_ms ();
	cout << "Elapsed time = " << (t1 -t0) << " ms";
	//cout << "result = " << result << endl;
	return 0;
}

