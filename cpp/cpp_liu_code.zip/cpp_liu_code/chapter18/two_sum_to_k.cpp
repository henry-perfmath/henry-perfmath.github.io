/*
 * two_sum_to_k.cpp
 *
 *  Created on: Oct 14, 2013
 *      Author: hliu
 */
#include<iostream>
#include<cstdlib>
using namespace std;
int get_milliseconds () {
	return clock () * (1000 / CLOCKS_PER_SEC);
}
void insertion_sort(int a[], int N) {
	for (int unsorted = 1; unsorted < N; ++unsorted) {
		int ins = unsorted;
		int currentItem = a[unsorted];
		while (a[ins - 1] > currentItem) {
			a[ins] = a[ins - 1];
			if (ins == 0)
				break;
			--ins;
		}
		a[ins] = currentItem;
	}
}

bool linear_search(const int a[], const int n, const int k, int &i, int &j) {
	i = 0; j = n - 1;
	bool found_it = false;

	int sum = 0;
	while (i < j) {
		sum = a[i] + a [j];
		if (sum < k) {
			i++;
		} else if (sum > k) {
			j--;
		} else {
			found_it = true;
			break;
		}
	}
	return found_it;
}

int main() {
	int n = 10;
	int k = 5;
	cout << "enter n and k (10 5): ";
	cin >> n >> k;
	//srand(time(NULL));
	int a[n];
	clock_t t0 = get_milliseconds ();
	for (int i = 0; i < n; i++) {
		a[i] = n / 2 - rand() % n;
		//cout << a[i] << " ";
	}
	cout << endl;
	clock_t t1 = get_milliseconds ();
	insertion_sort(a, n);
	for (int i = 0; i < 10; i++) {
		cout << a[i] << " ";
	}
	cout << endl;
	clock_t t2 = get_milliseconds ();
	int i, j;
		bool found_it = linear_search(a, n, k, i, j);
		if (found_it) {
			cout << "found it: i = " << i << " j = " << j << endl;
		} else {
			cout << " doesn't exist" << endl;
		}

	clock_t t3 = get_milliseconds ();
	cout << "search time: " << (t3 -t2) << " ms\n";
	return 0;
}
