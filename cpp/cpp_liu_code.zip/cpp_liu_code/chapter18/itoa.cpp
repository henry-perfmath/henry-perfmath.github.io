/*
 * itoa.cpp
 *
 *  Created on: Sep 6, 2013
 *      Author: henry
 */
#include <iostream>
using namespace std;

void itoa(int n, char *buf) {
	// keep the original for sign info
	int n0 = n;
	if (n0 < 0)
		n = -n;

	// index - buf array index and length
	int index = 0;
	do {
		buf[index] = n % 10 + '0';
		++index;
	} while ((n /= 10) > 0);

	// add sign if negative
	if (n0 < 0)
		buf[index++] = '-';

	// null-end the string
	buf[index] = '\0';

	// reverse it
	for (int i = 0; i < index / 2; i++)
		swap(buf[i], buf[index - i - 1]);
}
int main() {

	int i;
	char buf[9];
	do {
		cout << "Enter an integer (positive or negative or 0 to exit): ";
		cin >> i;
		itoa (i, buf);
		cout << "number " << i << " converted to string " << buf << "\n";
	} while (i != 0);
	return 0;
}

