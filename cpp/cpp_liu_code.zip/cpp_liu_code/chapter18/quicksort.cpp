/*
 * quicksort.cpp
 *
 *  Created on: Sep 5, 2013
 *      Author: henry
 */
#include<iostream>
#include<cstdlib>
using namespace std;

const int MAX_ARRAY_SIZE = 10;
/*
array regions: p + s1 region + s2 region + unpartitioned region
1. notations: m = start, n = end, x = last_s1, z = first_unpartitioned
2. set up to create S1 with values smaller than pivot
3. loop through first_unpartitioned (z) to end, advance x and swap first_unpartitioned with x
4. set pivot and its index (pivot points to the 1st element saved at the beginning)
*/
void partition(int a[], int m, int n, int *pvt_idx) {
	int x = m, pvt_val = a[m];
	for (int z = m + 1; z <= n; z++)
		if (a[z] < pvt_val) swap(a[z], a[++x]);
	swap(a[m], a[x]);
	*pvt_idx = x;
}

void my_quicksort(int a[], int start, int end) {
	int pvt_idx;

	if (start < end) {
		partition(a, start, end, &pvt_idx);
		my_quicksort (a, start, pvt_idx - 1);
		my_quicksort (a, pvt_idx + 1, end);
	}
}

int main() {
	srand(time(NULL));
	int a[MAX_ARRAY_SIZE];
	for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
		a[i] = rand() % 30;
		cout << a[i] << " ";
	}
	cout << endl;

	my_quicksort(a, 0, MAX_ARRAY_SIZE -1);
	cout << "after sorting:\n";
	for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
		cout << a[i] << " ";
	}
	cout << "done\n";

	return 0;
}


