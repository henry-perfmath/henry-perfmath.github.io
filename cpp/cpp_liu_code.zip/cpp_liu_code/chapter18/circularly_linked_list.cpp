/*
 * circularly_linked_list.cpp
 *
 *  Created on: May 11, 2013
 *      Author: henry
 */

#include <iostream>
#include <string>
using namespace std;

struct node {
	int data;
	node *next;
	node(int d) {
		data = d;
		next = 0;
	}
};

class mylist {
	int length;
	node *head;
	node *ptr_to(int position);
public:
	// constructors and destructor
	mylist();
	mylist(const mylist &list);
	~mylist();

	//operations
	bool is_empty();
	int size();
	void insert(int new_position, int new_item, bool &success);
	void remove(int position, bool &success);
	void retrieve(int position, int &item, bool &success);
	void display();

	void fold (int position, bool &success);
	node* get_head ();
};

//default construct
mylist::mylist() : length(0), head(0) {
}

//copy constructor
mylist::mylist(const mylist &list) : length(list.length) {
	if (!list.head)
		this->head = 0;
	else {
		// copy first node
		this->head = new node(list.head->data);
		//this->head->data = list.head->data;

		// copy rest of list
		node *new_prev = head;
		for (node *orig_curr = list.head->next; orig_curr;
				orig_curr = orig_curr->next) {
			new_prev->next = new node(orig_curr->data);
			new_prev = new_prev->next;
		}
		new_prev->next = 0;
	}
}
//destructor
mylist::~mylist() {
	bool success;
	while (!is_empty())
		remove(1, success);
}

bool mylist::is_empty() {
	return bool(length == 0);
}
int mylist::size() {
	return length;
}
node *mylist::ptr_to(int position) {
	node *trav = head;
	if (position < 1 || (position > size())) {
		return 0;
	} else {
		for (int skip = 1; skip < position; ++skip)
			trav = trav->next;
	}
	return trav;
}
void mylist::retrieve(int position, int &item, bool &success) {
	success = bool((position >= 1) && (position <= length));
	if (success) {
		node *curr = ptr_to(position);
		item = curr->data;
	}
}

void mylist::insert(int new_position, int new_item, bool &success) {
	int new_length = length + 1;
	success = (new_position >= 1) && (new_position <= new_length);
	if (success) {
		length = new_length;

		// create new node and place new item in it
		node *new_ptr = new node(new_item);
		success = (new_ptr);
		if (success) {
			new_ptr->data = new_item;
			// attach new node to list
			if (new_position == 1) {
				// insert new node at beginning of list
				new_ptr->next = head;
				head = new_ptr;
			}

			else {
				node *prev = ptr_to(new_position - 1);
				// insert new node after node to which prev points
				new_ptr->next = prev->next;
				prev->next = new_ptr;
			}
		}
	}
}

void mylist::remove(int position, bool& success) {
	node* curr;
	success = (position >= 1) && (position <= length);
	if (success) {
		length--;
		if (position == 1) {
			// delete the first node from the list
			curr = head;
			head = head->next;
		} else {
			node* prev = ptr_to(position - 1);
			// delete the node after the node to which prev points
			curr = prev->next; // save pointer to node
			prev->next = curr->next;
		}

		// return node to system
		curr->next = 0;
		delete curr;
		curr = 0;
	}
}

void mylist::fold(int position, bool& success) {
	node* curr = head;
	while (curr->next != NULL) {
		cout << "current item: " << curr->data << endl;
		curr = curr->next;
	}
	cout << "last item: " << curr->data << endl;

	node* ptr = ptr_to (position);
    curr->next = ptr;
}
 node *mylist::get_head () {
	 return head;
 }
void mylist::display() {
	cout << "display: ";
	for (node* curr = head; curr; curr = curr->next) {
		cout << curr->data << " ";
	}
	cout << endl;
}
void checkCircularLinkedList (mylist& list);
int main() {

	// create an empty mylist
	mylist list;
	bool success;
	int size = 19;
	for (int i = 0; i < size; i++) {
		list.insert (1, (size - i), success);
	}

	list.display ();
	list.fold (12, success);

	cout << "calling checkCircularLinkedList:\n";
	checkCircularLinkedList (list);
	return 0;
}
void checkCircularLinkedList (mylist& list) {
	// seg 0: declare fast and slow pointers
	node *fast = list.get_head();
	node *slow = list.get_head();

	// seg 1: move both pointers. Break if they meet
	cout << "find meeting point ...\n";
	while (fast != NULL && fast->next != NULL) {
		slow = slow->next;
		fast = fast->next->next;
		if (slow == fast) break;
	}

	// seg 2: no loop if fast or fast->next NULL
	if (fast == NULL || fast->next == NULL) return;
	cout << "circular linked list meeting point: " << slow->data << endl;

	// seg 3: find entry point for circular linked list
	cout << "\nfind entry point for circular linked list...\n";
	slow = list.get_head ();
	while (slow != fast) {
		slow = slow->next;
		fast = fast->next;
	}
	cout << "circular linked list entry point: " << fast->data << endl;
}
