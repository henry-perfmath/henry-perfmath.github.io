/*
 * max_subseq_sum1.cpp
 *
 *  Created on: Oct 14, 2013
 *      Author: hliu
 */
#include<iostream>
#include<cstdlib>

using namespace std;

int max_subsequence_sum(const int a[], const unsigned int n) {
	int sum = 0, max_sum = 0;
	for (int i = 0; i < n; i++)
		for (int j = i; j < n; j++) {
			sum = 0;
			for (int k = i; k <= j; k++)
				sum += a[k];
			if (sum > max_sum) {
				max_sum = sum;
			}
		}
	return max_sum;
}

int main() {
	int n = 0;
	cout << "enter n: ";
	cin >> n;
	srand(time(NULL));
	int a[n];
	a[0] = -5;
	for (int i = 1; i < n; i++) {
		a[i] = 20 / 2 - rand() % 20;
	}

	for (int i = 0; i < n; i++) {
		cout << a[i] << " ";
	}
	cout << endl;

	int result = max_subsequence_sum(a, n);
	cout << "result = " << result << endl;
	return 0;
}

