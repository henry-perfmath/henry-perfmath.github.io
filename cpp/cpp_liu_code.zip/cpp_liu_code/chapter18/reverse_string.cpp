/*
 * reverse_string.cpp
 *
 *  Created on: Sep 6, 2013
 *      Author: henry
 */
#include <iostream>
#include<cstring>
using namespace std;

void reverse1 (char *str);
void reverse2 (char *str);
void swap (char& x, char& y);

int main () {
	char str[20] = "This is a test";

	char *p;
	p = str;

	cout << "initial: " << str;
	reverse2 (str);

	cout << "\nafter: " << str << endl;
	return 0;
}

// mirroring swapping
void reverse1 (char *str) {
	int size = strlen (str);
	for (int i = 0; i < size / 2; i++) swap (str[i], str [size - i -1]);

}
// pointer arithmetic
void reverse2 (char *str) {
	char *end = str;

	if (str) {
		while (*end) {
		++end;
	}
	--end; // back up one

	char tmp;
	while (str < end) {
		tmp = *str;
		*str++ = *end;
		*end-- = tmp;
	}
	}
}
void swap (char& x, char& y) {
	char tmp;
	tmp = x;
	x = y;
	y = tmp;
}





