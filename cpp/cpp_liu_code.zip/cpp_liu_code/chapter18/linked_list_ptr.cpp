/*
 * linked_list_ptr.cpp
 *
 *  Created on: May 11, 2013
 *      Author: henry
 */

#include <iostream>
using namespace std;

struct node {
	int data;
	node *next;
	node(int d) {data = d; next = 0;}
};

class mylist {
	int length;
	node *head;
	node *ptr_to(int position);
public:
	// constructors and destructor
	mylist();
	mylist(const mylist &list);
	~mylist();

	//operations
	bool is_empty();
	int size();
	void insert(int new_position, int new_item, bool &success);
	void remove(int position, bool &success);
	void retrieve(int position, int &item, bool &success);
	void display();
};

//default construct
mylist::mylist() : length(0), head(0) { }

//copy constructor
mylist::mylist(const mylist &list) : length(list.length) {
	if (!list.head)
		this->head = 0;
	else {
		// copy head node
		this->head = new node(list.head->data);

		// copy rest of list
		node *new_prev = head;
		for (node *orig_curr = list.head->next; orig_curr;
				orig_curr = orig_curr->next) {
			new_prev->next = new node(orig_curr->data);
			new_prev = new_prev->next;
		}
		new_prev->next = 0;
	}
}
//destructor
mylist::~mylist() {
	bool success;
	while (!is_empty())
		remove(1, success);
}

bool mylist::is_empty() { return bool(length == 0); }
int mylist::size() { return length; }
node *mylist::ptr_to(int position) {
	node *trav = head;
	if (position < 1 || (position > size())) {
		return 0;
	} else {
		for (int skip = 1; skip < position; ++skip)
			trav = trav->next;
	}
	return trav;
}
void mylist::retrieve(int position, int &item, bool &success) {
	success = bool((position >= 1) && (position <= length));
	if (success) {
		node *curr = ptr_to(position);
		item = curr->data;
	}
}

void mylist::insert(int new_position, int new_item, bool &success) {
	int new_length = length + 1;
	success = (new_position >= 1) && (new_position <= new_length);
	if (success) {
		length = new_length;

		// create new node and place new item in it
		node *new_ptr = new node(new_item);
		success = (new_ptr);
		if (success) {
			// attach new node to list
			if (new_position == 1) {
				// insert new node at beginning of list
				new_ptr->next = head;
				head = new_ptr;
			} else {
				node *prev = ptr_to(new_position - 1);
				// insert new node after node to which prev points
				new_ptr->next = prev->next;
				prev->next = new_ptr;
			}
		}
	}
}

void mylist::remove(int position, bool& success) {
	node* curr;
	success = (position >= 1) && (position <= length);
	if (success) {
		length--;
		if (position == 1) {
			// delete the head node from the list
			curr = head;
			head = head->next;
		} else {
			node* prev = ptr_to(position - 1);
			// delete the node after the node to which prev points
			curr = prev->next; // save pointer to node
			prev->next = curr->next;
		}

		// return node to system
		curr->next = 0;
		delete curr;
		curr = 0;
	}
}

void mylist::display() {
	cout << "contents of the list: ";
	for (node* curr = head; curr; curr = curr->next) {
		cout << curr->data << " ";
	}
	cout << endl;
}
int main() {
	// create an empty mylist
	mylist list;
	bool success;

	// insert teh first node
	node n1(10);
	cout << "insert 10\n";
	list.insert(1, n1.data, success);

	// insert the second node
	node n2(20);
	cout << "insert 20\n";
	list.insert(2, n2.data, success);

	// insert the third node
	node n3(30);
	cout << "insert 30\n";
	list.insert(3, n3.data, success);
	cout << "current size of the list: " << list.size() << endl;
	// display
	list.display();

	cout << "\nremove 10\n";
	list.remove(1, success);
	cout << "current size of the list: " << list.size() << endl;
	list.display();
}

