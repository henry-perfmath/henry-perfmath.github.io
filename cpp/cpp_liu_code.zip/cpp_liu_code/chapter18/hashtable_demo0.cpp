/*
 * hashtable_demo0.cpp
 *
 *  Created on: May 12, 2013
 *      Author: henry
 */
#include <iostream>
#include <map>
using namespace std;

const int TABLE_CAPACITY = 256;
typedef int key_type;
typedef int value_type;

struct hash_entry {
	key_type key;
	value_type value;
	hash_entry(key_type k, value_type v) {
		key = k;
		value = v;
	}
};

class hash_table {
	hash_entry **table;
public:
	// constructor
	hash_table() {
		table = new hash_entry*[TABLE_CAPACITY];
		for (int i = 0; i < TABLE_CAPACITY; i++)
			table[i] = 0;
	}
	// get member function
	int get(key_type key) {
		int hash = (key % TABLE_CAPACITY); // hash function
		// find next empty slot using the linear probing open addressing scheme
		// this implementation is fine if the load factor does not exceed 1/2.
		while (table[hash] != 0 && table[hash]->key != key)
			hash = (hash + 1) % TABLE_CAPACITY;
		if (table[hash] == 0)
			return -1;
		else
			return table[hash]->value;
	}
	// put member function
	void put(key_type key, value_type value) {
		int hash = (key % TABLE_CAPACITY);
		while (table[hash] != 0 && table[hash]->key != key)
			hash = (hash + 1) % TABLE_CAPACITY;
		if (table[hash] != 0)
			delete table[hash]; // delete the old value if exists
		table[hash] = new hash_entry(key, value);
	}
	// clear member function
	void clear(int size) {
		for (int i = 0; i < size; i++)
			table[i] = 0;
	}

	~hash_table() {
		for (int i = 0; i < TABLE_CAPACITY; i++)
			if (table[i] != 0)
				delete table[i];
		delete[] table;
	}
};
int main() {
	unsigned int cycle;
	unsigned int max_cycles = 5000000;
	int test_key = 9;
	int test_value;
	long start, end;

	//seg 0: declare a hash_table named cache
	int cache_size = 10;
	start = clock();
	cycle = 0;
	hash_table cache;
	while (cycle < max_cycles) {
		for (int i = 0; i < cache_size; i++) {
			cache.put(i, 100 * i);
		}
		// retrieve from cache
		test_value = cache.get(test_key);
		cache.clear(cache_size);
		cycle++;
	}
	end = clock();
	cout << "hash_table time: " << (end - start) * (1000 / CLOCKS_PER_SEC)
			<< endl;

	//seg 1: using C++ STL map

	cycle = 0;
	map<int, int> m;
	while (cycle < max_cycles) {
		for (int i = 0; i < cache_size; i++) {
			m.insert(pair<int, int>(i, 100 * i));
		}
		map<int, int>::iterator p;
		p = m.find(test_key);
		if (p != m.end())
			test_value = p->second;
		cycle++;
		m.clear();
	}
	end = clock();
	cout << "STL map time: " << (end - start) * (1000 / CLOCKS_PER_SEC) << endl;

	return 0;
}
