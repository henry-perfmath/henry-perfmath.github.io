/*
 * array_multi.cpp
 *
 *  Created on: Oct 14, 2013
 *      Author: hliu
 */
#include<iostream>
#include<cstdlib>
using namespace std;
int get_ms () {
	return clock () * (1000 / CLOCKS_PER_SEC);
}
int num_zeros (int a[], int n) {
	int count = 0;
 for (int i = 0; i < n; i++) {
	 if (a[ i] == 0) count++;
 }
 return count;
}

void array_multi1 (int a[], int b[], int n) {
	int total = 1;
	for (int i = 0; i < n; i++) {
			if ( a[i] != 0 ) total *= a[i];
		}
	for (int i = 0; i < n; i++) {
		if (a[i] != 0) {
			b[i] = 0;
		} else {
			b[i] = total / a[i];
		}
	}
}
void array_multi2(int a[], int b[], int n) {
	for (int i = 0; i < n; i++)
		b[i] = 1;
	//cout << "first part \n";
	int first_part = 1;
	for (int i = 1; i < n; i++) {
		first_part = first_part * a[i - 1];
		b[i] = first_part;
		//cout << i << " " << a[i] << " " << b[i] << endl;
	}
	//cout << "second part \n";
	int second_part = 1;
	for (int i = n - 1; i > 0; i--) {
		second_part = second_part * a[i];
		b[i - 1] = b[i - 1] * second_part;
		//cout << i << " " << a [i] << " " << b [i - 1] << endl;
	}
}

int main() {
	int n, cycles;
	cout << "enter n cycles: ";
	cin >> n >> cycles;
	//srand(time(NULL));
	int a[n], b[n];
	for (int i = 0; i < n; i++) {
		a[i] = 20 / 2 - rand() % 10;
		cout << a[i] << " ";
	}
	cout << endl;
	int count = num_zeros (a, n);
	cout << "number of zeros = " << count << endl;
	int total = 1;
	for (int i = 0; i < n; i++) {
		if ( a[i] != 0 ) total *= a[i];
	}
	cout << "total = " << total << endl;

	if (count > 1) {
		for (int i = 0; i < n; i++) {
			b[i] = 0;
		}
	} else if (count == 1) {
		for (int i = 0; i < n; i++) {
			if (a[i] != 0) {
				b[i] = 0;
			} else {
				b[i] = total / a[i];
			}
		}
	} else {
		for (int i = 0; i < n; i++) {
			b[i] = total / a[i];
		}
	}
	for (int i = 0; i < n; i++) {
		cout << b[i] << " ";
		}
	cout << endl;
	clock_t t0 = get_ms ();
	for (int i = 0; i < cycles; i++) {
		array_multi1 (a, b, n);
}

	clock_t t1 = get_ms ();
	cout << "Elapsed time (array_multi_1) = " << (t1 -t0) << " ms\n";

	t0 = get_ms ();
		for (int i = 0; i < cycles; i++) {
			array_multi2 (a, b, n);
	}

		t1 = get_ms ();
		cout << "Elapsed time (array_multi_2) = " << (t1 -t0) << " ms\n";
	return 0;
}

