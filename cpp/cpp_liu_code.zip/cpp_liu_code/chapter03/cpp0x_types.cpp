/*
 * cpp0x_types.cpp
 *
 *  Created on: Jul 23, 2013
 *      Author: henry
 */
#include <iostream>
#include <limits>
using namespace std;

int main()
{
    // C++0x arithmetic types
	cout << "size of bool: " << sizeof (bool) << '\n';
	cout << "size of char: " << sizeof (char) << '\n';
	cout << "size of wchar_t: " << sizeof (wchar_t) << '\n';
	cout << "size of short int: " << sizeof (short int) << '\n';
	cout << "size of int: " << sizeof (int) << '\n';
	cout << "size of long int: " << sizeof (long int) << '\n';
	cout << "size of float: " << sizeof (float) << '\n';
	cout << "size of double: " << sizeof (double) << '\n';
	cout << "size of long double: " << sizeof (long double) << '\n';
    return 0;
}
