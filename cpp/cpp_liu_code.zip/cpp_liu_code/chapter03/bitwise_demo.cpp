/*
 * bitwise_demo.cpp
 *
 *  Created on: Jul 27, 2013
 *      Author: henry
 */
#include <iostream>
#include <cmath>
using namespace std;

bool get_bit (int number, int n) {
	return ((number & (1 << n)) != 0);
}
int set_bit (int number, int n) {
	return number | (1 << n);
}
int clear_bit (int number, int n) {
	int mask = ~(1 << n);
	return number & mask;
}
int clear_left_most_through_n_bits (int number, int n) {
	int mask = (1 << n) - 1;
	return number & mask;
}
int clear_n_through_0_bits (int number, int n) {
	int mask = ~((1 << (n + 1)) - 1);
	return number & mask;
}
int update_bit (int number, int n, int v) {
	int mask = ~(1 << n);
	return (number & mask) | (v << n);
}
void print_number (int number) {

	int n_bits = rint (log2 (number) + 0.5); // compute number of bits
	for (int i = 0; i < n_bits; i++) {
		cout << get_bit (number, n_bits - 1 - i);
	}
	cout << endl;
}
int main() {

	int number, n;
	cout << "Enter an integer number for bit manipulation: ";
	cin >> number;
	cout << "Enter the bit manipulation position (counting backwards, zero-based): ";
	cin >> n;
	print_number (number);
	cout << endl;
	cout << "get_bit (" << number << ", " << n << "): " << get_bit (number, n) << endl;
	cout << "set_bit (" << number << ", " << n << "): " << set_bit (number, n) << endl;
	cout << "clear_bit (" << number << ", " << n << "): " << clear_bit (number, n) << endl;
	cout << "clear_left_most_through_n_bits (" << number << ", " << n << "): " << clear_left_most_through_n_bits (number, n) << endl;
	cout << "clear_n_through_0_bits (" << number << ", " << n << "): " << clear_n_through_0_bits (number, n) << endl;

	cout << "Enter the value (0 or 1) of the bit to be updated: ";
	int new_bit_value;
	cin >> new_bit_value;

	cout << "update_bit (" << number << ", " << n << "): " << update_bit (number, n, new_bit_value) << endl;
	return 0;
}



