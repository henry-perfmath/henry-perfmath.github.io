/*
 * sizeof_demo0.cpp
 *
 *  Created on: Jul 23, 2013
 *      Author: henry
 */
#include <iostream>
#include <climits>
#include <limits>
#include <cfloat>
using namespace std;

int main()
{
	// c limits
    cout << "size of char:\t\t" << sizeof (char);
    cout << " min=" << CHAR_MIN << " max=" << CHAR_MAX << endl;

    cout << "size of int:\t\t" << sizeof (int);
    cout << " min=" << INT_MIN << " max=" << INT_MAX <<endl;
    cout << "size of float:\t\t" << sizeof (float);
    cout << " min=" << FLT_MIN << " max=" << FLT_MAX << endl;
    cout << "size of double:\t\t" << sizeof (double);
    cout << " min=" << DBL_MIN << " max=" << DBL_MAX << endl;
    cout << "size of bool:\t\t" << sizeof (bool) << endl;

    // C++ template
    cout << '\n'; // output an empty new line
    cout << "Minimum value for int: " << numeric_limits<int>::min() << '\n';
    cout << "Maximum value for int: " << numeric_limits<int>::max() << '\n';

    cout << '\n';
    // type wchar_t
    cout << "size of wchar_t:\t" << sizeof (wchar_t) << endl;
    cout << "size of void:\t" << sizeof (void) << endl;
    return 0;
}



