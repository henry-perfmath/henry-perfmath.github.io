/*
 * file_io_demo5.cpp
 *
 *  Created on: Aug 28, 2013
 *      Author: henry
 */
#include<iostream>
#include<fstream>
using namespace std;

int main() {
	ifstream in ("test_0.txt", ios::in|ios::binary);
	if (in) {
		// get file length
		in.seekg(0, in.end);
		int length = in.tellg();
		cout << "File size: " << length << " bytes\n";

		// move get pointer to the beginning
		in.seekg(0, in.beg);

		char *buffer = new char[length];

		// read the entire file
		in.read(buffer, length);
		for (int i = 0; i < length; i++) cout << buffer[i];

		in.close();
		delete[] buffer;
	}

	fstream out ("test_0a.txt", ios::in|ios::out|ios::binary);
	if (out) {
		out.seekp (5, ios::beg);
		out.put ('#');
		out.close ();
	}
	return 0;
}

