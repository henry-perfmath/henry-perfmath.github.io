/*
 * exception_demo2.cpp
 *
 *  Created on: Aug 20, 2013
 *      Author: henry
 */
#include<iostream>
#include<ctype.h>
#include<cstdlib> // for calling exit
using namespace std;
int divide (int x, int y) {
	if (!y) throw 0;
	return (x / y);
}
int main() {
	int x = 10;
	int y;
	while (true) {
		cout << "Enter a non-zero number or zero: ";
		cin >> x >> y;
		try {
			cout << x << " / " << y << " = " << divide (x, y) << endl;
		} catch (int i) {
			cout << "Exception: divide by " << i;
			cout << ". Please re-enter a non-zero #" << endl;
			//exit(-1);
		}
	}
	return 0;
}



