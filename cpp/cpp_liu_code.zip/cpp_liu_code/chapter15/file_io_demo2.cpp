/*
 * file_io_demo2.cpp
 *
 *  Created on: Aug 27, 2013
 *      Author: henry
 */
#include<iostream>
#include<fstream>
using namespace std;
int read_file (const char *in_file_name) {
	ifstream in;
		in.open (in_file_name, ios::in|ios::binary);
		if (!in) {
			cout << "Error in opening the file " << in_file_name << endl;
			return -1;
		}
		char ch;
		while (in.get (ch)) {
			cout << ch;
		}
		in.close ();
		return 0;
}
int write_file (const char *out_file_name) {
	ofstream out;
		out.open (out_file_name, ios::out|ios::binary);
		if (!out) {
			cout << "Error in opening the file " << out_file_name << endl;
			return -1;
		}
		const char *p = "This is another another test!";
		while (*p) {
			out.put (*p++);
		}
		out.close ();
		return 0;
}
int main () {
	const char *in_file_name = "test_0.txt";
	const char *out_file_name = "test_2.txt";
	read_file (in_file_name);
	write_file (out_file_name);
	return 0;
}



