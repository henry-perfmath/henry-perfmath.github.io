/*
 * file_io_demo5.cpp
 *
 *  Created on: Aug 28, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int main () {
	cout << "Enter a string: ";
	char ch = cin.peek ();
	cout << "First char is " << ch << endl;

	char c;
	cin >> c;
	cout << "Extracted the char " << c << endl;
	cin.putback ('c');
	cin.putback ('b');
	cin.putback ('a');

	char ch2;
	cin >> ch2;
	cout << "Extracted the char " << ch2 << " again" << endl;
	return 0;
}



