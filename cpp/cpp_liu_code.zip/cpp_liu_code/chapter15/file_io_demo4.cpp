/*
 * file_io_demo3.cpp
 *
 *  Created on: Aug 27, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;

int main() {
	//seg #1: create a string buffer and read a line from console
	// with getline function
	char *str;
	str = new char [80];

	cout << "Enter a line: ";
	cin.getline (str, 79);
	cout << "line " << str << " has " << cin.gcount () << " chars\n";

	//seg #2: read a line from console
	// with get function
	cout << "Enter another line: ";
	cin.get (str, 79);
	cout << "line " << str << " has " << cin.gcount () << " chars\n";

	//seg #3: read from console with getline function
	cin.getline (str, 79);
	cout << cin.gcount () << " char remaining in the cin stream\n";

	//seg #4: read from console with getline function
	cout << "Enter another line to try getline again:";
	cin.getline (str, 79);
	cout << "line " << str << " has " << cin.gcount () << " chars\n";

	delete[] str;
	return 0;
}

