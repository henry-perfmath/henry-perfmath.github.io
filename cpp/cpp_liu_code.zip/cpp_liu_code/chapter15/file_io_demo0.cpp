/*
 * file_io_demo0.cpp
 *
 *  Created on: Aug 27, 2013
 *      Author: henry
 */
#include<iostream>
#include<fstream>
using namespace std;

int main () {
	const char *in_file_name = "test_0.txt";
	ifstream in;
	in.open (in_file_name);
	if (!in) {
		cout << "Error in opening the file " << in_file_name << endl;
		return -1;
	}
	string line;
	//in >> line;
	getline (in, line);
	cout << line;

	/*
	char ch;
	in >> ch;
	do {
		cout << ch;
		in >> ch;
	} while (!in.eof());
	*/
	in.close ();
	return 0;
}



