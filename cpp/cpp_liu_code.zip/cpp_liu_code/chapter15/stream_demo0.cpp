/*
 * stream_demo0.cpp
 *
 *  Created on: Aug 26, 2013
 *      Author: henry
 */
#include<iostream>
#include<fstream>
#include<cstdlib>
using namespace std;

int main () {
	std::streambuf *errbuf, *logbuf, *outbuf;
	std::ofstream errstr, logstr, outstr;

	errstr.open ("test_err.txt");
	logstr.open ("test_log.txt");
	outstr.open ("test_out.txt");

	errbuf = errstr.rdbuf ();
	cerr.rdbuf (errbuf);

	logbuf = logstr.rdbuf ();
	clog.rdbuf (logbuf);

	outbuf = outstr.rdbuf ();
	cout.rdbuf (outbuf);
	int x = 10;
	int y;

	while (true) {
		cout << "Enter a number or zero: ";
		cin >> y;
		clog << "The user entered " << y << endl;
		if (!y) {
			cerr << "Divide-by-zero error! Enter a non-zero number.\n";
		} else {
			cout << x << " / " << y << " = " << x / y << endl;
		}
		if (y == 1) {
			errstr.close ();
			logstr.close ();
			outstr.close ();
			exit (0);
		}
	}
	return 0;
}



