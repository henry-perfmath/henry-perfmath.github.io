/*
 * virtual_base.cpp
 *
 *  Created on: Aug 13, 2013
 *      Author: henry
 */
#include<iostream>
using namespace std;
class account {
	double balance;
	int status;
	bool joint;
protected:
	bool is_joint () {return joint;}
public:
	//account (double balance, int status, bool joint) {
	account (double balance = 0, int status = 0, bool joint = 0) {
		this->balance = balance;
		this->status = status;
		this->joint = joint;
		cout << "base class account's constructor called" << endl;
	}
	~account () {cout << "base class account's destructor called" << endl;}
	double get_balance () {return balance;}
	int get_status () {return status;}
	void set_balance (double b) {balance = b;}
	void set_status (int i) {status = i;}
	void set_joint (bool j) {joint = j;}
};
class savings_account :  virtual public account {
	double interest_rate;
public:
	savings_account (double interest_rate,
		double balance, int status, bool joint) : account (balance, status,joint) {
		this->interest_rate = interest_rate;
		cout << "savings_account: constructor called" << endl;
	}
	~savings_account () {cout << "savings_account: destructor called" << endl;}
	double get_interest_rate () {return interest_rate;}
	void set_interest_rate (double rate) {interest_rate = rate;}
	void show_savings_account () {
		cout << "status: " << get_status ()
			 << "\nbalance: " << get_balance ()
			 << "\ninterest rate: " << get_interest_rate ()
			 << "\nis_joint: " << is_joint () << endl;
	}
};

class checking_account :  virtual public account {
	double monthly_fee;
public:
	checking_account (double monthly_fee,
		double balance, int status, bool joint) : account (balance, status,joint) {
		this->monthly_fee = monthly_fee;
		cout << "checking_account: constructor called" << endl;
	}
	~checking_account () {cout << "checking_account: destructor called" << endl;}
	double get_monthly_fee () {return monthly_fee;}
	void set_monthly_fee (double fee) {monthly_fee = fee;}
	void show_checking_account () {
		cout << "status: " << get_status ()
			 << "\nbalance: " << get_balance ()
			 << "\nmonthly_fee: " << get_monthly_fee ()
			 << "\nis_joint: " << is_joint () << endl;
	}
};
class combo_account : public savings_account, public checking_account {
public:
	combo_account (double interest_rate, double monthly_fee,
		double balance, int status, bool joint) : savings_account (interest_rate,
				balance, status, joint), checking_account (monthly_fee,
						balance, status, joint){
		cout << "combo_account: constructor called\n" << endl;}
	~combo_account () {
		cout << "\ncombo_account: destructor called" << endl;
	}
};
int main () {
	combo_account combo (0.015, 5, 100.0, 1, 1);
	combo.show_savings_account ();
	combo.show_checking_account ();
	return 0;
}



