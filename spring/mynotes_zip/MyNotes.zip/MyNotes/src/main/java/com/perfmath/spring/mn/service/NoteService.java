package com.perfmath.spring.mn.service;

import java.util.List;

import com.perfmath.spring.mn.model.domain.Note;

public interface NoteService {
	
	public void addNote(Note note);
	public List<Note> checkLogin(String username, String password);
	public List<Note> listNoteByUser(String username);
	public List<Note> listNote();
	public void removeNote(Integer id);
}
