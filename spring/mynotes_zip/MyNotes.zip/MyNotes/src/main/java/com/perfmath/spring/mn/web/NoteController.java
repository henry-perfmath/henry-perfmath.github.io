package com.perfmath.spring.mn.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.perfmath.spring.mn.model.domain.Note;
import com.perfmath.spring.mn.service.CreateNoteValidator;
import com.perfmath.spring.mn.service.NoteService;

@Controller
public class NoteController {

	@Autowired
	private NoteService noteService;

	@RequestMapping(value = "/createNote/username/{username}", method = RequestMethod.POST)
	public ModelAndView createNote(@PathVariable("username")
	String username, @ModelAttribute("note")
	Note note, BindingResult result) {
		System.out.println ("execute createNote");
		note.setUsername(username);	
		ModelAndView mav = new ModelAndView ();
		new CreateNoteValidator().validate (note, result);
		if (!result.hasErrors ()) {
		noteService.addNote(note);
		
		mav.setViewName ("note"); // to note.jsp
		mav.addObject("username", username);
		mav.addObject("noteList", noteService.listNoteByUser(username));
		}
    	return mav; 	
	}
	@RequestMapping(value = "/delete/username/{username}/noteId/{noteId}")
	public ModelAndView deleteNote(@PathVariable("username")
	String username, @PathVariable("noteId") 
	Integer noteId) {

		noteService.removeNote(noteId);
		ModelAndView mav = new ModelAndView ();
		mav.setViewName ("note");
		mav.addObject("username", username);
		mav.addObject("note", new Note ());
		mav.addObject("noteList", noteService.listNoteByUser(username));
    	return mav;
	}
}
