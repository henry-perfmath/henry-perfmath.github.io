package com.perfmath.spring.mn.model.dao;

import java.util.List;

import com.perfmath.spring.mn.model.domain.Note;

public interface NoteDAO {
	
	public void addNote(Note note);
	public List<Note> listNote();
	public void removeNote(Integer id);
	public List<Note> checkLogin(String username,  String password);
	public List<Note> listNoteByUser(String username);
}
