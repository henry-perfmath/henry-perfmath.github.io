package com.perfmath.spring.mn.service;

import org.springframework.stereotype.Component;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.validation.Errors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.perfmath.spring.mn.model.domain.Note;

@Component
public class CreateNoteValidator implements Validator {

	/** Logger for this class and subclasses */
	protected final Log logger = LogFactory.getLog(getClass());

	public boolean supports(Class clazz) {
		return Note.class.isAssignableFrom(clazz);
	}

	public void validate(Object target, Errors errors) {
		Note note = (Note) target;
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username",
					"required.username", "username is required.");
	}
}