package com.perfmath.spring.mn.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.perfmath.spring.mn.model.domain.Note;
import com.perfmath.spring.mn.service.NoteService;

@Controller
public class LoginController extends AbstractController {
	@Autowired
	private NoteService noteService;
	private Logger logger = org.slf4j.LoggerFactory.getLogger(this.getClass());

	@RequestMapping("/loginController")
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.info("Testing logging from SLF4J ... it works");

		String viewString = "redirect:/"; // redirect to login.jsp
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		List<Note> noteList = noteService.checkLogin(username, password);
		ModelAndView mav = new ModelAndView();
		if (noteList.size() > 0) {
			logger.info("returned " + noteList.size() + " notes for "
					+ username);
			viewString = "note"; // to note.jsp
			mav.addObject("username", username);
			mav.addObject("noteList", noteService.listNoteByUser(username));
			mav.addObject("note", new Note());
		} else {
			logger.info("User " + username + " login error. Create a user account or retry.");
		}
		mav.setViewName(viewString);
		return mav;
	}
}
