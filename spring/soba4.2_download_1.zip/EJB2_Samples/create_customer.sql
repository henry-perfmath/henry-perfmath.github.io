CREATE TABLE customer (     
customerID	VARCHAR(10) not null,     
name    VARCHAR(30),     
password    VARCHAR(30),     
email         VARCHAR(30),     
locked BOOLEAN);
alter table customer  add constraint customer_pk_customerID primary key (customerID);
