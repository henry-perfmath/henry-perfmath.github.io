package com.ejb2.test;

import java.lang.RuntimeException;

public class CustomerDAOSysException extends RuntimeException {
	public CustomerDAOSysException(String msg) {
		super(msg);
	}

	public CustomerDAOSysException() {
		super();
	}
}
