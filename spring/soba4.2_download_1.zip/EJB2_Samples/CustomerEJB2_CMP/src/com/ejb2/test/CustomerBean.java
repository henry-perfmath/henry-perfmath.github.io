package com.ejb2.test;

import java.util.*;
import javax.ejb.*;
public abstract class CustomerBean implements EntityBean {
	private EntityContext context;
	
	public abstract String getCustomerID();
	public abstract void setCustomerID(String id);
	public abstract String getName();
	public abstract void setName(String name);
	public abstract String getPassword();
	public abstract void setPassword(String password);
	public abstract String getEmail();
	public abstract void setEmail(String email);
	public abstract boolean getLocked();
	public abstract void setLocked(boolean locked);	
	public abstract Collection ejbSelectTotalCustomers () throws FinderException;

	public int ejbHomeGetTotalCustomers () 
			throws FinderException {
			return ejbSelectTotalCustomers ().size();
		}

	public String ejbCreate (String name, String password,
			String email, boolean locked) throws CreateException {
		
			String newKey = (new RandomID(10)).getId();
			setCustomerID (newKey);
			setName (name);
			setPassword (password);
			setEmail (email);
			setLocked (locked);
			return newKey;
		}
	public void setEntityContext (EntityContext context) {
		this.context = context;
	}
	public void unsetEntityContext () {
		System.out.println ("unsetEntityContext ()");
	}
	public void ejbActivate () {
		System.out.println ("ejbActivate ()");
	}
	public void ejbPassivate () {
	}
	public void ejbLoad () {
	}
	public void ejbStore () {
	}
	public void ejbPostCreate (String name, String password,
			String email, boolean locked)  {		
		}
	public void ejbRemove () {
	}
}
