package com.perfmath.ejb3.client;

import java.math.BigDecimal;
import java.util.*;
import javax.naming.*;
import com.perfmath.ejb3.ejb.*;
import com.perfmath.ejb3.jpa.*;
import com.perfmath.ejb3.util.RandomID;

public class TestCustomerEJB3 {

	public static void main(String[] args) throws Exception {

		InitialContext ctx = null;
		try {
			ctx = getInitialContext();
		} catch (Exception ex) {
			System.out.println("Error in establishing initial context: "
					+ ex.getMessage());
		}

		CustomerManager customerManager = (CustomerManager)ctx.lookup("CustomerManagerEJB3/remote");  

		String customerName = "customer" + (new RandomID()).getId();
		System.out.println ("creating " + customerName);
		customerManager.createCustomer(customerName, "password", "customer0@abc.com", false);

		System.out.println ("finding " + customerName);
		Customer customer = customerManager.findCustomerByName(customerName);
		
		int customerId = customer.getId ();
		System.out.println ("saving txs for for customer with customer ID: " + customerId);
		customerManager.saveTxs(customerId, new BigDecimal(1000.0*Math.random()), "EJB 3 test", "test");

		System.out.println ("find all txs for " + customerName);
		List<BankingTx> txs = customerManager.findAllTxs(customerId);

		System.out.println("Listing txs for "+customer.getName());
		Iterator <BankingTx> iter = txs.iterator();
		while (iter.hasNext()) {
			BankingTx tx = iter.next();
			System.out.println("----------------");
			System.out.println("tx id: " + tx.getId());
			System.out.println("description: " +tx.getDescription());
			System.out.println("Type: " +tx.getType());
			System.out.println("amount: " +tx.getAmount());
		}
	}
	protected static InitialContext getInitialContext() throws NamingException {
		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put("java.naming.factory.initial",
				"org.jboss.security.jndi.JndiLoginInitialContextFactory");
		env.put("java.naming.provider.url", "localhost:1099");
		env.put(Context.SECURITY_PRINCIPAL, "admin");
		env.put(Context.SECURITY_CREDENTIALS, "admin");
		return new InitialContext(env);
	}
}
