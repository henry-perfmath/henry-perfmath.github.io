create database ejb3db;
grant usage on *.* to ejb3admin@localhost identified by 'ejb3admin';
grant all privileges on ejb3db.* to ejb3admin@localhost;
show databases;