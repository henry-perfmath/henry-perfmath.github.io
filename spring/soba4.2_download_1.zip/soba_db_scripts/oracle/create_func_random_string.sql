CREATE OR REPLACE FUNCTION random_string (type IN VARCHAR2, length IN NUMBER)
  RETURN VARCHAR2 IS
  rdm_string VARCHAR2 (500);
  BEGIN
    SELECT DBMS_RANDOM.STRING (type, length) INTO rdm_string FROM DUAL;
    RETURN rdm_string;
  END;
/