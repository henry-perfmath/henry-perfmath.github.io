CREATE OR REPLACE FUNCTION compute_balance (acnt_id NUMBER, amount NUMBER)
  RETURN NUMBER IS
  curr_balance NUMBER;
  BEGIN
    SELECT balance into curr_balance FROM ACCOUNT
	WHERE account_id = acnt_id;
    RETURN (amount + curr_balance);
  END;
/