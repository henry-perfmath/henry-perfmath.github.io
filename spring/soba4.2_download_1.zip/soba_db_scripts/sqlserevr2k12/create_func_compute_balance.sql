CREATE FUNCTION compute_balance (@acnt_id NUMERIC(10,2), @amount NUMERIC(10,2))
  RETURNS NUMERIC(10,2) AS
  BEGIN;
  DECLARE @curr_balance NUMERIC;
    SELECT @curr_balance = ACCOUNT.balance FROM ACCOUNT
	WHERE account_id = @acnt_id;
    RETURN (@amount + @curr_balance);
  END;
