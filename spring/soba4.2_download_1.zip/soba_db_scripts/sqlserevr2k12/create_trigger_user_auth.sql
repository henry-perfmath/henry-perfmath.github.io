CREATE TRIGGER dbo.USER_AUTH
  on dbo.LOGINUSER
  AFTER INSERT
  AS
	declare @username varchar (9);
	select @username=i.username from inserted i;
	INSERT INTO AUTHORITIES (USERNAME, AUTHORITY) VALUES (@username, 'ROLE_CUST');
go