-- SQL Server does not support BEFORE TRIGGER so this has to be done with an AFTER TRIGGER
CREATE TRIGGER account_balance_update on dbo.BANKINGTX
  AFTER INSERT  
  AS
  declare @account_id varchar(9), @amount decimal (10, 2), @account_new_balance decimal (10, 2), @transaction_id numeric (10,0);
  SELECT @account_id=i.account_id from inserted i;
  SELECT @account_new_balance=a.balance FROM ACCOUNT a WHERE a.ACCOUNT_ID = @account_id;
  SELECT @amount=i.amount from inserted i;
  SELECT @transaction_id=i.TRANSACTION_ID from inserted i;
  set @account_new_balance = @account_new_balance + @amount;

  BEGIN
  UPDATE ACCOUNT SET BALANCE = @account_new_balance WHERE ACCOUNT.ACCOUNT_ID = @account_id;
  UPDATE BANKINGTX set BALANCE = @account_new_balance WHERE TRANSACTION_ID = @transaction_id;
  END
  go
