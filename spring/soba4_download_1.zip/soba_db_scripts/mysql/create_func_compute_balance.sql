DELIMITER //

CREATE FUNCTION compute_balance (acnt_id INTEGER, amount INTEGER)
  RETURNS INTEGER

  BEGIN
  
    DECLARE curr_balance INTEGER;
    SELECT balance into curr_balance FROM ACCOUNT
	WHERE account_id = acnt_id;
    RETURN (amount + curr_balance);
  END//
  DELIMITER ;
  
