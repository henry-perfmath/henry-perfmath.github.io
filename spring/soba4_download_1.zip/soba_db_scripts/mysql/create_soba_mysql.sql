create database soba;
grant usage on *.* to sobaadmin@localhost identified by 'sobaadmin';
grant all privileges on soba.* to sobaadmin@localhost;
show databases;
 
