create user sobaadmin with password 'sobaadmin';
create database soba owner sobaadmin;
grant all privileges on database soba to sobaadmin;