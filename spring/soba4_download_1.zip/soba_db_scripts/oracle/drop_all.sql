DROP SEQUENCE acl_sid_id_seq;
DROP SEQUENCE acl_class_id_seq;
DROP SEQUENCE aoi_id_seq;
DROP SEQUENCE ae_id_seq;
DROP SEQUENCE customer_id_seq;
DROP SEQUENCE account_id_seq;
DROP SEQUENCE bankingtx_id_seq;
DROP SEQUENCE bll_pymnt_seq;
DROP SYNONYM users;
DROP INDEX TX_ACCOUNT_ID_TX_DATE_IX;

drop trigger user_auth;
drop trigger account_balance_update;
drop function compute_balance;
drop function random_string;
drop view activity cascade constraints;
drop table bankingtx cascade constraints;
drop table transfer cascade constraints;
drop table bill_payment cascade constraints;
drop table statement cascade constraints;
drop table account cascade constraints;
drop table authorities cascade constraints;
drop table loginuser cascade constraints;
drop table acl_entry cascade constraints;
drop table acl_object_identity cascade constraints;
drop table acl_class cascade constraints;
drop table acl_sid cascade constraints;
drop table customer cascade constraints;


