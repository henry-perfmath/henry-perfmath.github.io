CREATE OR REPLACE TRIGGER account_balance_update
  BEFORE INSERT  on BANKINGTX

  FOR EACH ROW
	DECLARE account_new_balance NUMBER (10,2);
  BEGIN
	SELECT BALANCE INTO account_new_balance FROM ACCOUNT WHERE ACCOUNT.ACCOUNT_ID = :new.ACCOUNT_ID;
	account_new_balance := account_new_balance + :new.AMOUNT;
        UPDATE ACCOUNT SET (BALANCE) = account_new_balance 
	WHERE ACCOUNT.ACCOUNT_ID = :new.ACCOUNT_ID;
        :new.balance := account_new_balance;
  END;
/