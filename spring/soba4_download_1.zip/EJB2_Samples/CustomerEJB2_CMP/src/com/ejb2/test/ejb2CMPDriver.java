package com.ejb2.test;

import java.util.*;

import javax.naming.*;
import javax.rmi.*;
import javax.ejb.*;

public class ejb2CMPDriver {
	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		System.out.println("testing Customer EJB2");
		InitialContext ctx = null;
		try {
			ctx = getInitialContext();
			sessionTest(ctx);
		} catch (Exception ex) {
			System.out.println("Error in establishing initial context: "
					+ ex.getMessage());
		}
		long endTime = System.currentTimeMillis();
		System.out.println("total time: " + (endTime - startTime) / 1000.0
				+ " seconds");
	}

	public static void sessionTest(InitialContext ctx) {
		System.out.println("\nsesionBeanTest:");
		long startTime = System.currentTimeMillis();
		try {
			Object obj = ctx.lookup("CustomerSession");

			CustomerSessionHome home = (CustomerSessionHome) PortableRemoteObject
					.narrow(obj, CustomerSessionHome.class);
			String customerID = (new RandomID(10).getId());
			System.out.println("testing CustomerEJB2: creating customer_"
					+ customerID);

			CustomerVO customer = new CustomerVO(customerID, "password",
					"customer0@abc.com", false);
			CustomerSession customerSession = home.create();
			try {
				customerSession.createCustomer(customer);
			} catch (CreateException ex) {
				System.out.println("createCustomer error: " + ex.getMessage());
			}

			System.out.println("testing CustomerEJB2: getCustomers");
			Collection <CustomerVO> customers = customerSession.getCustomers();
			String primaryKey = "229083991";
			String name = null;
			String password = null;
			int count = 0;
			Iterator<CustomerVO> cust = customers.iterator();
			while (cust.hasNext()) {
				CustomerVO c0 = (CustomerVO) cust.next();
				if (count < 1) {
					name = c0.getName();
					password = c0.getPassword();
					count = 1;
					System.out.println(name + ": " + password);
				}
			}
			System.out.println("testing CustomerEJB2: getCustomerByID");
			try {
				CustomerVO customerVO = customerSession
						.getCustomerByID(primaryKey);
				System.out.println("getCustomerByID result: " + customerID);
			} catch (FinderException ex) {
				System.out
						.println("findByPrimaryKey error: " + ex.getMessage());
			}

			try {
				customerSession.authenticateCustomer(name, password);
			} catch (CustomerCredentialException ex) {
				System.out.println("authenticateCustomer error: "
						+ ex.getMessage());
			}

			System.out.println("testing getTotalCustomers:");
			int totalNumOfCustomers = customerSession.getTotalCustomers();
			System.out.println("total number of customers in database: "
					+ totalNumOfCustomers);

		} catch (CreateException ex) {
			System.err.println("Error creating object.");
			System.err.println(ex.getMessage());

		} catch (Exception ex) {
			System.err.println("Caught an unexpected exception.");
			System.err.println(ex.getMessage());
		}
		long endTime = System.currentTimeMillis();
		System.out.println("sessionTest execution time: "
				+ (endTime - startTime) / 1000.0 + " seconds");
	}

	protected static InitialContext getInitialContext() throws NamingException {
		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put("java.naming.factory.initial",
				"org.jboss.security.jndi.JndiLoginInitialContextFactory");
		env.put("java.naming.provider.url", "localhost:1099");
		env.put(Context.SECURITY_PRINCIPAL, "admin");
		env.put(Context.SECURITY_CREDENTIALS, "admin");
		return new InitialContext(env);
	}

}
