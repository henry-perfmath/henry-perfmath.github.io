package com.ejb2.test;

import javax.ejb.*;

public interface CustomerLocal extends EJBLocalObject
{
    public String getCustomerID ();
    public String getName ();
    public void setName (String newName);
    public String getPassword ();
    public void setPassword (String newPassword);
    public String getEmail ();
    public void setEmail (String newEmail);
    public boolean getLocked ();
    public void setLocked (boolean locked);
}
