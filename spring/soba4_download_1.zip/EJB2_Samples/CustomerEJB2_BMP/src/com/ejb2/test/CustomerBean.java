package com.ejb2.test;

import java.util.*;
import javax.ejb.*;

public class CustomerBean implements EntityBean {
	CustomerModel customerData;
	private CustomerDAO customerDAO = null;
	private EntityContext context;
	private boolean dirty;
	
	public String getCustomerID() {
		return customerData.getCustomerID ();
	}

	public String getName() {
		return customerData.getName ();
	}
	public void setName(String name)  {
		customerData.setName (name);
		dirty = true;
	}
	public String getPassword() {
		return customerData.getPassword ();
	}
	public void setPassword(String password) {
		customerData.setPassword (password);
		dirty = true;
	}
	public String getEmail() {
		return customerData.getEmail ();
	}
	public void setEmail(String email) {
		customerData.setEmail (email);
		dirty = true;
	}
	public boolean getLocked() {
		return customerData.getLocked ();
	}
	public void setLocked(boolean locked) {
		customerData.setLocked (locked);
		dirty = true;
	}

	public String ejbFindByPrimaryKey (String primaryKey) 
		throws FinderException {
		boolean found;
		try {
			CustomerDAO dao = getDAO ();
			found = dao.dbSelectByPrimaryKey(primaryKey);
		} catch (CustomerDAOSysException ex) {
			ex.printStackTrace();
			throw new EJBException ("ejbFindByPrimaryKey: " + ex.getMessage());
		}
		if (found) {
			return primaryKey;
		} else {
			throw new ObjectNotFoundException
			("Row for id = " + primaryKey + " not found.");
		}	
	}
	public Collection ejbFindByCustomerName (String name) 
			throws FinderException {
			Collection customers;
			try {
				CustomerDAO dao = getDAO ();
				customers = dao.dbSelectByCustomerName (name);
			} catch (CustomerDAOSysException ex) {
				ex.printStackTrace();
				throw new EJBException ("ejbFindByCustomerName: " + ex.getMessage());
			}
			return customers;
		}
	public Collection ejbFindAll () 
			throws FinderException {
			Collection customers;
			try {
				CustomerDAO dao = getDAO ();
				customers = dao.dbSelectAll();
			} catch (CustomerDAOSysException ex) {
				ex.printStackTrace();
				throw new EJBException ("ejbFindAll: " + ex.getMessage());
			}
			return customers;
		}
	public int ejbHomeGetTotalCustomers () 
			throws FinderException {
			int numOfCustomers;
			try {
				CustomerDAO dao = getDAO ();
				numOfCustomers = dao.dbCountTotalCustomers();
			} catch (CustomerDAOSysException ex) {
				ex.printStackTrace();
				throw new EJBException ("ejbHomeGetTotalCustomers: " + ex.getMessage());
			}
			return numOfCustomers;
		}
	private CustomerDAO getDAO() throws CustomerDAOSysException {
		if (customerDAO == null) {
			customerDAO = CustomerDAOFactory.getDAO();
		}
		return customerDAO;
	}
	public String ejbCreate (String name, String password,
			String email, boolean locked) throws CreateException {
		System.out.println ("ejbCreate(): name = " + name);
		CustomerModel customer = null;
		try {
			CustomerDAO dao = getDAO ();
			String key = dao.dbGetKey ();
			customer = new CustomerModel (key, name, password, email, locked);
			dao.dbInsertCustomer(customer);
		} catch (CustomerDAOSysException ex) {
			throw new CreateException ("ejbCreate: " +
					ex.getMessage());
		}
		customerData = customer;
		dirty = false;
		return customerData.getCustomerID();
			
		}
	public void setEntityContext (EntityContext context) {
		this.context = context;
	}
	public void unsetEntityContext () {
		System.out.println ("unsetEntityContext ()");
	}
	public void ejbActivate () {
		System.out.println ("ejbActivate ()");
	}
	public void ejbPassivate () {
		customerDAO = null;
	}
	public void ejbLoad () {
		System.out.println ("ejbLoad ()");
		try {
			CustomerDAO dao = getDAO ();
			customerData = dao.dbLoadCustomer((String)context.getPrimaryKey()) ;
			dirty = false;
		} catch (CustomerDAOSysException ex) {
			ex.printStackTrace();
			throw new EJBException ("ejbLoad: " +
					ex.getMessage());
		}
	}
	public void ejbStore () {
		try {
			if (dirty) {
			CustomerDAO dao = getDAO ();
			dao.dbStoreCustomer(customerData) ;
			dirty = false;
			}
		} catch (CustomerDAOSysException ex) {
			ex.printStackTrace();
			throw new EJBException ("ejbStore: " +
					ex.getMessage());
		}
	}
	public void ejbPostCreate (String name, String password,
			String email, boolean locked)  {		
		}
	public void ejbRemove () {
		System.out.println ("ejbRemove ()");
		try {
			CustomerDAO dao = getDAO ();
			dao.dbRemoveCustomer((String)context.getPrimaryKey()) ;
			dirty = false;
		} catch (CustomerDAOSysException ex) {
			ex.printStackTrace();
			throw new EJBException ("ejbRemove: " +
					ex.getMessage());
		}
	}
}
