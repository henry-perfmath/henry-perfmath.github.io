package com.ejb2.test;

public class CustomerVO implements java.io.Serializable {
	private String name;
	private String password;
	private String email;
	private boolean locked;


	public CustomerVO(String name, String password, String email, boolean locked) {
		super();
		this.name = name;
		this.password = password;
		this.email = email;
		this.locked = locked;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	public boolean getLocked() {
		return locked;
	}

	public void setLocked(boolean clocked) {
		this.locked = locked;
	}
}
