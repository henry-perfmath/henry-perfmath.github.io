package com.perfmath.ejb3.ejb;

import javax.ejb.Remote;

@Remote
public interface CustomerManagerRemote extends  CustomerManager  {

}
