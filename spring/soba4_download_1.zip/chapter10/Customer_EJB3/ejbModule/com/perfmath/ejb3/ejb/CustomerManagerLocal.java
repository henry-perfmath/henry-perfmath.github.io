package com.perfmath.ejb3.ejb;

import javax.ejb.Local;

@Local
public interface CustomerManagerLocal extends  CustomerManager  {

}
