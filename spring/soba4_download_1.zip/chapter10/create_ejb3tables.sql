create table customer (
id bigint unsigned not null auto_increment primary key,
name varchar (30) not null,
password varchar(30) not null,
email       varchar(30) not null,     
locked tinyint(1) not null
);

create table bankingtx (
id bigint unsigned not null auto_increment primary key,
description varchar(45) default null,
amount decimal(10,2) default null,
type varchar(30) not null,
customer_id bigint unsigned not null,
foreign key (customer_id) references customer (id)
);

alter table bankingtx add constraint fk_bankingtx foreign key (customer_id) references customer (id) on delete cascade on update cascade;