package com.perfmath.spring.mn.web;

import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.perfmath.spring.mn.model.domain.Note;
import com.perfmath.spring.mn.service.NoteService;

@Controller
public class NoteController {

	@Autowired
	private NoteService noteService;

	@RequestMapping("/index")
	public String listNotes(Map<String, Object> map) {

		map.put("note", new Note());
		map.put("noteList", noteService.listNote());

		return "note";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String addNote(@ModelAttribute("note")
	Note note, BindingResult result) {

		noteService.addNote(note);

		return "redirect:/index";
	}

	@RequestMapping("/delete/{noteId}")
	public String deleteNote(@PathVariable("noteId")
	Integer noteId) {

		noteService.removeNote(noteId);

		return "redirect:/index";
	}
}
