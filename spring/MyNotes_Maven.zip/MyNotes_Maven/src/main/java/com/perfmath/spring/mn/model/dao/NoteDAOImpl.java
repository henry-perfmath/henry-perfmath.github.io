package com.perfmath.spring.mn.model.dao;

import java.util.List;


import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.perfmath.spring.mn.model.domain.Note;

@Repository
public class NoteDAOImpl implements NoteDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public void addNote(Note note) {
		sessionFactory.getCurrentSession().save(note);
	}

	public List<Note> listNote() {

		return sessionFactory.getCurrentSession().createQuery("from Note")
				.list();
	}

	public void removeNote(Integer id) {
		Note note = (Note) sessionFactory.getCurrentSession().load(
				Note.class, id);
		if (null != note) {
			sessionFactory.getCurrentSession().delete(note);
		}

	}
}
