package com.perfmath.spring.mn.model.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.perfmath.spring.mn.model.domain.Note;

@Repository
public class NoteDAOImpl implements NoteDAO {

	@Autowired
	private SessionFactory sessionFactory;
private static final Logger log = LoggerFactory.getLogger(NoteDAOImpl.class);
	//@Cacheable("noteCache")
	//@CachePut("noteCache")
	public List<Note> listNote() {
		 long startTime = System.nanoTime();
		List<Note> notes =  sessionFactory.getCurrentSession().createQuery("from Note")
				.list();
		log.info("listNote() " + (System.nanoTime() - startTime)/1000 + " microseconds");
		return notes;
		}
	 //@CacheEvict ("noteCache")
	// @CachePut("noteCache")
	public void addNote(Note note) {
		 long startTime = System.nanoTime();
			sessionFactory.getCurrentSession().save(note);
			log.info("saveNote() " + (System.nanoTime() - startTime)/1000 + " microseconds");
		} 
	public List<Note> checkLogin(String username, String password) {
		 long startTime = System.nanoTime();
		 List<Note> notes = sessionFactory.getCurrentSession().createQuery("from Note "
					+ " where username = '" + username + "' and password = '" + password + "'").list();
			log.info("saveNote() " + (System.nanoTime() - startTime)/1000 + " microseconds");
			return notes;
		} 
	public List<Note> listNoteByUser(String username) {
		 long startTime = System.nanoTime();
		 List<Note> notes = sessionFactory.getCurrentSession().createQuery("from Note "
					+ " where username = '" + username + "'").list();
			log.info("saveNote() " + (System.nanoTime() - startTime)/1000 + " microseconds");
			return notes;
		} 
	public void removeNote(Integer id) {
		Note note = (Note) sessionFactory.getCurrentSession().load(
				Note.class, id);
		if (null != note) {
			sessionFactory.getCurrentSession().delete(note);
		}

	}
}
