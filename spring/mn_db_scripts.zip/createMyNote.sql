CREATE TABLE MYNOTE (     
id         	INT PRIMARY KEY AUTO_INCREMENT,   
username	VARCHAR(12),
password	VARCHAR (8),  
category   	VARCHAR(20),
subject    	VARCHAR(30),     
content	        VARCHAR(500),         
created     	TIMESTAMP DEFAULT NOW() ); 
