insert into mynote (username, password, category, subject, content, created) values ('user0', 'user0', 'sys created', 'sys created', 'sys created', current_timestamp);


