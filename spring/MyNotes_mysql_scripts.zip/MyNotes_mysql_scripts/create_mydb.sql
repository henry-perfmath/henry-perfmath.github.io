create database mydb;
grant usage on *.* to mydbadmin@localhost identified by 'mydbadmin';
grant all privileges on mydb.* to mydbadmin@localhost;
show databases;
 
