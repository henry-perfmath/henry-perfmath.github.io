CREATE TABLE NOTES (     
id         	INT PRIMARY KEY AUTO_INCREMENT,     
subject    	VARCHAR(30),     
content	        VARCHAR(500),     
url   		VARCHAR(50),    
created     	TIMESTAMP DEFAULT NOW() ); 
