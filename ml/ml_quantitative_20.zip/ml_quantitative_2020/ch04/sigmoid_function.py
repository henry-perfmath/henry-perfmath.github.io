import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
 
x = np.linspace (-5, 5, 20)
x1 = np.linspace (-5, 0, 10)
x2 = np.linspace (0, 5, 10)
y2 = 1./(1 + np.exp(-x2))
y = 1./(1 + np.exp(-x))
y1 = 1./(1 + np.exp(-x1))

plt.xlabel("t")
plt.ylabel(r'$\sigma(t)$')

plt.text(-3.8, 0.83, r'$\sigma(t) = 1/(1 + e^{-t})$', fontsize=12)
plt.tick_params(direction='in', length=3, width=1, colors='k')
plt.yticks(np.arange(0, 1, 0.1))
plt.plot([-5, 5], [0.5, 0.5], color ='r')
plt.fill_between(x1, 0, y1)
plt.fill_between(x2, y2, 1)
plt.xlim ([-5, 5])
plt.ylim ([0, 1])
plt.title("logistic function")
plt.grid(True)
plt.show()
