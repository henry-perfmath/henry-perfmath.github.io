#pip3 install python-mnist
#https://www.renom.jp/notebooks/tutorial/neuralnetwork/download_mnist/notebook.html
import random

#from mnist import MNIST
from sklearn.utils import shuffle
import matplotlib.pyplot as plt
#from sklearn.utils import Bunch
import ml_util as util

data_dir = '../data/mldata'
mnist = util.fetch_mnist(data_dir)
print('type of mnist: ', type(mnist))
print('mnist: ', mnist)

data, y  = shuffle(mnist.data, mnist.target, random_state=0)
print('type of data:', type(data), ' shape of data:', data.shape)
print('type of y:',type(y), ' shape of y:', y.shape)
print('data:', data, '\ndata[0]', data[0], '\ny', y)

def check_mnist_data (data, y, N):
    N_max = len(data)
    print(N_max)
    for k in range(N):
        index = random.randint(1, N_max)
        image = data[index].reshape(28, 28)
        target = y [index]
    
        plt.subplot(5, 20, k + 1)
        plt.axis('off')
        plt.title('%i' % target, color='red')
        plt.imshow(image, cmap='Greys', interpolation = 'nearest')
    
    plt.show()

check_mnist_data (data, y, 100)
