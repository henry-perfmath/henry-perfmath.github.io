import matplotlib.pyplot as plt
import time
from collections import OrderedDict
from sklearn.ensemble import RandomForestClassifier
#from sklearn.datasets import fetch_mldata
from sklearn.model_selection import train_test_split

from sklearn.utils import shuffle
import numpy as np

import ml_util as util

data_dir = '../data/mldata'
mnist = util.fetch_mnist(data_dir)
#my_data_home = '/Users/henryliu/mspc/ml_dev/ml_quantitative/data'
#mnist = fetch_mldata('MNIST original', data_home=my_data_home)

start0 = time.time()
data, target  = shuffle(mnist.data/255, mnist.target, random_state=0)

n = data.shape[0]
n = 20000
X, y = data[0:n], target[0:n]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.5, random_state=np.random.RandomState (None))

# NOTE: Setting the `warm_start` construction parameter to `True` disables
# support for parallelized ensembles but is necessary for tracking the OOB
# error trajectory during training.
ensemble_clfs = [("RFC, max_features='sqrt'", RandomForestClassifier(warm_start=True, 
     oob_score=True, max_features="sqrt", random_state=None)),
    ("RFC, max_features='log2'", RandomForestClassifier(warm_start=True, max_features='log2',
     oob_score=True, random_state=None)),
    ("RFC, max_features=None", RandomForestClassifier(warm_start=True, max_features=None,
     oob_score=True, random_state=None))
]

# Map a classifier name to a list of (<n_estimators>, <error rate>) pairs.
error_rate = OrderedDict((label, []) for label, _ in ensemble_clfs)

# Range of `n_estimators` values to explore.
min_estimators = 50
max_estimators = 200
start = time.time()
for label, clf in ensemble_clfs:
    for i in range(min_estimators, max_estimators + 1, 10):

        clf.set_params(n_estimators=i)
        clf.fit(X, y)

        # Record the OOB error for each `n_estimators=i` setting.
        oob_error = 1 - clf.oob_score_
        error_rate[label].append((i, oob_error))
print("total time:", str(int(time.time() - start)))
# Generate the "OOB error rate" vs. "n_estimators" plot.
for label, clf_err in error_rate.items():
    xs, ys = zip(*clf_err)
    plt.plot(xs, ys, label=label)

plt.xlim(min_estimators, max_estimators)
plt.ylim(0., 1.5 * np.max(ys))
plt.xlabel("n_estimators")
plt.ylabel("OOB derived generalization error rate")
plt.legend(loc="best", frameon=False)
plt.show()
