As of September 16, 2020, the samples for this book have been upgraded and tested with the the following configurations:

1. macOS Catalina Version 10.15.4
2. Eclipse Version 2020-06 (4.16.0)
3. PyDev version 7.7.0.202008021154
4. Python 3.8.5
5. matplotlib 3.3.1
6. numpy 1.19.1
7. pandas 1.1.1
8. scikit-learn 0.23.2
9. scipy 1.5.2

Those three png files in the install dir show how Eclipse, PyDev and Python3.8 were installed and configured on author's Macbook Pro. If needed, you can find instructions online on how to install Eclipse, PyDev and Python3.8 on your env. 

In case you encounter issues, here are some tips:

(1) You can start with PyDev_on_macOS_1.png, and click the underlined link "Click here to confiure an interpreter not listed."
(2) Then click "Choose from list" on the right-most panel to select python3.8 installed on your env, as shown in python3.8_config_for_PyDev_on_Eclipse_macOS_2.png.
(3) Then, verify by referring to python3.8_with_PyDev_on_Eclipse_3.png.

Note that this initial setup process could be very frustrating due to many very fluid parts. If you encounter difficulties, either search online or contact the author who had gone through similar diffculties as well.
