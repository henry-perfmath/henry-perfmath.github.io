import numpy as np
import matplotlib.pyplot as plt
x = np.linspace(-10, 10, 500)
#plt.plot (x, np.exp(-0.01*x*x), label = r'$\gamma=0.01$')
plt.plot (x, np.exp(-0.1*x*x), label = r'$\gamma=0.1$')
plt.plot (x, np.exp(-1.0*x*x), label = r'$\gamma=1.0$')
plt.plot (x, np.exp(-10.0*x*x), label = r'$\gamma=10.0$')
plt.plot (x, np.exp(-100.0*x*x), label = r'$\gamma=100.0$')
plt.legend(loc='best', frameon=False)
plt.xlabel ('x')
plt.ylabel ('Radial basis function (RBF)')
plt.xlim (-10, 12)
plt.show()
