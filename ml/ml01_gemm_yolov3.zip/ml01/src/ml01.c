/*
 ============================================================================
 Name        : ml01.c
 Author      : henry
 Version     :
 Copyright   : machine learning 01
 Description : Hello gemm in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "gemm.h"
#include <Accelerate/Accelerate.h>
#include <assert.h>

/*
[ 0.11 0.12 0.13 ]  [ 11 12 ]     [ 7.76 8.12 ]
[ 0.21 0.22 0.23 ]  [ 21 22 ]  =  [ 4.06 4.72 ]
                    [ 31 32 ]
*/
void demo () {
	puts("Hello, gemm!!!");
	int m = 2, k = 3, lda = 3;
	float a[] = { 0.11, 0.12, 0.13,
				  0.21, 0.22, 0.23 };

	int n = 2, ldb = 2;
	float b[] = { 11, 12,
	              21, 22,
	              31, 32 };
	int ldc = 2;
	float c[] = { 1000.00, 1000.00,
	              1000.00, 1000.00 };

	puts("print array a ...");
	for (int i = 0; i < m; i++)
		for (int j = 0; j < k; j++)
			printf ("%i, %i, %g\n", i, j, a[i*lda +j]);

	puts("\nprint array b ...");
	for (int i = 0; i < k; i++)
		for (int j = 0; j < n; j++)
			printf ("%i, %i, %g\n", i, j, b[i*ldb +j]);

	// "0, 0" means no transpose
    gemm(0, 0, 2, 2, 3, 1.0, a, 3, b, 2, 1, c, 2);

	puts("\nprint array c ...");
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			printf ("%i, %i, %g\n", i, j, c[i*ldc +j]);
	printf ("\narray c in matrix format:\n[ %g, %g\n", c[0], c[1]);
	printf ("  %g, %g ]\n", c[2], c[3]);
}

void init_array (float *c, int N) {
	for (int i = 0; i < N; i++) {
		c[i] = 0.0;
	}
}

void gemm_test (int m, int k, int n, int lda, int ldb, int ldc, float alpha, float beta, int iter) {
	puts("\ngemm_test ...");
	float *a = random_matrix (m, k);
	float *b = random_matrix (k, n);
	float *c = random_matrix (m, n);
	float *c1 = malloc (m*n*sizeof(float));
	memcpy(c1, c, m*n*sizeof(float));

	for (int i = 0; i < m * n; i++)
		assert (c[i] == c1[i]);
	printf("c == c1 after memcpy\n");

    clock_t start = clock(), end;
    for (int i = 0; i < iter; i++) {
    		//init_array(c, m*n);
    		gemm(0, 0, m, n, k, alpha, a, m, b, k, beta, c, n);
    }

    double flop = ((double)m)*n*(2.*k + 2.)*iter;
    double gflop = flop/pow(10., 9);
    end = clock();
    double seconds = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("gemm: Matrix Multiplication %dx%d * %dx%d: %lf s, %lf GFLOPS\n",m,k,k,n, seconds, gflop/seconds);

	puts("\nprint array c (partial) from gemm_test ...");
	for (int i = 0; i < 2; i++)
		for (int j = 0; j < 2; j++)
			printf ("%i, %i, %lf\n", i, j, c[i*ldc +j]);


	start = clock();
    for (int i = 0; i < iter; i++) {
    		//init_array(c1, m*n);
    		cblas_sgemm(101, 111,111, m, n, k, alpha, a, lda, b, ldb, beta, c1, ldc);
    }

    end = clock();
    seconds = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("cblas_gemm: Matrix Multiplication %dx%d * %dx%d: %lf s, %lf GFLOPS\n",m,k,k,n, seconds, gflop/seconds);

	puts("\nprint array c (partial) from gemm_test ...");
	for (int i = 0; i < 2; i++)
		for (int j = 0; j < 2; j++)
			printf ("%i, %i, %lf\n", i, j, c1[i*ldc +j]);

	/* c and c1 are not exactly the same
	for (int i = 0; i < m * n; i++) {
		printf ("%i, %lf, %lf\n", i, c[i], c1[i]);
		assert (c[i] == c1[i]);
	}
	*/
	printf("Passed\n");
    free(a), free(b), free(c), free(c1);
}
int main(int argc, char *argv[]) {
	int m = 2, k = 3, n = 2;
	int lda = k, ldb = n, ldc = n;
	int iter = 10;
	float alpha = 1.0, beta = 1.0;
	//demo();

    for (int i = 0; i < argc; ++i)
        printf("%i: %s ", i, argv[i]);

	if (argc == 5) {
		m = atoi(argv[1]);
		k = atoi(argv[2]);
		n = atoi(argv[3]);
		iter = atoi(argv[4]);
	} else {
		m = 64, k = 64, n = 64, iter = 10;
	}

	lda = k, ldb = n, ldc = n;
	gemm_test(m, k, n, lda, ldb, ldc, alpha, beta, iter);
	return EXIT_SUCCESS;
}
