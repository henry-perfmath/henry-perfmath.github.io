//
//  NTPAddNewNoteItemViewController.h
//  NoteApp
//
//  Created by Henry Liu on 7/21/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NTPNoteItem.h"

@interface NTPAddNewNoteItemViewController : UIViewController
@property NTPNoteItem *noteItem;
@end
