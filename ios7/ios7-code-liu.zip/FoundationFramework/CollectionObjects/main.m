//
//  main.m
//  CollectionObjects
//
//  Created by Henry Liu on 7/23/14.
//
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // 1 creating a dictionary with different types of objects
        NSNumber *myIntValue = @99;
        NSString *cString = [NSString stringWithCString:"Hello, iOS!" encoding:NSUTF8StringEncoding];
        id aStringObject = @"Hello, OS X";
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                    myIntValue, @"myIntValueObj",
                                    cString, @"cStringObj",
                                    aStringObject, @"aStringObj",
                                    nil];
        
        // 2 enumerating the dictionary
        NSLog(@"There are %ld objects in the dictionary", [dictionary count]);
        for (id key in dictionary) {
            NSLog(@"object: %@ - key: %@", dictionary[key], key);
        }
        
        // 3 querying the dictionary
        NSLog (@"querying the dictionary:");
        id dictionaryElement = [dictionary objectForKey:@"aStringObj"];
        NSLog (@"a dictionary object: %@", dictionaryElement);
        
        // 4 removing an object and then querying the dictionary
        NSMutableDictionary *mutableDictionary = [NSMutableDictionary dictionaryWithDictionary:dictionary];
        NSLog (@"removing an object and then querying the dictionary:");
        [mutableDictionary removeObjectForKey:@"aStringObj"];
        dictionaryElement = [mutableDictionary objectForKey:@"aStringObj"];
        NSLog (@"a dictionary object: %@", dictionaryElement);
        
    }
    return 0;
}

