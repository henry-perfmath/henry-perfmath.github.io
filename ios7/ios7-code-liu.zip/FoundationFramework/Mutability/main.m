//
//  main.m
//  Mutability
//
//  Created by Henry Liu on 7/23/14.
//
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // 1 creating a mutableArray
        NSMutableArray *mutableArray = [NSMutableArray array];
        [mutableArray addObject:@"Orange"];
        [mutableArray addObject:@"Apple"];
        [mutableArray addObject:@"Peach"];
        
        NSLog (@"\nmutableArray before modifying:");
        for (id obj in mutableArray) {
            NSLog (@"%@", obj);
        }
        
        // 2 replacing an item in mutableArray
        NSLog (@"\nmutableArray after modifying:");
        [mutableArray replaceObjectAtIndex:0 withObject:@"kiwi"];
        for (id obj in mutableArray) {
            NSLog (@"%@", obj);
        }
        
        // 3 sorting the mutableArray
        NSLog (@"\nmutableArray after sorting:");
        [mutableArray sortUsingSelector:@selector(caseInsensitiveCompare:)];
        for (id obj in mutableArray) {
            NSLog (@"%@", obj);
        }
        
    }
    return 0;
}

