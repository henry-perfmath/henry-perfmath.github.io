//
//  main.m
//  ValueObjects
//
//  Created by Henry Liu on 7/23/14.
//
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // example 1: NSNumber
        int num1= 10;
        NSNumber *numObject = [NSNumber numberWithInt: num1];
        int x = [numObject intValue];
        
        if ( x == num1) {
            NSLog (@" num1 and x are equal");
        } else {
           NSLog (@" num2 and x are not equal");
        }
        // example 2: alloc, init and assigning a value all in one
        NSNumber *myIntValue = @99;
        NSLog (@"%i", myIntValue.intValue);
        
        // example 3: NSInteger
        NSInteger num2 = 20;
        numObject = [NSNumber numberWithInteger: num2];
        int y = [numObject integerValue];
       
        NSInteger z =[numObject integerValue];
        
        if ( y == num2) {
            NSLog (@" num2 and y are equal");
        } else {
            NSLog (@" num2 and y are not equal");
        }
        
        // example 4: NSString
        NSString *string1 = [NSString string];
        string1 = @"Hello";
        NSLog (@"string1: %@", string1);
        
        NSString *string2 = [NSString stringWithFormat: @", iOS!"];
        NSLog (@"string2: %@", string2);
        
        NSString *string3 = @"Have fun!";
        NSLog (@"string3: %@", string3);
        
    }
    return 0;
}

