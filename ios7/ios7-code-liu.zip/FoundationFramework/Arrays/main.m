//
//  main.m
//  Arrays
//
//  Created by Henry Liu on 7/23/14.
//
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // creating an array with different types of objects
        NSNumber *myIntValue = @99;
        NSString *cString = [NSString stringWithCString:"Hello, iOS!" encoding:NSUTF8StringEncoding];
        id aStringObject = @"Hello, OS X";
        NSArray *array = [NSArray arrayWithObjects:myIntValue, cString, aStringObject, nil];
        
        int count = [array count];
        
        // accessing array elements using subscript index
        for (int i = 0; i < count; i++) {
            NSLog (@" i = %i: %@", i, array [i]);
        }
        
        // accessing array elements using defined method
        for (int i = 0; i < count; i++) {
            NSLog (@" i = %i: %@", i, [array objectAtIndex:i]);
        }
        
        // sorting array
        NSArray *unsortedArray = @[cString, aStringObject];
        NSArray *sortedArray = [unsortedArray sortedArrayUsingSelector:@selector(compare:)];
        
        NSLog (@"sorted array:");
        for (id stringObject in sortedArray) {
            NSLog (@"string object: %@", stringObject);
        }
    }
    return 0;
}

