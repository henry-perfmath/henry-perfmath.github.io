//
//  NTPDetailViewController.h
//  NoteApp-iPhone-I
//
//  Created by Henry Liu on 8/6/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NTPNoteItem.h"

@interface NTPDetailViewController : UIViewController
@property int currentRowIndex;

@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *saveButton;
@property  NTPNoteItem *noteItem;
@property (strong, nonatomic) id detailItem;

@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;
@end
