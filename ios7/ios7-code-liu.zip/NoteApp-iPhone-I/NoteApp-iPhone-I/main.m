//
//  main.m
//  NoteApp-iPhone-I
//
//  Created by Henry Liu on 8/6/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "NTPAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([NTPAppDelegate class]));
    }
}
