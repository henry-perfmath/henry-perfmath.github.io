//
//  NTPDetailViewController.m
//  NoteApp-iPhone-I
//
//  Created by Henry Liu on 8/6/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import "NTPDetailViewController.h"

@interface NTPDetailViewController ()
- (void)configureView;
@end

@implementation NTPDetailViewController
@synthesize textView = _textView;
@synthesize textField = _textField;
@synthesize noteItem;

#pragma mark - Managing the detail item

- (void)setDetailItem:(id)newDetailItem
{
    if (_detailItem != newDetailItem) {
        _detailItem = newDetailItem;
        
        // Update the view.
        [self configureView];
    }
}

- (void)configureView
{
    // Update the user interface for the detail item.

    if (self.detailItem) {
        self.detailDescriptionLabel.text = [self.detailItem description];
        NTPNoteItem *item = [[NTPNoteItem alloc] init];
        item = _detailItem;
        self.textView.text = item.content;
        self.textField.text = item.itemName;
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self configureView];
    //self.currentRowIndex = -1;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if (sender != self.saveButton) return;
    if (self.textField.text.length > 0) {
        NSLog (@"text field length is not zero");
        self.noteItem = [[NTPNoteItem alloc] init];
        self.noteItem.itemName = self.textField.text;
        self.noteItem.content = self.textView.text;
        NSLog (@" itemName = %@ 2 %@", self.noteItem.itemName, self.textField.text);
    } else {
        NSLog (@"text field length is zero");
    }
}

- (IBAction)saveButton:(id)sender {
}
@end
