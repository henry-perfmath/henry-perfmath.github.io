//
//  NTPMasterViewController.m
//  NoteApp-iPhone-I
//
//  Created by Henry Liu on 8/6/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import "NTPMasterViewController.h"
#import "NTPDetailViewController.h"
#import "NTPNoteItem.h"
#import "NTPAppDelegate.h"

@interface NTPMasterViewController () {
    NSMutableArray *_objects;
}
@property NSMutableArray *noteItems;
@end

@implementation NTPMasterViewController
- (IBAction) unwindToMasterView:(UIStoryboardSegue *)segue {
    NSLog (@"Got back from detail view controller");
    NTPDetailViewController *source = [segue sourceViewController];
    NTPNoteItem *item = source.noteItem;
  
    if (item != nil) {
    int index = source.currentRowIndex;
    NSLog (@"save item from detail view: %@ %@ %i", item.itemName, item.content, index);
    if (source.currentRowIndex < 0) {
        [self.noteItems addObject:item];
        // add item
        NSLog (@"added item: %@", item.itemName);
        [self.itemNames addObject:item.itemName];
        [self.itemContents addObject:item.content];
        // persist to CD
        //[self saveData: item];
    } else {
        [self.noteItems replaceObjectAtIndex:index withObject:item];
        [self.itemNames replaceObjectAtIndex:index withObject:item.itemName];
        [self.itemContents replaceObjectAtIndex:index withObject:item.content];
    }
        [self saveData: item];
	[(UITableView*)self.view reloadData];
        //[self.noteItems addObject:item];
        NSLog (@"added item: %@", item.itemName);
    } else {
        NSLog (@"No item returned");
    }
    
}
- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.navigationItem.leftBarButtonItem = self.editButtonItem;
/*
    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(insertNewObject:)];
    self.navigationItem.rightBarButtonItem = addButton;
 */
    self.noteItems = [[NSMutableArray alloc] init];
    [self loadInitialData];
}
- (void) loadInitialData
{
    // load initial data using core Data
    NTPAppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    
    NSManagedObjectContext *context = [appDelegate managedObjectContext];
    NSEntityDescription *entityDesc = [NSEntityDescription entityForName:@"Notes" inManagedObjectContext:context];
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setEntity:entityDesc];
    
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"(itemName != %@)", nil];
    [request setPredicate:pred];
    
    NSError *error;
    NSArray *objects = [context executeFetchRequest:request error:&error];
    if ([objects count] == 0) {
        NSLog (@"No matches");
    } else {
        NSLog (@"%lu matches found", (unsigned long) [objects count]);
    }
    _itemNames = [[NSMutableArray alloc] init];
    _itemContents = [[NSMutableArray alloc] init];
    for (NSManagedObject *item in objects) {
        NTPNoteItem *newItem = [[NTPNoteItem alloc] init];
        newItem.itemName = [item valueForKey:@"itemName"];
        newItem.content = [item valueForKey:@"content"];
        [self.noteItems addObject:newItem];
        NSLog (@"added item: %@ %@", newItem.itemName, newItem.content);
        [self.itemNames addObject:newItem.itemName];
        [self.itemContents addObject:newItem.content];
    }
}

- (void) saveData: (NTPNoteItem *)item
{
    NTPAppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    
    NSManagedObjectContext *context = [appDelegate managedObjectContext];
    NSManagedObject *newNote;
    newNote = [NSEntityDescription insertNewObjectForEntityForName:@"Notes" inManagedObjectContext:context];
    [newNote setValue: item.itemName forKey: @"itemName"];
    [newNote setValue: item.content forKey: @"content"];
    
    NSError *error;
    [context save: &error];
    NSLog (@"context saved");
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)insertNewObject:(id)sender
{
    if (!_objects) {
        _objects = [[NSMutableArray alloc] init];
    }
    [_objects insertObject:[NSDate date] atIndex:0];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //return _objects.count;
    return [self.noteItems count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ListPrototypeCell" forIndexPath:indexPath];

    //NSDate *object = _objects[indexPath.row];
    //cell.textLabel.text = [object description];
    NTPNoteItem * item = [self.noteItems objectAtIndex:indexPath.row];
    cell.textLabel.text = item.itemName;
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        NSLog (@"delete at index %i", indexPath.row);
        
        NTPNoteItem *item = [self.noteItems objectAtIndex:indexPath.row];
        
        [self.noteItems removeObjectAtIndex:indexPath.row];
        [self.itemNames removeObjectAtIndex:indexPath.row];
        [self.itemContents removeObjectAtIndex:indexPath.row];
        
        
        // Delete the row from the data source
        NTPAppDelegate *appdelegate = [[UIApplication sharedApplication] delegate];
        NSManagedObjectContext *context = appdelegate.managedObjectContext;
        NSEntityDescription *entityDesc = [NSEntityDescription entityForName:@"Notes" inManagedObjectContext:context];
        
        NSFetchRequest *request = [[NSFetchRequest alloc] init];
        [request setEntity:entityDesc];
        
        NSLog (@"Search for %@", item.itemName);
        NSPredicate *pred = [NSPredicate predicateWithFormat:@"(itemName = %@)", item.itemName];
        [request setPredicate:pred];
        
        NSError *error;
        NSArray *objects = [context executeFetchRequest:request error:&error];
        NSLog (@"found %i items", [objects count]);
        for (NSManagedObject *item in objects) {
            NTPNoteItem *newItem = [[NTPNoteItem alloc] init];
            newItem.itemName = [item valueForKey:@"itemName"];
            //[self.noteItems addObject:newItem];
            NSLog (@"found item: %@", newItem.itemName);
        }
        
        [context deleteObject:objects[0]];
        
        [context save:&error];
        
        // Animate the deletion
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];

        /*
        [_objects removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
         */
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }
}

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"showDetail"]) {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        NTPNoteItem *item = [[NTPNoteItem alloc] init];
        item.itemName = self.itemNames [indexPath.row];
        item.content = self.itemContents [indexPath.row];
        [[segue destinationViewController] setDetailItem:item];
        [[segue destinationViewController] setCurrentRowIndex:indexPath.row];
    } else if ([[segue identifier] isEqualToString:@"addItem"]) {
        NTPNoteItem *item = [[NTPNoteItem alloc] init];
        item.itemName = @"New Item ID";
        item.content = @"content for new item";
        [[segue destinationViewController] setDetailItem:item];
        [[segue destinationViewController] setCurrentRowIndex:-1];
    }
}

@end
