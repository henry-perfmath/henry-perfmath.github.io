//
//  NTPCDViewController.h
//  NTPCoreData
//
//  Created by Henry Liu on 7/31/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NTPCDAppDelegate.h"

@interface NTPCDViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextView *note;
- (IBAction)saveData:(id)sender;
- (IBAction)findNote:(id)sender;

@end
