//
//  main.m
//  Files
//
//  Created by Henry Liu on 7/26/14.
//
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        // for measuring end to end time
        clock_t start, end;
        double elapsed;
        start = clock();

        // 1. get the shared file manager object
        NSFileManager *fileMgr = [NSFileManager defaultManager];
        
        // 2. read data of a file in its entirety into an NSData object
        NSData *data = [fileMgr contentsAtPath: @"/Users/henry/mydev/workspace/ios7/DiskCheck/ioTest1.txt"];
        
        // 3. write data of a file in its entirety to a file
        [fileMgr createFileAtPath:@"/Users/henry/mydev/workspace/ios7/DiskCheck/ioTmp.txt" contents:data attributes:nil];
        
        end = clock();
        elapsed = ((double) (end - start)) / CLOCKS_PER_SEC;
        NSLog(@"Time: %f",elapsed);
        
        // 4. use NSFileHandle to read a file block by block
        NSFileHandle *file = [NSFileHandle fileHandleForReadingAtPath:@"/Users/henry/mydev/workspace/ios7/DiskCheck/ioTest1.txt"];
        if (file == nil)
            NSLog (@"Cannot open file for read");
        
        int bufferSize = 513;
        // 5. read the file with a fixed buffer size into an NSData object
        data = [file readDataOfLength: bufferSize];
        
        // 6. Copy data from an NSData object to an NSString object
        NSString *aStr = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
        NSLog(@"%@",aStr);
        
        // 7. Tokenize the NSString line by line into an NSArray
        NSArray *tokens = [aStr componentsSeparatedByString: @"\n"];
        int n = (int) [tokens count];
        for (int i = 0; i < n; i++) {
            if (i < 3) NSLog (@"%i: %@", i, tokens[i]);
        }
        NSLog (@"n = %i", n);
        
        // 8. close the file handle
        [file closeFile];
    }
    return 0;
}

