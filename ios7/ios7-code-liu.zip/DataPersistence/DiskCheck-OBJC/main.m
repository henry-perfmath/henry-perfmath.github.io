//
//  main.m
//  DiskCheck-OBJC (1st param: inputFileName, 2nd param: buffersize in bytes)
//  bufferSize = 50,000 optimal
//  Created by Henry Liu on 7/29/14.
//
//

#import <Foundation/Foundation.h>
#include <mach/mach_time.h>

// functions must be declared first to avoid error "Conflicting types for ..."
NSString *getFileNamePostFix (); // calls getStartTimeInSeconds for a postfix
int getElapsedTimeInMS (uint64_t start, uint64_t end); // for timing code execution using mac_absolute_time
int getStartTimeInSeconds (); // relative to local w/o hard-coding a timezon
NSString *getLocalTime (); // local with format including ms
NSDate *currentDateTime (); // hard-coded PST

void readWriteTest (NSString *fileName, int bufferSize);
NSArray* getLines (NSFileHandle *fileHandle, int offset, int bufferSize);

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSLog (@"current time: %@", getLocalTime ());
        
        // extract fileName, bufferSize and call readWriteMethod
        NSString *fileName = [NSString stringWithUTF8String: argv [1]];
        NSString *bufferSizeStr = [NSString stringWithUTF8String: argv [2]];
        NSNumber *bufferSize = [NSNumber numberWithInteger:[bufferSizeStr intValue]];
        readWriteTest (fileName, bufferSize.intValue);
    }
    return 0;
}

void readWriteTest (NSString *fileName, int bufferSize) {
    // for calculating total execution time
    clock_t start, end;
    double elapsed;
    start = clock();
    
    // use NSFileHandle to read a file
    NSFileHandle *fileHandleIn = [NSFileHandle fileHandleForReadingAtPath:fileName];
    if (fileHandleIn == nil) {
        NSLog (@"Cannot open file %@ for read", fileName);
        exit (1);
    }
    
    // get file size
    NSNumber * fileSize = [NSNumber numberWithUnsignedLongLong:[[[NSFileManager defaultManager] attributesOfItemAtPath:fileName error:nil] fileSize]];
    int inputFileSize = [fileSize intValue];
    
    // construct output file handle
    NSString *outFileName = [NSString stringWithFormat:@"%@%@%@", fileName, @"_", getFileNamePostFix()];
    // must create the output file first
    [[NSFileManager defaultManager] createFileAtPath:outFileName contents:nil attributes:nil];
    
    NSFileHandle *fileHandleOut = [NSFileHandle fileHandleForUpdatingAtPath:outFileName];
    NSData *outData; // for writeData
    
    //int bufferSize = 50000;
    int offset = 0;
    
//    NSFileManager *fileMgr = [NSFileManager defaultManager];
    BOOL eof = false;
    uint64_t        startRead;
    uint64_t        endRead;
    int totalReadTime = 0;
    
    uint64_t        startWrite;
    uint64_t        endWrite;
    int totalWriteTime = 0;
    int numOfLines = 0;
    int writeOffset = 0;
    do {
        if (offset < inputFileSize) {
            //NSLog (@"offset = %i", offset);
            startRead = mach_absolute_time();
            NSArray *lines = getLines(fileHandleIn, offset, bufferSize);
            endRead = mach_absolute_time();
            totalReadTime += getElapsedInMS(startRead, endRead);
            int lineCount = (int) [lines count] - 1;

            for (int i = 0; i < lineCount - 1; i++)
            {
                // timing read operations
                startRead = mach_absolute_time();
                NSString* line = lines [i];
                endRead = mach_absolute_time();
                totalReadTime += getElapsedTimeInMS(startRead, endRead);
                numOfLines++;
                
                // do not use NSMutable data
                
                //outData = [NSMutableData dataWithContentsOfFile: line];
                outData = [line dataUsingEncoding:NSUTF8StringEncoding];
               // NSLog (@"out data: %@)", outData);
                
                // timing write operation (seek and write)
                startWrite = mach_absolute_time();
                [fileHandleOut seekToFileOffset:writeOffset ];
                // do not use writeTofile
                //[line writeToFile:outFileName atomically:YES encoding:NSUTF8StringEncoding error:nil];
                [fileHandleOut writeData: outData];
                writeOffset += outData.length;
                endWrite = mach_absolute_time();
                totalWriteTime += getElapsedTimeInMS(startWrite, endWrite);
            }
            int lastLineSize = (int) ((NSString *)lines [lineCount]).length;
            offset += bufferSize - lastLineSize; // subtract lastLineSize to discount partial line
        } else {
            eof = true;
        }
    } while (!eof);

    end = clock();
    elapsed = ((double) (end - start)) / CLOCKS_PER_SEC;
    // report throughput numbers
    NSLog (@"Total Time: %f",elapsed);
    NSLog (@"test data file size = %f MB", (double) (inputFileSize * 0.000001));
    NSLog (@"Total number of lines: %i", numOfLines);
    NSLog (@"total read time = %i ms", totalReadTime);
    NSLog (@"read throughput on this drive = %i MB/second", (int) (inputFileSize * 0.001) / totalReadTime);
    NSLog (@"total write time = %i ms", totalWriteTime);
    NSLog (@"write throughput on this drive = %i MB/second", (int) (inputFileSize * 0.001) / totalWriteTime);
    // close file handles
    [fileHandleIn closeFile];
    [fileHandleOut closeFile];
    
}
NSArray* getLines (NSFileHandle *fileHandle, int offset, int bufferSize) {
    // seek and read using a data buffer
    [fileHandle seekToFileOffset: offset];
    NSData *dataBuffer = [fileHandle readDataOfLength: bufferSize];
    NSString *block = [[NSString alloc] initWithData:dataBuffer encoding:NSASCIIStringEncoding];
    NSArray *tokens = [block componentsSeparatedByString: @"\n"]; // tokenizing for lines

    return tokens;
}
// Get current date/time, format is YYYY-MM-DD.HH:mm:ss GMT
NSDate *currentDateTime() {
    NSDate *now = [NSDate date];
    NSDate *current = [now dateWithCalendarFormat:@"%Y-%m-%d %H:%M:%S %z"
                                 timeZone:[NSTimeZone timeZoneWithName:@"PST"]];
    
    return current;
}
// get current local time with ms
NSString *getLocalTime ()
{
    NSDate *currentDate = [[NSDate alloc] init];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd' 'HH:mm:ss.SSS'Z'"];
    NSString *localDateString = [dateFormatter stringFromDate:currentDate];
    
    return localDateString;
}
int getStartTimeInSeconds () {
    // get current date, timezone and interval from GMT
    NSDate *now = [NSDate date];
    NSTimeZone *zone = [NSTimeZone systemTimeZone]; // local timezone
    NSInteger interval = [zone secondsFromGMTForDate:now];
    //NSDate *startDate = [now addTimeInterval:interval]; //deprecated
    
    // return start time in seconds - used as a postfix for creating a new output file
    int startTime = [now timeIntervalSince1970] + interval; //
    NSLog(@"start time in seconds: %d",startTime);

    return startTime;
}
int getElapsedTimeInMS (uint64_t start, uint64_t end) {
    //uint64_t        start;
    //uint64_t        end;
    
    //  start = mach_absolute_time();
    //  code to execute
    //  end = mach_absolute_time();
    //  NSLog (@"%llu %llu %llu ", start, end);
    
    return (int) (end - start)*0.000001;
}
NSString *getFileNamePostFix () {
    // convert an int to NSString using new literal syntax
    //NSString *fileNamePostFix = [@(getStartTimeInSeconds()) stringValue];
	NSString *fileNamePostFix = [NSString stringWithFormat:@"%i", getStartTimeInSeconds()];
	return fileNamePostFix;
}



