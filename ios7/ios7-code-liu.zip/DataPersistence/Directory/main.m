//
//  main.m
//  Directory
//
//  Created by Henry Liu on 7/26/14.
//
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // find the Documents Directory
        
        NSArray *dirPaths;
        NSString *docDir;
        dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentationDirectory, NSUserDomainMask, YES);
        docDir = dirPaths [0];
        
        NSLog (@"docsDir = %@", docDir);
        for (NSString *dir in dirPaths)
            NSLog (@"dir: %@", dir);
        
        // find the current working directory
        NSFileManager *fileMgr;
        fileMgr = [NSFileManager defaultManager];
        NSString *currentPath = [fileMgr currentDirectoryPath];
        
        NSLog (@"current dir = %@", currentPath);
        
        // find the tmp directory
        NSString *tmpDir = NSTemporaryDirectory();
        
        NSLog (@"tmp dir = %@", tmpDir);
        
        // list contentes of a dir
        NSArray *fileList;
        
        //fileMgr = [NSFileManager defaultManager];
        fileList = [fileMgr contentsOfDirectoryAtPath:currentPath error:NULL];
        for (NSString *file in fileList)
            NSLog (@"file: %@", file);
        for (int i = 0; i < [fileList count]; i++)
            NSLog (@"file %i: %@", (i + 1), fileList[i]);
        
    }
    return 0;
}

