//
//  HLOViewController.m
//  Hello-iOS
//
//  Created by Henry Liu on 6/30/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import "HLOViewController.h"

@interface HLOViewController ()

@end

@implementation HLOViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
