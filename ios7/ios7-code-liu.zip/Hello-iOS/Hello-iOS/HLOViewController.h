//
//  HLOViewController.h
//  Hello-iOS
//
//  Created by Henry Liu on 6/30/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HLOViewController : UIViewController

@end
