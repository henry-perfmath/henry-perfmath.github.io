//
//  NTPNoteItem.h
//  NoteApp
//
//  Created by Henry Liu on 7/24/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NTPNoteItem : NSObject

@property NSString *itemName;
@property NSString *username;
@property NSString *password;
@property NSString *url;
@property (readonly) NSData *creationDate;
@property BOOL completed;

- (void) markAsCompleted : (BOOL) isCompleted;
@end
