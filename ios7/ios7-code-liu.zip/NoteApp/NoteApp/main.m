//
//  main.m
//  NoteApp
//
//  Created by Henry Liu on 7/7/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "NTPAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([NTPAppDelegate class]));
    }
}
