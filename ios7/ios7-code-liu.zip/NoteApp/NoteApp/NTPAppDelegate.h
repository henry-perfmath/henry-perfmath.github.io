//
//  NTPAppDelegate.h
//  NoteApp
//
//  Created by Henry Liu on 7/7/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NTPAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
