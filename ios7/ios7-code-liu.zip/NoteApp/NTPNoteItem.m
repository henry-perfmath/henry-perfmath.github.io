//
//  NTPNoteItem.m
//  NoteApp
//
//  Created by Henry Liu on 7/24/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import "NTPNoteItem.h"

@interface NTPNoteItem ()

@property NSDate *completionDate;

@end

@implementation NTPNoteItem


- (void) markAsCompleted : (BOOL) isComplete {
    self.completed = isComplete;
    [self setCompletionDate];
}
- (void) setCompletionDate {
    if (self.completed) {
        self.completionDate = [NSDate date];
    } else {
        self.completionDate = nil;
    }
}
@end
