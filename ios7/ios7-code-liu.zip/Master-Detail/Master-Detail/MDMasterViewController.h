//
//  MDMasterViewController.h
//  Master-Detail
//
//  Created by Henry Liu on 8/4/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MDDetailViewController;

@interface MDMasterViewController : UITableViewController

@property (strong, nonatomic) MDDetailViewController *detailViewController;

@end
