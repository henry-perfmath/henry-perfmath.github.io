//
//  main.m
//  SavingsAccount
//
//  Created by Henry Liu on 7/15/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SavingsAccount.h"
#import "XAccount+TxOps.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        SavingsAccount *account;
        
        account = [SavingsAccount alloc];
        account = [account init];
        
        [account setAccountId: 123456788 andStatus: 1];
        [account setBalance: 500];
        [account setInterestRate: 0.01];
        
        [account showAccountInfo];
        
        NSLog (@"Account ID %li , Balance %f.", account.accountId,
               account.balance);
        
        [account deposit : 100];
        
        [account showAccountInfo];
        
    }
    return 0;
}

