//
//  XAccount+TxOps.m
//  Categories
//
//  Created by Henry Liu on 7/18/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//
#import "XAccount+TxOps.h"

@implementation XAccount (TxOps)
//@synthesize accountId, status, balance;
- (void) deposit:(double)d
{
    self.balance = self.balance + d;
}
- (void) debit:(double)d
{
    self.balance = self.balance - d;
}
@end
