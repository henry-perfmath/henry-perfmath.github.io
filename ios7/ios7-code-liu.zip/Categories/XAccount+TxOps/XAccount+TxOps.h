//
//  XAccount+TxOps.h
//  Categories
//
//  Created by Henry Liu on 7/18/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XAccount.h"

@interface XAccount (TxOps)
- (void) deposit: (double) d;
- (void) debit: (double) d;
@end
