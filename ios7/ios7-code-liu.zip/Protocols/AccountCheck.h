//
//  AccountCheck.h
//  Protocols
//
//  Created by Henry Liu on 7/18/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol AccountCheck <NSObject>

- (void) lockAccount : (XAccount *) a;

@end
