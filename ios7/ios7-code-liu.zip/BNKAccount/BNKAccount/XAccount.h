//
//  XAccount.h
//  BNKAccount
//
//  Created by Henry Liu on 7/15/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XAccount : NSObject

@property long accountId;
@property double balance;
@property int status;

- (void) setAccountId : (long) i andStatus : (int) s;
- (void) showAccountInfo;
- (void) deposit: (double) d;

@end
