//
//  SavingsAccount.m
//  BNKAccount
//
//  Created by Henry Liu on 7/15/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import "SavingsAccount.h"

@implementation SavingsAccount
@synthesize interestRate;
- (void) showAccountInfo
{
    NSLog (@"account id:  %li balance: %f status: %i interest rate: %f", super.accountId, super.balance, super.status, self.interestRate);
}
@end
