//
//  SavingsAccount.h
//  BNKAccount
//
//  Created by Henry Liu on 7/15/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import "XAccount.h"

@interface SavingsAccount : XAccount
@property double interestRate;
@end
