//
//  Account.h
//  Account
//
//  Created by Henry Liu on 7/11/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Account : NSObject
{
    long accountId;
    double balance;
    int status;
}
- (long) getAccountId;
- (void) setAccountId : (long) i;

- (double) getBalance;
- (void) setBalance : (double) b;

- (int) getStatus;
- (void) setStatus : (int) s;

- (void) setAccountId : (long) i andStatus : (int) s;
- (void) showAccountInfo;
- (void) deposit: (double) d;

@end
