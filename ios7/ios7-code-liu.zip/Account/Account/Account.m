//
//  Account.m
//  Account
//
//  Created by Henry Liu on 7/11/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import "Account.h"

@implementation Account

- (long) getAccountId
    {
        return accountId;
    }
- (void) setAccountId : (long) i
    {
        accountId = i;
    };
    
    - (double) getBalance
    {
        return balance;
    };
- (void) setBalance : (double) b
    {
        balance = b;
    };
    
- (int) getStatus
    {
        return status;
    };
    - (void) setStatus : (int) s
    {
        status = s;
    }
    
- (void) setAccountId : (long) i andStatus : (int) s
    {
        accountId = i;
        status = s;
    };
- (void) deposit:(double)d
{
    balance = balance + d;
    //[self setBalance: (balance + d)];
}
- (void) showAccountInfo
    {
        NSLog (@"account id:  %li balance: %f status: %i ", accountId, balance, status);
    }

@end
