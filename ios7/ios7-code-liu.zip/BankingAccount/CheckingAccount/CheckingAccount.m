//
//  CheckingAccount.m
//  BankingAccount
//
//  Created by Henry Liu on 7/15/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import "CheckingAccount.h"

@implementation CheckingAccount
- (void) deposit:(double)d
{
    self.balance = self.balance + d - self.processingFee;
}
- (void) showAccountInfo
{
    NSLog (@"account id:  %li balance: %f status: %i processing fee: %f", super.accountId, super.balance, super.status, self.processingFee);
}
@end
