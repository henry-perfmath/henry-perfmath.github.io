//
//  CheckingAccount.h
//  BankingAccount
//
//  Created by Henry Liu on 7/15/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import "Account.h"

@interface CheckingAccount : Account
@property double processingFee;
@end
