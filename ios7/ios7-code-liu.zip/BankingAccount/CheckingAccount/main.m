//
//  main.m
//  CheckingAccount
//
//  Created by Henry Liu on 7/15/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CheckingAccount.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        CheckingAccount *account;
        
        account = [CheckingAccount alloc];
        account = [account init];
        
        [account setAccountId: 123456788 andStatus: 1];
        [account setBalance: 500];
        [account setInterestRate: 0.01];
        [account showAccountInfo];
        
        NSLog (@"Account ID %li , Balance %f, and Interest Rate %f", account.accountId,
               account.balance, account.interestRate);
        
        [account deposit : 100];
        
        [account showAccountInfo];
        
    }
    return 0;
}

