//
//  main.m
//  AccountTest
//
//  Created by Henry Liu on 7/16/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SavingsAccount.h"
#import "CheckingAccount.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        SavingsAccount *saveingsAccount;
        saveingsAccount = [[SavingsAccount alloc] init];
        
        [saveingsAccount setAccountId: 123456788 andStatus: 1];
        [saveingsAccount setBalance: 500];
        [saveingsAccount setInterestRate: 0.01];
        
        //savingsAccount deposit & showAccountInfo
        [saveingsAccount deposit : 100];
        [saveingsAccount showAccountInfo];
        
        CheckingAccount *checkingAccount;
        checkingAccount = [[CheckingAccount alloc] init];
        
        [checkingAccount setAccountId: 123456789 andStatus: 1];
        [checkingAccount setBalance: 900];
        [checkingAccount setProcessingFee: 5.0];
        
        //checkingAccount deposit & showAccountInfo
        [checkingAccount deposit: 50];
        [checkingAccount showAccountInfo];
    }
    return 0;
}

