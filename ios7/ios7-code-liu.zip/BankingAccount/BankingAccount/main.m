//
//  main.m
//  BankingAccount
//
//  Created by Henry Liu on 7/15/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Account.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        
        Account *account;
        
        account = [Account alloc];
        account = [account init];
        
        [account setAccountId: 123456789 andStatus: 1];
        [account setBalance: 500];
        
        [account showAccountInfo];
        
        NSLog (@"Account ID %li , Balance %f.", account.accountId,
               account.balance);
        
        [account deposit : 100];
        
        [account showAccountInfo];
        
    }
    return 0;
}

