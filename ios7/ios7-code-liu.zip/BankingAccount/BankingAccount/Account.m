//
//  Account.m
//  BankingAccount
//
//  Created by Henry Liu on 7/15/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import "Account.h"

@implementation Account
@synthesize accountId, status, balance;
- (void) setAccountId : (long) i andStatus : (int) s
{
    accountId = i;
    status = s;
};
- (void) deposit:(double)d
{
    balance = balance + d;
}
- (void) showAccountInfo
{
    NSLog (@"account id:  %li balance: %f status: %i ", accountId, balance, status);
}
@end
