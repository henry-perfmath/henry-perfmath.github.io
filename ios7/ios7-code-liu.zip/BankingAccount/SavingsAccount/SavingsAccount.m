//
//  SavingsAccount.m
//  BankingAccount
//
//  Created by Henry Liu on 7/16/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import "SavingsAccount.h"

@implementation SavingsAccount
@synthesize interestRate;
- (void) showAccountInfo
{
    NSLog (@"account id:  %li balance: %f status: %i interest rate: %f", self.accountId, self.balance, self.status, self.interestRate);
}
@end
