//
//  SavingsAccount.h
//  BankingAccount
//
//  Created by Henry Liu on 7/16/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import "Account.h"

@interface SavingsAccount : Account
@property double interestRate;
@end
