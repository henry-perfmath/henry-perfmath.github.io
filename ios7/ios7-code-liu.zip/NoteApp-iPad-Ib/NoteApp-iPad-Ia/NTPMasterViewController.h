//
//  NTPMasterViewController.h
//  NoteApp-iPad-Ia
//
//  Created by Henry Liu on 8/4/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NTPDetailViewController.h"

@class NTPDetailViewController;

@interface NTPMasterViewController : UITableViewController <NTPDetailViewControllerDelegate>

@property (nonatomic, retain) NSMutableArray *itemNames;
@property (nonatomic, retain) NSMutableArray *itemContents;

@property (strong, nonatomic) NTPDetailViewController *detailViewController;

@end
