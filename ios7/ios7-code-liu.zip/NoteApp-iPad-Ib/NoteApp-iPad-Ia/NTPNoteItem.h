//
//  NTPNoteItem.h
//  NoteApp-iPad-Ib
//
//  Created by Henry Liu on 8/5/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NTPNoteItem : NSObject
@property NSString *itemName;
@property NSString *content;
@end
