//
//  NTPDetailViewController.h
//  NoteApp-iPad-Ia
//
//  Created by Henry Liu on 8/4/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol NTPDetailViewControllerDelegate <NSObject>
-(void)saveItemRequest:(id)itemToSave; // delegate method
@end
@class NTPDetailViewController;

@interface NTPDetailViewController : UIViewController <UISplitViewControllerDelegate>
//{
//    id <NTPDetailViewControllerDelegate> delegate;
//}
@property (nonatomic, strong) id <NTPDetailViewControllerDelegate> delegate;

@property int currentRowIndex;
@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (weak, nonatomic) IBOutlet UIButton *saveButton;

@property (strong, nonatomic) id detailItem;
- (IBAction)saveData:(id)sender;

@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;

@end
