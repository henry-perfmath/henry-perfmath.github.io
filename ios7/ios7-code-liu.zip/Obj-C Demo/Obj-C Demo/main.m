//
//  main.m
//  Obj-C Demo
//
//  Created by Henry Liu on 7/11/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        
        int numOfLoops;
        NSLog (@"Enter the number of loops:\n");
        scanf ("%i", &numOfLoops);
        
        for (int i = 0; i < numOfLoops; i++) {
            NSLog (@"Loop # %i", i);
        }
        
    }
    return 0;
}

