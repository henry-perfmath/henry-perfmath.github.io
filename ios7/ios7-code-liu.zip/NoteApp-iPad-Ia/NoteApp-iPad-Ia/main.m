//
//  main.m
//  NoteApp-iPad-Ia
//
//  Created by Henry Liu on 8/4/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "NTPAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([NTPAppDelegate class]));
    }
}
