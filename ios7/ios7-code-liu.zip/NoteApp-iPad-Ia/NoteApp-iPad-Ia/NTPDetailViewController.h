//
//  NTPDetailViewController.h
//  NoteApp-iPad-Ia
//
//  Created by Henry Liu on 8/4/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NTPDetailViewController : UIViewController <UISplitViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@property (strong, nonatomic) id detailItem;

@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;
@end
