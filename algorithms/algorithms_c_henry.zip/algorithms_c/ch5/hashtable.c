/*
 * hashtable_demo0.c
 *
 *  Created on: Feb 14, 2018
 *      Author: henry
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "hashtable.h"
/*
 const int TABLE_CAPACITY = 5;

 typedef struct entry {
 int key;
 int value;
 struct entry *next;
 } Entry;

 // a hash list is a linear list indexed with hash values of the entries
 typedef struct table{
 int capacity;
 struct entry **hash_list;
 } Table;
 */
Table *init(int capacity)
{
	Table *tbl = (Table *) malloc(sizeof(Table));
	tbl->capacity = capacity;
	//printf("sizeof(Entry) = %lu, sizeof(Entry *) = %lu\n", sizeof(Entry), sizeof(Entry *));
	tbl->hash_list = (Entry **) malloc(sizeof(Entry *) * capacity); // should be sizeof(Entry *), not sizeof(Entry)

	for (int i = 0; i < capacity; i++)
		tbl->hash_list[i] = NULL;
	return tbl;
}

void put(Table *table, int key, int value)
{
	// 1. check if the new entry already exists
	int hash = (key % TABLE_CAPACITY);
	Entry *curr = table->hash_list[hash];
	Entry *cursor = curr;
	while (cursor)
	{
		if (cursor->key == key)
		{
			cursor->value = value;  // 2. update
			return;
		}
		//break if reached the end of the list
		if (cursor->next == NULL)
			break;
		cursor = cursor->next;
	};

	Entry *new_entry = (Entry *) malloc(sizeof(Entry));
	new_entry->key = key;
	new_entry->value = value;
	new_entry->next = NULL;

	//2. check if the first at the hashed cell
	if (curr == NULL)
	{
		table->hash_list[hash] = new_entry;
		return;
	}

	// 3a. put at the end of the hashed list
	//cursor->next = new_entry;

	// 3b. put at the front
	new_entry->next = curr;
	table->hash_list[hash] = new_entry;
}

int get(const Table *table, int key)
{
	int hash = (key % TABLE_CAPACITY);
	Entry *cursor = table->hash_list[hash];
	while (cursor)
	{
		if (cursor->key == key)
		{
			return cursor->value;
		}
		cursor = cursor->next;
	}
	return -1;
}

int delete(Table *table, int key)
{
	int hash = (key % TABLE_CAPACITY);
	Entry *cursor = table->hash_list[hash];

	if (cursor == NULL)
		return 0;

	if (cursor->key == key)
	{
		table->hash_list[hash] = cursor->next;
		free(cursor);
		return 1;
	}

	Entry *prev = cursor;
	cursor = cursor->next;
	while (cursor)
	{
		if (cursor->key == key)
		{
			prev->next = cursor->next;
			free(cursor);
			return 1;
		}
		prev = cursor;
		cursor = cursor->next;
	}
	return 0;
}

// all key-value pairs hashed into the same bucket
int get_all_by_hash(const Table *table, int key)
{
	int hash = (key % TABLE_CAPACITY);
	Entry *cursor = table->hash_list[hash];
	while (cursor)
	{
		printf("(%d, %d) ", cursor->key, cursor->value);
		cursor = cursor->next;
	}
	putchar('\n');
	return -1;
}

void delete0(Table *table)
{
	Entry *cursor = *table->hash_list;
	int count = 0;
	while (cursor)
	{
		Entry *psave_next = cursor->next;
		count++;
		printf("delete count = %d\n", count);
		free(cursor);
		cursor = psave_next;
	}
	free(table);
}

void clear(Table *table)
{
	for (int i = 0; i < table->capacity; i++)
	{
		Entry *head = table->hash_list[i];
		int count = 0;
		while (head)
		{
			Entry *p_save = head->next;
			free(head);
			count++;
			//printf("delete i = %d count = %d\n", i, count);
			head = p_save;
		}
	}

	free(table);
}
/*
 int main() {
 unsigned int cycle;
 //unsigned int max_cycles = 500000000;
 unsigned int max_cycles = 10;
 int test_key = 3;
 int test_value;
 long start, end;

 int cache_size = 10;
 start = clock() * 1000 / CLOCKS_PER_SEC;
 cycle = 1;
 Table *hash_table = init(TABLE_CAPACITY);

 while (cycle < max_cycles) {
 for (int i = 0; i < cache_size; i++) {
 put(hash_table , i * cycle, 100 * i * cycle);
 }
 cycle++;
 }
 // retrieve from cache
 test_value = get(hash_table , test_key);
 printf("key = %d: retrieved value = %d\n", test_key, test_value);
 get_all_by_hash(hash_table, 3);
 //delete0(hash_table);
 if (delete(hash_table, test_key)) {
 printf("detete %d successful\n", test_key);
 } else {
 printf("detete %d not found\n", test_key);
 }
 clear(hash_table);
 end = clock() * 1000 / CLOCKS_PER_SEC;
 printf("table time: %d\n", (int) (end - start));

 return 0;

 }
 */
