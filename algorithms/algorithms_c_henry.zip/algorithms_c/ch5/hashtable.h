#ifndef _HASH_TABLE_H
#define _HASH_TABLE_H
//#define TABLE_CAPACITY 101
#define TABLE_CAPACITY 2069

typedef struct entry
{
	int key;
	int value;
	struct entry *next;
} Entry;

// a hash list is a linear list indexed with hash values of the entries
typedef struct table
{
	int capacity;
	struct entry **hash_list;
} Table;
#endif

Table *init(int capacity);
int get(const Table *table, int key);
void put(Table *table, int key, int value);
int delete(Table *table, int key);
void clear(Table *table);
