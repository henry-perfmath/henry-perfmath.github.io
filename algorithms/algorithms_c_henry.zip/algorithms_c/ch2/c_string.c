/*
 * c_string.c
 *
 *  Created on: Jan 15, 2019
 *      Author: henryliu
 */

#include <stdio.h>
#include <string.h>

int main() {
	char str1[256] = "hello, ";
	char str2[] = "world!";
	char *str3 = " again!";

	printf("%s %s\n", str1, str2);

	strcat(str1, str2);
	printf("%s\n", str1);

	strcat(str1, str3);
	printf("%lu %s\n", strlen(str1), str1);

	//char str4[] = strdup("strdup to c string");
	char *str4 = strdup("strdup to c string");
	printf("%s\n", str4);

	str4[0] = 'S';
	printf("%s\n", str4);

	str1[0] = 'H';
	printf("%s\n", str1);

	str2[0] = 'W';
	printf("%s\n", str2);
}
