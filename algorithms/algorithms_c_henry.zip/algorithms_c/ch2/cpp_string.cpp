/*
 * cpp_string.cpp
 *
 *  Created on: Jan 14, 2019
 *      Author: henryliu
 */

#include <iostream>
#include <string>

using namespace std;

int main () {

   string str1 = "This is ";
   string str2 = "a test";
   string str3;
   int  len ;

   // copy string via assignment
   str3 = str1;
   cout << "str3 : " << str3 << endl;

   // concatenates two strings
   str3 = str1 + str2;
   cout << "str1 + str2 : " << str3 << endl;

   // find the length of a string
   len = str3.size();
   cout << "str3.size() :  " << len << endl;

   return 0;
}
