/*
 * test_mersort.c
 *
 *  Created on: Jan 5, 2019
 *      Author: henryliu
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

const int MAX_ARRAY_SIZE = 10;

int cmp_func(const void *a, const void *b) {
	return (*(int *) a - *(int *)b);
}
void print_array (int a[]) {
	for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
		(i < (MAX_ARRAY_SIZE - 1)) ? printf("%d ", a[i]) : printf("%d \n", a[i]);
	}
}

int main() {
	srand(time(NULL));
	int a[MAX_ARRAY_SIZE];
	for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
		a[i] = rand() % 30;
		(i < (MAX_ARRAY_SIZE - 1)) ? printf("%d ", a[i]) : printf("%d \n", a[i]);
	}

	mergesort((int *)a, MAX_ARRAY_SIZE -1, sizeof(int), cmp_func);
	printf("after sorting:\n");

	print_array(a);
	/*
	for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
		(i < (MAX_ARRAY_SIZE - 1)) ? printf("%d ", a[i]) : printf("%d \n", a[i]);
	}
	*/
	return 0;
}
