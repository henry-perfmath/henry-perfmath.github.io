/*
 * qsort_items.c
 *
 *  Created on: Jan 1, 2019
 *      Author: henryliu
 */

#include <stdio.h>
#include <stdlib.h>

typedef struct item
{
	int idx;
	int count;
} Item;

int item_cmp_func(const void *a, const void *b)
{
	int a_idx = ((Item *) a)->idx;
	int b_idx = ((Item *) b)->idx;
	int a_count = ((Item *) a)->count;
	int b_count = ((Item *) b)->count;
	if (a_count == b_count)
		return b_idx - a_idx;
	else
		return b_count - a_count; // reverse for ascending order
}

void print_item_array(Item a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		printf("i = %d, idx = %d, count = %d\n", i, a[i].idx, a[i].count);
	}
}

int main()
{
	int idx[] = { 1, 2, 3, 5, 80 };
	int count[] = { 2, 2, 1, 3, 1 };
	int n = sizeof(idx) / sizeof(idx[0]);

	Item items[n];
	for (int i = 0; i < n; i++)
	{
		items[i].idx = idx[i];
		items[i].count = count[i];
	}

	qsort((Item *) items, n, sizeof(Item), item_cmp_func);

	printf("after sort_by_count:\n");
	print_item_array(items, n);
}
