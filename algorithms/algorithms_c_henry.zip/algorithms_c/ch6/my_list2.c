#include "my_list2.h"
#include <stdio.h>
#include <stdlib.h>

bool is_empty(const Node *list)
{
    return (list == NULL);
}

bool is_full()
{
	bool full;

	Node *node_ptr = (Node *) malloc(sizeof(Node));
    if (!node_ptr)
        full = true;
    else
        full = false;

    free(node_ptr);
    
    return full;
}

unsigned int length(const Node *list)
{
    unsigned int count = 0;

    while (list != NULL)
    {
        ++count;
        list = list->next;
    }
    
    return count;
}

Node *insert(Item item, Node *list)
{
    Node *new_node;
    new_node = (Node *) malloc(sizeof(Node));
    if (!new_node)
        return NULL;
    
    new_node->item = item;
    new_node->next = NULL;

    Node *cursor = list;
    if (cursor == NULL)
        list = new_node;
    else
    {
        while (cursor->next != NULL)
        		cursor = cursor->next;

        cursor->next = new_node;
    }
    
    return list;
}

// prev node is the new head
void reverse2(Node **head)
{
	Node *curr = *head;
	Node *prev = NULL;
	Node *next = NULL;

	while (curr != NULL)
	{
		next = curr->next; // take curr->next's data
		curr->next = prev; // point next to prev
		prev = curr;	   // take curr's data
		curr = next;	   // continue
	}

	*head = prev;
}

Node *reverse(Node *list)
{
	Node *curr = list;
	Node *prev = NULL;
	Node *next = NULL;

	while (curr != NULL)
	{
		next = curr->next;
		curr->next = prev;
		prev = curr;
		curr = next;
	}

	return prev;
}

void traverse(const Node *list, void (*func_ptr)(Item item))
{
    while (list != NULL)
    {
        (*func_ptr)(list->item);
        list = list->next;
    }
}

Node *clear(Node *list)
{
    Node *ptr_save;
    while (list != NULL)
    {
        ptr_save = list->next;
        printf("freeing %d\n", list->item.data);
        free(list);
        list = ptr_save;
    }
    return NULL;
}

Node *clear_circular(Node *list, int length)
{
    Node *ptr_save;
    int count = 0;
    while (count < length && list != NULL)
    {
        ptr_save = list->next;
        free(list);
        list = ptr_save;
        count++;
    }
    return NULL;
}
