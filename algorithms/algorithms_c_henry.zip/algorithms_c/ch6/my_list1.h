#ifndef LIST_H_
#define LIST_H_
#include <stdbool.h>

typedef struct item
{
    int data;
} Item;

typedef struct node
{
    Item item;
    struct node *next;
} Node;

// no need to define a List of Node *
bool is_empty(const Node **head);
bool is_full();
unsigned int length(const Node **head);
bool insert(Item item, Node **head);
void traverse(const Node **head, void (* func_ptr)(Item item) );

void clear(Node **head);
void clear_circular(Node **head, int length);
void clear_circular2(Node **head, int length);
#endif
