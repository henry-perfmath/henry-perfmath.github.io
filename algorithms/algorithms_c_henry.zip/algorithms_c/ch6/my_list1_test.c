#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "my_list1.h"

void display(Item item); // local

int main(void)
{
    Node *head = NULL;
    //const Node *head_const = (const Node *) head; // needs to assigned after the head is allocated memory

    Item temp;

    if (is_full ())
    {
        fprintf(stderr,"No memory available! Bye!\n");
        exit(1);
    }
    
    temp.data = 10;
    printf("insert %d\n", temp.data);
    insert(temp, &head);

    const Node *head_const = (const Node *) head;

    temp.data = 20;
    printf("insert %d\n", temp.data);
    insert(temp, &head);

    temp.data = 30;
    printf("insert %d\n", temp.data);
    insert(temp, &head);


    printf("current size of the head:  %d\n", length(&head_const));

    if (is_empty(&head_const))
        printf("No data entered. ");
    else
    {
        printf ("Contents of the data head: ");
        traverse(&head_const, display);
        printf ("\n");
    }

    clear_circular2(&head, 3);
    //clear(&head);
    if (head_const) {
    	printf("size of the head after calling clear:  %d\n", is_empty(&head_const));
    }
    return 0;
}

void display(Item item)
{
    printf("%d ", item.data);
}

