/*
 * bst.c
 *
 *  Created on: Feb 13, 2018
 *      Author: henryliu
 */

#include<stdio.h>
#include<stdlib.h>
#include "bst.h"


/* return the most immediate parent given two arbitrary child keys*/
int find_common_ancestor(Node* root, int left_key, int right_key)
{
	Node *cursor = root;
	while (cursor != NULL) {
		int curr_key = cursor->key;
		if (curr_key > left_key && curr_key > right_key)
			cursor = cursor->left;
		else if (curr_key < left_key && curr_key < right_key)
			cursor = cursor->right;
		else
			return curr_key;
	}
	return -1;
}

int main()
{
    Node *root = NULL;
    root = insert(root, 50);
    insert(root, 30);
    insert(root, 20);
    insert(root, 40);
    insert(root, 70);
    insert(root, 60);
    insert(root, 80);

    insert(root, 10);
    insert(root, 25);
    insert(root, 35);
    insert(root, 45);

    int common_ancestor = find_common_ancestor(root, 25, 35);
    printf("Found common ancestor = %d (-1 means not found)\n", common_ancestor);
    clear(root);
}
