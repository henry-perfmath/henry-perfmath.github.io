/*
 * bst.c
 *
 *  Created on: Feb 13, 2018
 *      Author: henryliu
 */
#include<stdio.h>
#include<stdlib.h>
#include "bst.h"

Node *make_node(int key)
{
    Node *temp =  (Node *)malloc(sizeof(Node));
    temp->key = key;
    temp->left = temp->right = NULL;
    return temp;
}

void preorder(Node *node)
{
    if (node != NULL)
    {
        printf("%d ", node->key);
        preorder(node->left);
        preorder(node->right);
    }
}

void inorder(Node *node)
{
    if (node != NULL)
    {
        inorder(node->left);
        printf("%d ", node->key);
        inorder(node->right);
    }
}

void postorder(Node *node)
{
    if (node != NULL)
    {
        postorder(node->left);
        postorder(node->right);
        printf("%d ", node->key);
    }
}

Node *insert(Node *node, int key)
{
    /* empty tree case */
    if (node == NULL) return make_node(key);

    /* non-empty tree case */
    if (key < node->key)
    	node->left = insert(node->left, key);
    else if (key > node->key)
    	node->right = insert(node->right, key);

   	return node;
}

void clear (Node *node)
{
    if(node != NULL)
    {
        clear(node->left);
        clear(node->right);
        free(node);
    }
}

