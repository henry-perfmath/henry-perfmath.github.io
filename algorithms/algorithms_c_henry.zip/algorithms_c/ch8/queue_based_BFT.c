#include <stdio.h>
#include "bst.h"
#include "bst_queue.h"

void bft(Node *root)
{
	Queue queue;
	init(&queue);

	Node *node = root;
	enqueue(*node, &queue);
	while (!is_empty(&queue))
	{
		dequeue(node, &queue);
		printf("%d (%d) \n", node->key, queue.length);
		if (node->left)
			enqueue(*node->left, &queue);
		if (node->right)
			enqueue(*node->right, &queue);
	}
}

int main()
{
	Node *root = NULL;
	root = insert(root, 50); // first call must return root

	insert(root, 30);
	insert(root, 20);
	insert(root, 40);
	insert(root, 70);
	insert(root, 60);
	insert(root, 80);

	insert(root, 15);
	insert(root, 25);
	// print depth_first_Traversal traversal of the BST
	printf("inorder... ");
	inorder(root);
	printf("\npreorder... ");
	preorder(root);
	printf("\npostorder... ");
	postorder(root);
	printf("\nqueue-based BFT ... \n");
	bft(root);
	printf("\nclear ... ");

	clear(root);
	return 0;
}
