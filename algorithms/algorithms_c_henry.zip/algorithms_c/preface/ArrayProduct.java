package algorithms_java;

import java.util.Arrays;

public class ArrayProduct {
	private static int[] arrayProducts(int[] a) {
		int n = a.length;
		int[] b = new int[n];
			
		int sub = 1;
		for (int i = 1; i < n; i++) {
			sub *= a[i - 1];
			b[i] = sub;
		}
		
		b[0] = 1;	
		sub = 1;
		for (int i = n - 1; i > 0; i--) {
			sub *= a[i];
			b[i - 1] *= sub;
		}
		
		return b;		
	}
	
	public static void main(String[] args) {
		int[] a = {1, 2, 3, 4, 5, 6, 7, 8, 9};
		int n = a.length;
		int[] result = new int[n];
		int N = 10000000;

		long start = System.currentTimeMillis();
		
		for (int i = 0; i < N; i++)
			result = arrayProducts(a);
		
		float totalTime = (float) (System.currentTimeMillis() - start) / 1000;
		System.out.println("duration = " + totalTime);
		System.out.println(Arrays.toString(result));		
	}
}
