#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int min (int a, int b) {
	return (a < b) ? a: b;
}
int get_min_weight (int a[], int level, int *idx) {
	int idx1 = *idx + level;
	int idx2 = idx1 + 1;
	int min_weight = a[idx1];
	*idx = idx1;
	if (a[idx1] > a[idx2]) {
		min_weight = a[idx2];
		*idx = idx2;
	}
	printf("level = %d, min_weight_value = %d\n", level, a[*idx]);
	return min_weight;
}
int find(int n, int a[]) {

	int count = 1;
	int min_weight = a[0];
	int levels = sqrt(2 * n);
	int level = 1;
	int idx = 0;
	printf("level = %d, min_weight_value = %d\n", level, a[idx]);
	while (level < levels) {
		//int next_idx = idx + level;
		min_weight += get_min_weight(a, level, &idx);
		level++;
	}
	return min_weight;
}

void test1() {
	int a[] = {2, 4, 4, 8, 5, 6, 4, 2, 6, 2, 1, 5, 2, 3, 4};
	int n = sizeof(a) / sizeof(a[0]);
	printf("Found min weight = %d\n", find(n, a));
}

int main() {
	test1();
}
