#include <stdio.h>
#include <stdlib.h>

int cmp_func(const void *a, const void *b) {
	return (*(int *)a - *(int *)b);
}

void find_triplets(int a[], int n, int k)
{
    // 1. sort the array
    qsort(a, n, sizeof(a[0]), cmp_func);

    // 2.a for loop
    for (int i = 0; i < n - 1; i++) {
        // initialize start and end
        //int x = a[i];
        int start = i + 1;
        int end = n - 1;
        // 2.b while loop
        while (start < end) {
        	int sum = a[i] + a[start] + a[end];
            if (sum == k) {
                printf("%d %d %d\n", a[i], a[start], a[end]);
                // return here if only one triplet is needed
                start++;
                end--;
            } else if (sum < k)
                start++;
            else
                end--;
        }
    }
}
void test1() {
    int a[] = { 1, 4, 45, 6, 10, 8, 12, 0, 16 };
    int k = 22;
    int n = sizeof(a) / sizeof(a[0]);
    find_triplets(a, n, k);
}
void test2() {
    int a[] = { 0, -1, 2, -3, 1 };
    int k = -2;
    int n = sizeof(a) / sizeof(a[0]);
    find_triplets(a, n, k);
}
int main()
{
    test1();
    test2();
    return 0;
}
