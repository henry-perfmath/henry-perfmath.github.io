#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// must have the semi-colon for the last attribute
typedef struct pair {int task1; int task2;} Pair;

int cmp_func(const void *a, const void *b) {
	return (*(int *)a - *(int *)b);
}

// Pair[] is not valid. Use pointer
Pair *pairing_tasks (int a[], int n) {
	int num_pairs = n / 2;
	Pair *task_pairs =(Pair *) malloc(num_pairs * sizeof(Pair));;

	qsort(a, n, sizeof(a[0]), cmp_func);

	for (int i = 0; i < n / 2; i++) {
		task_pairs [i].task1 = a[i];
		task_pairs [i].task2 = a[n - 1 - i];
		printf("paired %d with %d\n", a[i], a[n - 1 -i]);
	}
	return task_pairs;
}

void test1() {
	int a[] = {5, 2, 1, 6, 4, 4};
	int n = sizeof(a) / sizeof(a[0]);
	int num_pairs = n / 2;
	Pair *task_pairs;
	task_pairs = pairing_tasks (a, n);
	for (int i = 0; i < num_pairs; i++) {
		printf(">>paired %d with %d\n", task_pairs[i].task1, task_pairs[i].task2);
	}
	free(task_pairs);
}

int main() {
	test1();
}
