#include <stdio.h>
int fibonacci( int n) {
	if (n <= 1) {
		return n;
	}

	int f_minus_2 = 0, f_minus_1 = 1, f;
	for (int i = 2; i <=n; ++i) {
		f = f_minus_2 + f_minus_1;
		f_minus_2 = f_minus_1;
		f_minus_1 = f;
	}
	return f;
}

int main() {
	int n = 11; // 89
	printf("fibonacci(%d): %d\n", n, fibonacci(n));
}

