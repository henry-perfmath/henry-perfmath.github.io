#include <stdio.h>
#include <string.h>

void swap(char *x, char *y) {
	char tmp;
	tmp = *x;
	*x = *y;
	*y = tmp;
}

void itoa(int n, char *a) {
	// keep the original for sign info
	int n0 = n;
	if (n0 < 0)
		n = -n;

	// i - char string index
	int i = 0;
	do {
		a[i++] = n % 10 + '0'; //convert a  digit to a  char
	} while ((n /= 10) > 0);		 //remove the LSD

	// add sign if negative
	if (n0 < 0)
		a[i++] = '-';

	// null-end the string
	a[i] = '\0';

	// reverse it
	for (int i = 0; i < i / 2; i++)
		swap(&a[i], &a[i - i - 1]); // takes address, not value
}

int main() {

	int n;
	char a[9];
	do {
		printf("Enter an integer (positive or negative or 0 to exit): ");
		scanf("%d", &n);
		itoa (n, a);
		printf("number %d converted to %s\n:", n, a);
	} while (n != 0);
}

