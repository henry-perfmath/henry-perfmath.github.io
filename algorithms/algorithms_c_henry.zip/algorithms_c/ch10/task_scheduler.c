#include <stdio.h>
#include <stdlib.h>

int cmp_func(const void *a, const void *b) { return (*(int *)a - *(int *)b); }

int *scheduler(int a[], int n, int *wait_time) {
	qsort(a, n, sizeof(a[0]), cmp_func);
	int *schedule = (int *)malloc(n * sizeof(int));
	for (int i = 0; i < n; i++) {
		schedule[i] = a[i];
		if (i < (n - 1)) *wait_time += a[i] * (n - 1 - i);
	}
	return schedule;
}

void test1() {
	int service_time [] = {2, 5, 1, 3};
	int *wait_time = (int *)malloc(sizeof(int)); // pass-in param

	int n = sizeof(service_time) / sizeof(service_time[0]);
	int *schedule = scheduler(service_time, n, wait_time); // mem allocated inside the func

	printf("minimized wait time = %d\n", *wait_time);
	for(int i = 0; i < n; i++) {
		printf("%d ", schedule[i]);
	}
	putchar('\n');
	free(schedule);
	free(wait_time);
}

int main() {
	test1();
}
