#include <stdio.h>
#include "max_heap.h"
#define MAX_CAPACITY 100
//int heap[MAX_CAPACITY ] = {150, 80, 40, 30, 10, 70, 110, 100, 20, 90, 60, 50, 120, 140, 130}; // remaining set to 0's
int heap[MAX_CAPACITY ] = {15, 150, 80, 40, 30, 60, 70, 110, 100, 20, 90, 10, 50, 120, 140, 130}; // remaining set to 0's
int main() {

	//build_max_heap(heap);
	int k = 5;
	int heap_size = heap[0];
	heap[0] = k;
	heapify (heap); //heapify an array initialized at the start
	print_heap(heap, "initial: ");
	for (int i = k + 1; i <= heap_size; i++) {
		int kth_smallest = get_max(heap);
		if (kth_smallest > heap[i]) {
			delete_max(heap);
			insert(heap, heap[i]);
		}
	}
	print_heap(heap, "kth smallest heap:");
	printf("kth smallest element = %d\n", get_max(heap));
}
