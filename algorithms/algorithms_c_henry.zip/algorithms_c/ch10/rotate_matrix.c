#include <stdio.h>
#define N 4

void print_matrix(int n, int a[n][n]) {
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++)
			printf("%d ", a[i][j]);
		putchar('\n');
	}
}

void rotate_matrix (int offset, int n, int a[n][n]) {
	if (n % 2 == 0 && offset >= n / 2) return;
	if (n % 2 == 1 && offset > n / 2) return;

	// save last column
	int tmp[n - offset];
	for (int i = offset; i < n - offset ; i++) {
		tmp[i - offset] = a[i][n - 1 - offset];
	}

	int i, j;
	// rotate 1st row to last column
	for (j = n - 1 - offset; j >= offset; j--) {
		a[j][n - offset - 1] = a[offset][j];
	}

	// rotate 1st column to 1st row
	for (i = offset; i < n - offset; i++) {
		//printf("%d ", a[i][n - offset - 1]);
		a[offset][n - 1 - i] = a[i][offset];
	}

	//rotate last row to 1st column
	for (j = offset; j < n - offset; j++) {
		a[j][offset] = a[n - 1 - offset][j];
	}

	// rotate last column to last row
	for (i = n - 1 - offset; i > offset; i--) {
		a[n - 1 - offset][n - 1 - i] = tmp[i- offset];
	}

	putchar('\n');
	offset++;
	rotate_matrix(offset, n, a);
}

void test1() {
	int n = 3;
	int a[3][3] = {{1, 2, 3}, {4, 5, 6}, {7,8, 9}};
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			printf("%d ", a[i][j]);
	putchar('\n');
	rotate_matrix(0, n, a);
	print_matrix(n, a);
}
void test2() {
	int n = N;
	int a[N][N] = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 16}};
	putchar('\n');
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			printf("%d ", a[i][j]);
	putchar('\n');
	rotate_matrix(0, N, a);
	print_matrix(N, a);
}

int main() {
	test1();
	test2();
}
