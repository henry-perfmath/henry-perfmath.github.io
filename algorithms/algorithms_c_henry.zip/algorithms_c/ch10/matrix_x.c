#include <stdio.h>

void matrix_multiply(int M, int K, int N, int A[M][K], int B[K][N], int C[M][N])
{
	printf("M K N: %d, %d, %d\n", M, K, N);
    int i, j, k;
    for (i = 0; i < M; i++)
    {
        for (j = 0; j < N; j++)
        {
            //C[i][j] = 0;
            for (k = 0; k < K; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

void test1() {
	int M = 2, K = 3, N = 2;

	int A[2][3] = {{1, 2, 3}, {4, 5, 6}};
	int B[3][2] = {{7, 8}, {9, 10}, {11, 12}};
	int C[2][2] = {[0 ... 1] = {[0 ... 1] = 0}};

    matrix_multiply (M, K, N, A, B, C);

    // C = 58, 64, 139, 154
    for (int i = 0; i < M; i++) {
		putchar('\n');
    	for (int j = 0; j < N; j++)
    		printf("%d ", C[i][j]);
    }
    putchar('\n');
}

int main()
{
	test1();
}
