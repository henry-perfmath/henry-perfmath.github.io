#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct city {
	char symbol;
	int gas;
	int miles;
	float remaining_gas;
} City;

int cmp_func (const void *a, const void *b) {
	const City	*x = a;
	const City	*y = b;
	return y->remaining_gas - x->remaining_gas;
}

int find_city(City *cities, int n, int start_idx) {
	int count = 0;
	float curr_gas = 0;
	int idx = start_idx;
	while (count < n) {
		idx = (count + start_idx) % n;
		curr_gas = curr_gas + cities[idx].remaining_gas;
		if (curr_gas < 0) return curr_gas;
		count++;
	}
	return curr_gas;
}

void test1() {
	int num_cities = 7;
	City *cities = (City *)malloc(num_cities * sizeof(City));
	City cityA = {'A', 50, 900, 0.0};
	cities[0] = cityA;
	City cityB = {'B', 20, 600, 0.0};
	cities[1] = cityB;
	City cityC = {'C', 5, 200, 0.0};
	cities[2] = cityC;

	City cityD = {'D', 30, 400, 0.0};
	cities[3] = cityD;

	City cityE = {'E',25, 600, 0.0};
	cities[4] = cityE;

	City cityF = {'F', 10, 200, 0.0};
	cities[5] = cityF;
	City cityG = {'G', 10, 100, 0.0};
	cities[6] = cityG;

	for (int i = 0; i < num_cities; i++) {
		cities[i].remaining_gas = cities[i].gas - cities[i].miles / 20.0;
		printf("%c: %d %d %f\n", cities[i].symbol, cities[i].gas, cities[i].miles, cities[i].remaining_gas);
	}

	/*
	qsort(cities, num_cities, sizeof(City), cmp_func);

	for (int i = 0; i < num_cities; i++) {
		cities[i].remaining_gas = cities[i].gas - cities[i].miles / 20.0;
		printf("%c: %d %d %f\n", cities[i].symbol, cities[i].gas, cities[i].miles, cities[i].remaining_gas);
	}
A: 50 900 5.000000
B: 20 600 -10.000000
C: 5 200 -5.000000
D: 30 400 10.000000
E: 25 600 -5.000000
F: 10 200 0.000000
G: 10 100 5.000000
===================
D: 30 400 10.000000
A: 50 900 5.000000
G: 10 100 5.000000
F: 10 200 0.000000
C: 5 200 -5.000000
E: 25 600 -5.000000
B: 20 600 -10.000000
	*/
	/*
	int i = 0;
	float curr_gas = find_ample_city(cities, num_cities, 0);
			printf("city %c: gas at the end = %f\n", cities[i].symbol, curr_gas);
			*/

	//int start_idx = 0;
	for (int i = 0; i < num_cities; i++) {
		float curr_gas = find_city(cities, num_cities, i);
		printf("city %c: gas at the end = %f\n", cities[i].symbol, curr_gas);
	}
}

int main() {
	test1();
}
