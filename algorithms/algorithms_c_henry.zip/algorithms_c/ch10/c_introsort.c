/*
 * introsort2.c
 *
 *  Created on: Nov 30, 2018
 *  adapted from https://www.programmingalgorithms.com/algorithm/intro-sort?lang=C
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
const int MAX_ARRAY_SIZE = 10000;
void swap (int *x, int *y) {
	*x ^= *y;
	*y ^= *x;
	*x ^= *y;
}
void insertion_sort(int *a, int n) {
	for (int i = 1; i < n; ++i)
	{
		int j = i;

		while (j > 0)
		{
			if (a[j - 1] > a[j])
			{
				swap(&a[j], &a[j - 1]);
				--j;
			}
			else
			{
				break;
			}
		}
	}
}
/* Q: What are needed for the max_heapify function (signature?)
 * Find the largest among the parent and the two child nodes. If one of the
 * child nodes is the largest, swap it with the parent and heapify again with
 * the largest
 */
void max_heapify(int *a, int n, int p_idx) {
	int left = 2 * p_idx + 1;
	int right = 2 * p_idx + 2;
	int largest = p_idx;

	if (left < n && a[left] > a[p_idx])
		largest = left;
	if (right < n && a[right] > a[largest])
		largest = right;

	if (largest != p_idx)
	{
		swap(&a[p_idx], &a[largest]);
		max_heapify(a, n, largest);
	}
}
/*
 * What are input to the heap_sort function?
 */
void heap_sort(int *a, int n) {

	for (int p_idx = (n - 1) / 2; p_idx >= 0; --p_idx)
		max_heapify(a, n, p_idx);

	for (int i = n - 1; i > 0; --i)
	{
		swap(&a[0], &a[i]);
		--n;
		max_heapify(a, n, 0);
	}
}

int partition (int a[], int start, int end) {
	int pivot;
	if (start < end) {
		pivot = start;

		while (start < end) {
			while (a[start] <= a[pivot]) start++;
			while (a[end] > a[pivot]) end--;
			if (start < end) swap(&a[start], &a[end]);
		}
	}
	// at this point, a[right] <= a[pivot], so exchange them
	swap(&a[end], &a[pivot]);
	pivot = end;
	return pivot;
}

void quicksort(int *a, int start, int end) {
	if (start < end)
	{
		int q = partition(a, start, end);
		quicksort(a, start, q - 1);
		quicksort(a, q + 1, end);
	}
}

void intro_sort(int *a, int n) {
	int pivot_idx = partition(a, 0, n - 1);

	if (pivot_idx < 16)
	{
		insertion_sort(a, n);
	}
	else if (pivot_idx > (2 * log(n)))
	{
		heap_sort(a, n);
	}
	else
	{
		quicksort(a, 0, n - 1);
	}
}

void test1() {
	srand(time(0));
	int a[MAX_ARRAY_SIZE];
	for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
		a[i] = rand() % MAX_ARRAY_SIZE;
	}

	printf("before sorting:\n");
	int PRINT_LIMIT = 15;
	for (int i = 0; i <PRINT_LIMIT; i++) {
		(i < PRINT_LIMIT) ? printf("%d ", a[i]) : printf("%d \n", a[i]);
	}

	int n = a[0];
	int depth_limit = 2 * log2(n);
	printf("depth_limit = %d\n", depth_limit);
	intro_sort(a, n);

	printf("after sorting:\n");
	for (int i = 0; i <= PRINT_LIMIT; i++) {
		(i < PRINT_LIMIT) ? printf("%d ", a[i]) : printf("%d \n", a[i]);
	}
}

 int main() {
	test1();
}

