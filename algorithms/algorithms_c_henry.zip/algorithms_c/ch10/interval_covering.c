#include <stdio.h>
#include <stdlib.h>

typedef struct interval {
	int start;
	int end;
} Interval;

int cmp_func (const void *a, const void *b) {
	const Interval *x = a;
	const Interval *y = b;
	return (x->end - y->end);
}

void print_intervals(Interval *intervals, int n) {
	for (int i = 0; i < n; i++) {
		printf("i = %d: [%d, %d]\n", i, intervals[i].start, intervals[i].end);
	}
}
int *interval_covering(Interval *intervals, int n) {
	int *visit_times = (int *)malloc(n * sizeof(int));
	int k = 0;
	visit_times [k] = intervals[0].end; // select the 1st visit time

	for (int i = 1; i < n; i++)
		visit_times[i] = -1;

	qsort(intervals, n, sizeof(Interval), cmp_func); // sort by end time
	printf("\nafter sorting:\n");
	print_intervals(intervals, n);

	for (int i = 0; i < n; i++) {
		if(intervals[i + 1].start <= visit_times [k]) {
			continue; // ok if the next job already started before the current visit time
		} else { // if the next job has not started, that will be the next visit time
			k++;
			visit_times [k] = intervals[i + 1].start;
		}
	}

	return visit_times;
}

void test1() {
	int n = 4;
	Interval *intervals = (Interval *) malloc(n * sizeof(Interval));
	intervals[0].start = 0;
	intervals[0].end = 3;

	intervals[1].start = 2;
	intervals[1].end = 6;

	intervals[2].start = 3;
	intervals[2].end = 4;

	intervals[3].start = 6;
	intervals[3].end = 9;
	print_intervals(intervals, n);
	int *visit_times = interval_covering(intervals, n);

	printf("\nvisit times: ");
	for (int i = 0; i < n; i++)
		if (visit_times[i] > 0) printf("%d ", visit_times[i]);
	putchar('\n');
	free(visit_times);
}

void test2() {
	int n = 5;
	Interval *intervals = (Interval *) malloc(n * sizeof(Interval));
	intervals[0].start = 0;
	intervals[0].end = 3;

	intervals[1].start = 2;
	intervals[1].end = 6;

	intervals[2].start = 3;
	intervals[2].end = 4;

	intervals[3].start = 6;
	intervals[3].end = 9;

	intervals[4].start = 4;
	intervals[4].end = 5;

	print_intervals(intervals, n);
	int *visit_times = interval_covering(intervals, n);

	printf("\nvisit times: ");
	for (int i = 0; i < n; i++)
		if (visit_times[i] > 0) printf("%d ", visit_times[i]);
	putchar('\n');
	free(visit_times);
}

int main() {
	test1();
	test2();
}
