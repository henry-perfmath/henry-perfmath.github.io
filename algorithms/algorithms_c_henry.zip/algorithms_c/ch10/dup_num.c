#include <stdio.h>
#include <stdlib.h>

void print_duplicate(int a[], int n)
{
  int i;
  printf("The repeating elements are: \n");
  for (i = 0; i < n; i++)
  {
    if (a[abs(a[i])] >= 0)
      a[abs(a[i])] = -a[abs(a[i])];
    else
      printf(" %d ", abs(a[i]));
  }
  putchar('\n');
}

int main()
{
  int a[] = {1, 2, 1, 3, 4, 4, 5, 6, 7, 2, 1, 8, 3, 1, 3, 2, 10, 2, 4, 12};
  int n = sizeof(a)/sizeof(a[0]);
  print_duplicate(a, n);
  return 0;
}
