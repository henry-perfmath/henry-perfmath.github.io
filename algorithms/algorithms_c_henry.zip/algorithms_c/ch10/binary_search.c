#include <stdio.h>

int binary_search(int a[], int left, int right, int x)
{
	int mid = (left + right) / 2;
	if (a[mid] == x) {
		printf("returning mid = %d and a[mid] = %d\n", mid, a[mid]);
		return mid;
	}
	if (left <= right) {

		printf("left = %d, mid = %d, rright = %d for x = %d, a[m] = %d\n", left, mid, right, x, a[mid]);

		if (a[mid] > x)
			return binary_search(a, left, mid - 1, x); //cannot miss return here
		else
			return binary_search(a, mid + 1, right, x); //cannot miss return here
	}
	return -1;
}

// non-recursive version
int binary_search2(int a[], int left, int right, int x)
{
	while (left <= right) {
		int mid = (left + right) / 2;
		if (a[mid] == x) {
			printf("returning mid = %d and a[mid] = %d\n", mid, a[mid]);
			return mid;
		}

		printf("left = %d, mid = %d, right = %d for x = %d, a[m] = %d\n", left, mid, right, x, a[mid]);
		if (a[mid] > x) right = mid - 1;
		else if (a[mid] < x) left = mid + 1;
	}
	return -1;
}

int main(void)
{
   int a[] = {2, 3, 4, 10, 40};
   int n = sizeof(a)/ sizeof(a[0]);
   int x = 10;
   int result = binary_search2(a, 0, n-1, x);
   printf("result = %d\n", result);
   (result == -1)? printf("Element is not present in array")
                 : printf("Element is present at index %d\n",
                                                   result);
   return 0;
}
