#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

int check(int x) {
	if (x <= 0) return x == 0;
	int num_digits = (int) (floor(log10(x)) + 1);
	int msd_mask = (int) pow(10, num_digits - 1);

	for (int i = 0; i < (num_digits / 2); ++i) {
		int msd = x / msd_mask;
		int lsd = x % 10;
		if (msd != lsd)
			return false;
		x = x % msd_mask;
		x = x / 10;
		msd_mask = msd_mask / 100;
	}
	return true;
}

int main() {
	printf("check 151751: %d\n", check(151751));
	printf("check 157751: %d\n", check(157751));
}
