#include <stdio.h>
#include <stdlib.h>

int cmp_func(const void *a, const void *b) {
	return (*(int *)a - *(int *) b);
}

void print_array(int a[], int n) {
	for (int i = 0; i < n; i++)
		printf("%d ", a[i]);
	putchar('\n');
}

// assuming array has all natural #'s w/o negatives and 0
void print_k_missing(int a[], int n, int k) {
	int count = 0;
	if (a[0] > 1) printf("1 - %d missing\n", a[0] - 1);
	count = a[0] - 1;
	if (count > k) return;

	for (int i = 1; i < n; i++) {
		int diff = a[i] - a[i - 1];
		if (diff > 1) {
			int missing_number = a[i - 1] + 1;
			while (missing_number < a[i]) {
				count++;
				if (count > k) break;
				printf("count = %d: %d is missing\n", count, missing_number);
				missing_number++;
			}
		}
		if (count > k) break;
	}
}

int main()
{
    int a[] = {3, 7, 4, 12, 9, 25, 15};

    int n = sizeof(a) / sizeof(a[0]);
    qsort(a, n, sizeof(a[0]), cmp_func);

    printf("Sorted array is\n");
    print_array(a, n);

    int k = 7;
    print_k_missing(a, n, k);
    return 0;
}


