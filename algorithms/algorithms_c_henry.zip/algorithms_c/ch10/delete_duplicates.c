#include <stdio.h>

int delete_duplicates(int a[], int n) {
	int k = 1;
	for (int i = 1; i < n; i++) {
		if (a[i - 1] != a[i])
			a[k++] = a[i];
	}
	return k;
}

int main() {
	int a[] = {2, 3, 5, 5, 7, 11, 11, 11, 13};
	int n = sizeof(a) / sizeof(a[0]);
	n = delete_duplicates(a, n);
	for (int i = 0; i < n; i++)
		printf("%d ", a[i]);
	putchar('\n');
}
