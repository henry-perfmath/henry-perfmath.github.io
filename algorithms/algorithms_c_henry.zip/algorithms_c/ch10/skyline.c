#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

void test1();
int max_rect(int a[], int n, int *i, int *j);

int min (int a, int b) {
	return (a < b) ? a : b;
}
int main() {
	test1();
}

void test1() {
	int a[] = {1, 4, 2, 5, 6, 3, 2, 6, 6, 5, 2, 1, 3};
	int n = sizeof(a) / sizeof(a[0]);
	int i, j;
	int max_area = max_rect (a, n, &i, &j);
	printf("between elements %d and %d, max_rect = %d\n", i, j, max_area);
}

int find_lowest_inbetween (int a[], int start, int end) {
	int min_bar = INT_MAX;
	for (int i = start; i <= end; i++)
		if (a[i] < min_bar)
			min_bar = a[i];
	return min_bar;
}

int max_rect(int a[], int n, int *i, int *j) {

	int start = 0, end = n - 1, max_area = 0, area;
	while (start < end) {
		int lowest_inbetween = find_lowest_inbetween(a, start, end);
		printf("start = %d, end = %d, lowest_inbetween = %d \n", start, end, lowest_inbetween);
		area = (end - start + 1) * lowest_inbetween;
		//if (area > max_area && validate(a, start, end)) {
		if (area > max_area) {
			max_area = area;
			*i = start;
			*j = end;
		}
		//printf(">>>>i = %d, j = %d, area = %d, min = %d\n", *i, *j, area, min(a[start], a[end]));
		if (a[start] < a [end]) {
			start++;
		} else {
			end--;
		}
	}
	return max_area;
}


