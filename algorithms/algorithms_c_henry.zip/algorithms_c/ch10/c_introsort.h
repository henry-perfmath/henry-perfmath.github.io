/*
 * c_introsort.h
 *
 *  Created on: Nov 30, 2018
 *      Author: henryliu
 */

void insertion_sort(int *a, int count);
void max_heapify(int *a, int heap_size, int index);
void heap_sort(int *a, int count);
int partition(int *a, int left, int right);
void quicksort(int *a, int left, int right);
void intro_sort(int *a, int count);
