#include <stdio.h>
#include <stdlib.h>

int cmp_func(const void *a, const void *b) {
	return (*(int *)a - *(int *) b);
}

void print_array(int a[], int n) {
	for (int i = 0; i < n; i++)
		printf("%d ", a[i]);
	putchar('\n');
}

int find_crossover(int a[], int n, int val) {
	int crossover_idx = 0;
	for (int i = 0; i < n; i++) {
		if ((a[i] - val) >= 0) {
			crossover_idx = i;
			break;
		}
	}
	return crossover_idx;
}
void find_k_closest(int a[], int n, int k, int x) {
	int crossover_idx = find_crossover(a, n, x);
	printf("crossover = %d at index = %d\n", a[crossover_idx], crossover_idx);

	int i = crossover_idx - k;
	if (i < 0) i = 0;
	int j = crossover_idx + k;
	if ( j > n - 1) j = n - 1;

	int count = 0;
	int skip_idx = crossover_idx;
	while (count < k) {
		if (abs(a[i] - x) > abs(a[j] - x)) {
			i++;
		} else {
			j--;
		}
		count++;
	}

	// check if crossover should be excluded
	if (a[crossover_idx] != x) {
		skip_idx = -1; // disable skipping
		if (abs(a[i] - x) > abs(a[j] - x)) {
			i++;
		} else {
			j--;
		}
	}

	printf("%d closest elements with i = %d, j = %d, skip_idx = %d: ", k, i, j, skip_idx);
	for (int m = i; m <= j; m++) {
		if (m != skip_idx) printf("%d ", a[m]);
	}
	putchar('\n');
}

int main()
{
    int a[] = {12, 16, 22, 30, 35, 39, 42, 45, 48, 50, 53, 55, 56};
    //expected output: 30 39 42 45
    int k = 4;
    //int x = 35; // in the array
    int x = 32; // not in the array

    int n = sizeof(a) / sizeof(a[0]);

    printf("Initial array:\n");
    print_array(a, n);
    qsort(a, n, sizeof(a[0]), cmp_func);

    printf("Sorted array is\n");
    print_array(a, n);

    find_k_closest(a, n, k, x);

    return 0;
}


