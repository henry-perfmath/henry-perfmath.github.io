#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

char flip_char(char ch) {
	/*
	char flipped_char;
	if (islower(ch))
		flipped_char = toupper(ch);
	else
		flipped_char = tolower(ch);
	return flipped_char;*/
	return islower(ch) ? toupper(ch) : tolower(ch);
}

// in-place with O(n) time and O(1) space
void sanitize(char *a, int n) {
	printf("sanitize: n = %d, %s\n", n, a);
	int i = 0, k = 0;

	while ( i < n - 1) {
		if (a[i] == flip_char(a[i + 1])) {
			i = i + 2; // jump by 2
		} else if  (i > 0 && a[i] == flip_char(a[k - 1])) {
			k = k - 1; // k goes back by 1 as the slot for the next new char
			i++;
		} else {
			a[k++] = a[i++]; // just copy data from index i to k
		}
	}
	// take care of the last char
	a[k] = a[i];
	a[k + 1] = '\0';
}

void test1() {
	char *str = strdup("abcCBppQQTtzz");
	int n = strlen(str);
	printf("n = %d\ncheck flip_char:\n", n);
	for (int i = 0; i < n; i++) {
		printf("%c ", flip_char(str[i]));
	}
	printf("\n");
	sanitize(str, n);
	printf("after: %s\n", str);
}

void test2() {
	char *str = strdup("abcCBppQQTt");
	int n = strlen(str);
	printf("n = %d\ncheck flip_char:\n", n);
	for (int i = 0; i < n; i++) {
		printf("%c ", flip_char(str[i]));
	}
	printf("\n");
	sanitize(str, n);
	printf("after: %s\n", str);
}

int main() {
	test1();
	test2();
}
