#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int min (int a, int b) {
	return (a < b) ? a : b;
}
int trap (int a[], int n, int *i, int *j) {

	int start = 0, end = n - 1;
	int max = -INT_MAX;
	int water_trapped;

	while (start < end) {
		water_trapped = (end - start) * min(a[start], a[end]); // tricky part
		printf("%d %d %d\n", start, end, water_trapped);
		if (max < water_trapped) {
			max =  water_trapped;
			*i = start;
			*j = end;
		}
		if (a[start] < a[end])
			start++;
		else
			end--;
	}
	return max;
}

void test1() {
	int a [] = {1, 2, 1, 3, 4, 4, 5, 6, 2, 1, 3, 1, 3, 2, 1, 2, 4, 1};
	int n = sizeof(a) / sizeof(a[0]);
	int i = 0, j = 0;
	int water_tarpped = trap(a, n, &i, &j);
	printf("water trapped between %d - %d: %d\n", i, j, water_tarpped);
}

int main() {
	test1();
}
