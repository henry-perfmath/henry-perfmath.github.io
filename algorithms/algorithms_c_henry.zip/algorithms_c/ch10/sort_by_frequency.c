#include <stdio.h>
#include <stdlib.h>
#include "../ch5/hashtable.h"

typedef struct item {
	int idx;
	int count;
} Item;

int item_cmp_func(const void *a, const void *b) {
	int a_idx = ((Item *) a)->idx;
	int b_idx = ((Item *) b)->idx;
	int a_count = ((Item *) a)->count;
	int b_count = ((Item *) b)->count;
	if (a_count == b_count)
		return b_idx - a_idx;
	else
		return b_count - a_count; // reverse for ascending order
}

void print_array(int a[], int n) {
	for (int i = 0; i < n; i++) {
		printf("i = %d, a[%d] = %d\n", i, i, a[i]);
	}
}

void print_table(Table *table, int a[], int n) {
	for (int i = 0; i < n; i++) {
		printf("i = %d, idx = %d, count = %d\n", i, table->hash_list[a[i]]->key,
				table->hash_list[a[i]]->value);
	}
}

void print_item_array(Item a[], int n) {
	for (int i = 0; i < n; i++) {
		printf("i = %d, idx = %d, count = %d\n", i, a[i].idx, a[i].count);
	}
}

void sort_by_count(Item a[], int n) {
	qsort(a, n, sizeof(struct item), item_cmp_func);
}

int main() {
	int a[] = { 1, 5, 2, 5, 1, 3, 5, 2, 80 };
	int n = sizeof(a) / sizeof(a[0]);

	Table *table = init(n);

	for (int i = 0; i < n; i++) {
		printf("%d, a[%d] = %d\n", i, i, a[i]);
		int value = get(table, a[i]);
		printf("i = %d, a[%d] = %d, value = %d\n", i, i, a[i], value);
		if (value == -1) {
			put(table, a[i], 1);
		} else {
			put(table, a[i], ++value); // do not do value++
		}
	}
	printf("print table\n");
	print_table(table, a, n);

	Item item[n];
	for (int i = 0; i < n; i++) {
		item[i].idx = a[i];
		item[i].count = get(table, a[i]);
	}

	printf("before sort_by_count:\n");
	print_item_array(item, n);
	sort_by_count(item, n);
	printf("after sort_by_count:\n");
	print_item_array(item, n);
}
