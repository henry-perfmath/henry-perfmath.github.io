#include <stdio.h>
#include <math.h>
#include "max_heap.h"

//#define MAX_CAPACITY 100
////int heap[MAX_CAPACITY ] = {150, 80, 40, 30, 10, 70, 110, 100, 20, 90, 60, 50, 120, 140, 130}; // remaining set to 0's
//int heap[MAX_CAPACITY ] = {15, 150, 80, 40, 30, 60, 70, 110, 100, 20, 90, 10, 50, 120, 140, 130}; // remaining set to 0's

void insert(int *heap, int x) // percolate up
{
	int i = ++heap[0];
	heap[i] = x;
	heapify(heap);
}

int delete_max(int *heap) {
	int max_val = heap[1];
	heap[1] = heap[heap[0]];
	heap[0]--;
	heapify(heap);
	return max_val;
}

int get_max(int *heap) {
	return heap[1];
}
void reverse_to_desc (int *heap)
{
	for (int i = 1; i <= heap[0]/2; i++)
		swap(&heap[i], &heap[heap[0] + 1 - i]);
}

void percolate_down_no_swap(int *heap, int i) { // Weiss p 262
	int curr_element = heap[i];

	int child; // precolate curr_node down along the child path with smaller value until ...
	for ( ; 2 * i <= heap[0]; i = child) {
		child = 2 * i;
		if ((child + 1) <= heap[0] && heap[child + 1] > heap[child]) // min-max 1st comparison must be "<=", not "<"
			child++; // right child
		if (curr_element < heap[child]) { // min-max
			heap[i] = heap[child];
		} else {
			break;
		}

	}
	heap[i] = curr_element;
}

void heap_sort_asc(int *heap)
{
    int array_size = heap[0]; // after sorting, array would be no longer a heap
    int count = 1;
    while (count < array_size) {
        // swap head and tail
        swap(&heap[1], &heap[heap[0]]);
        heap[0]--; // exclude tail node
        heapify(heap);
        count++;
    }

    heap[0] = array_size;
}

void heapify(int *heap) { // start from the last parent node
	for (int i = heap[0] / 2; i > 0; i--) {
		percolate_down_no_swap(heap, i);
	}
}

void build_max_heap(int *heap) { // with a non-heap to start with
	puts("build heap from an initialized array");
	heapify(heap);
	print_heap(heap, "build heap done: ");
}

void swap(int *x, int *y) {
	int temp = *x;
	*x = *y;
	*y = temp;
}

void print_heap(int *heap, char *header) {
	printf("\n... %s \n", header);
	int level = 0;
	int n = heap[0];
	for (int i = 1; i <= n; i++) {
		if ((int) log2(i) > level) {
			putchar('\n');
			level = (int) log2(i) ;
		}
		printf("%d ", heap[i]);
	}
	printf("\n");
}

/*
int main() {

	//build_min_heap();
	heapify (); //heapify an array initialized at the start

	print_heap("before insert");

	printf("\n===insert===\n");
	insert(15);
	print_heap("after insert 15");

	int max_val = delete_max();
	printf("\ndelete_max: max_val = %d\n", max_val);
	print_heap("after delete_max");

	print_heap("before sort_asc");
	heap_sort_asc();
	print_heap("after sort_asc");

	reverse_to_desc ();
	print_heap("after reverse");
}
*/
