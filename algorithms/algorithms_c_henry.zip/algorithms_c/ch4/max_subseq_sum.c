#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int max_subsequence_sum(const int a[], const unsigned int n)
{
	int max_sum = 0, sum = 0;
	for (int i = 0; i < n; i++)
	{
		sum += a[i];

		if (sum > max_sum)
			max_sum = sum;
		else if (sum < 0)
			sum = 0;
	}

	return max_sum;
}

int main()
{
	int n;
	printf("enter n:");
	scanf("%d", &n);

	srand(time(NULL));

	int a[n];
	for (int i = 0; i < n; i++)
		a[i] = 20 / 2 - rand() % 20;

	for (int i = 0; i < n; i++)
		(i < (n - 1)) ? printf("%d ", a[i]) : printf("\n");

	int max_sum = max_subsequence_sum(a, n);
	printf("max_sum = %d\n", max_sum);
}

