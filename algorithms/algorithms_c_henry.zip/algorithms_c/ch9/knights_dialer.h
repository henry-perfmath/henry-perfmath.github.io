/*
 * knights_dialer.h
 *
 *  Created on: Dec 10, 2018
 *      Author: henryliu
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#define M 4
#define N 3

typedef struct sequence {
	int start;
	int p1;
	int p2;
	int end;
} Sequence;

typedef struct validMoves {
	int key;
	int count;
	Sequence *seq;
} ValidMoves;


