/*
 *https://www.topcoder.com/blog/generating-permutations/
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../ch5/hashtable.h"
#include <limits.h>
#include <math.h>

Table *table;

int ht_hash(char *key, int n) {

	int hash = 0;
	for (int i = 0; i < n; i++)
		hash = key[i] + hash * pow(i, 10);

	return hash % TABLE_CAPACITY;
}

void swap(char *x, char *y)
{
	char temp = *x;
	*x = *y;
	*y = temp;
}

void print_array(char *a, int n)
{
	int index = ht_hash(a, n);
	put(table, index, index);

	for (int i = 0; i < n; i++)
		printf("%c", a[i]);
	printf(" %d %d \n", index, get(table, index));

}

void heap_perm(char *a, int size, int n)
{
	// if size is 1, perm done and print
	if (size == 1)
	{
		print_array(a, n);
		//int index = ht_hash(a, n);
		//put(table, index, index);
		return;
	}

	for (int i = 0; i < size; i++)
	{
		heap_perm(a, size - 1, n);

		// if size is odd, swap first and last item
		if (size % 2 == 1)
			swap(&a[0], &a[size - 1]);
		// if size is even, swap ith and last item
		else
			swap(&a[i], &a[size - 1]);
	}
}
int factorial(int n)
{
	int f = 1;
	for (int i = 1; i <= n; ++i)
		f *= i;
	return f;
}

void anagram_index(int N, char* str) {
	int n = strlen(str);
	char *substr = (char *)calloc(1, N);
	for (int i = 0; i < n - N + 1; i++) {
		char *start = &str[i];
		memcpy(substr, start, N);
		int index = ht_hash(substr, N);
		int value = get(table, index);
		//printf("%s %d %d\n", substr, index, value);
		if (value > 0) {
			printf("%s at %d\n", substr, i);
		}
	}
}

int main()
{
	//char a[] = {'a', 'b', 'c', 'd'};
	char a[] = {'a', 'b'};
	int n = sizeof a / sizeof a[0];
	//char *a = "abcd";
	//int n = strlen(a);
	int N = factorial(n);
	printf("N = %d\n", N);
	table = init(N);
	heap_perm(a, n, n);

	anagram_index(N, "abxaba");
}
