/*
 * smallest_region.c
 *
 *  Find smallest region to be sorted
 *  Author: henryliu
 */
#include <stdio.h>
#include <stdlib.h>

void find_smallest_region(int a[], int n, int *min_index, int *max_index) {
	*min_index = 0;
	*max_index = n - 1;

	for (int i = 0; i < n; i++) {
		if (a[i] <= a[i + 1])
			(*min_index)++;
		else
			break;
	}

	for (int i = n - 1; i > 0; i--) {
			if ((a[i] >= a[*min_index]) && (a[i - 1] <= a[i]))
				(*max_index)--;
			else
				break;
		}
}

int main() {
	int a[] = {4, 8, 6, 7, 10};
	int n = sizeof(a) / sizeof(a[0]);
	int min_index, max_index;
	find_smallest_region(a, n, &min_index, &max_index);
	printf("min_index = %d, max_index = %d for n = %d\n", min_index, max_index, n);
}
