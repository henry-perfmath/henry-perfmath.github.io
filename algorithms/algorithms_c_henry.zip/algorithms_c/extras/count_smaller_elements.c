/*
 * 1M took 0.39s. 10M took 3.7"
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void count_smaller_elememnts(int a[], int b[], int n) {
	for (int i = 0; i < n; i++) {
		b[i] = 0;
		for (int j = n - 1; j > i; j--)
			if (a[j] < a[i])
				b[i]++;
	}
}

int main() {
	int a[] = {3, 4, 9, 6, 1, 10, 2, 5, 20, 7, 19, 8, 18, 11, 17, 12, 16, 13, 15, 14};
	int n = sizeof(a) / sizeof(a[0]);
	int b[n];

	int N = 1000000;

	clock_t start = clock();
	for (int i = 0; i < N; i++)
		count_smaller_elememnts(a, b, n);
	double duration = (double) (clock() - start) / CLOCKS_PER_SEC;
	printf("duration = %f seconds\n", duration);


	for (int i = 0; i < n; i++)
		printf("%d ", b[i]);
	putchar('\n');
}
