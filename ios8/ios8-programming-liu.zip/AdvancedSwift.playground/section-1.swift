// Playground - noun: a place where people can play

import Cocoa

// example: closure with operator function
var websites = ["Apple", "Microsoft", "Google", "Yahoo"]
//let reversed = sorted (websites, <)
let sortedWebsites = sorted (websites, {(str1: String, str2: String) -> Bool in return str1 < str2})
println (sortedWebsites)

// example: trailing closures
let digitNames = [0: "Zero", 1: "One", 2: "Two", 3: "Three", 4: "Four", 5: "Five", 6: "Six", 7: "Seven", 8: "Eight", 9: "Nine"]

let numbers = [9, 10, 99]

let strings = numbers.map {
    (var number) -> String in
    var output = ""
    while number > 0 {
        output = digitNames [number % 10]! + output
        number /= 10
    }
    return output
}
