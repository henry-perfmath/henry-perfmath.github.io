//
//  MyNotesTableViewController.swift
//  NoteApp
//
//  Created by Henry Liu on 8/25/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import Foundation
import UIKit
import CoreData

@objc (NoteItem1)
class NoteItem1: NSManagedObject {
    @NSManaged var itemName: String
}


class MyNotesTableViewController: UITableViewController, UITableViewDelegate, UITableViewDataSource {
    var noteItems = [AnyObject] ()
    var _dataFilePath = "noteapp2_data.archive"

    @IBAction func unwindToList (segue: UIStoryboardSegue) {
        var source: AddNewNoteItemViewController = segue.sourceViewController as AddNewNoteItemViewController
        if let item = source.noteItem as NoteItem! {
            self.noteItems.append(item)
            self.tableView.reloadData()
            saveData(item)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        loadInitialData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    // not needed anymore in iOS 8
    func numberOfRowsInSelection (tableView: UITableView) -> Int {
       return noteItems.count
    }
    func saveData (item: NoteItem) {
        /*
        var itemArray = [AnyObject] ()
    
        for item: NoteItem in noteItems as [NoteItem] {
            itemArray.append(item.itemName)
        }
        NSKeyedArchiver.archiveRootObject(itemArray, toFile: _dataFilePath)
        println ("completed saving data to: \(_dataFilePath)")
*/
        println ("saving note using Core Data for \(item.itemName)")
        let  appDelegate = UIApplication.sharedApplication().delegate as AppDelegate
        let context: NSManagedObjectContext = appDelegate.managedObjectContext!
        let noteEntity = NSEntityDescription.entityForName("Notes", inManagedObjectContext: context)
        
        // insert newNote into context
        var newNote = NoteItem1 (entity: noteEntity!, insertIntoManagedObjectContext: context)
        
        // bad -  crashes even w/o newNote.itemName = textView.text
        // var newNote = NSEntityDescription.insertNewObjectForEntityForName("MyNotes",inManagedObjectContext: context) as NoteItem
        
        //set note name (don't do newNote.itemName = textView.text - crashes)
        newNote.setValue(item.itemName, forKey: "note")
        var error: NSError?
        context.save(&error)
        println ("note \"\(item.itemName)\" saved")
    }
    
    func loadInitialData () {
        println ("loading initial data using Core Data ")
        let  appDelegate = UIApplication.sharedApplication().delegate as AppDelegate
        let context: NSManagedObjectContext = appDelegate.managedObjectContext!
        let noteEntity = NSEntityDescription.entityForName("Notes", inManagedObjectContext: context)
        
        //let searchString = textView.text
        // must include double quote escape
        var request: NSFetchRequest  = NSFetchRequest (entityName: "Notes")
        request.predicate = NSPredicate (format: "note != nil")
        
        var error: NSError?
        var objects = context.executeFetchRequest (request, error:&error)
        
        if objects?.count == 0 {
            println ("No data in the database")
        } else {
//            println ("found: \(objects.count) items with search string \"\(searchString)\"")
            for foundItem: NSManagedObject in objects as [NSManagedObject] {
                var itemName = foundItem.valueForKey("note") as String
                println ("found: \(itemName) of \(objects?.count)")
                noteItems.append(NoteItem (name: itemName))
            }
            
            //            var matches:  NSManagedObject = objects [0] as NSManagedObject
            //            var text = matches.valueForKey("note") as String
            //            println ("matches found \(text)")
        }
        

        /*
        var docsDir: String = ""
        var dirPths = [AnyObject]()
        
        dirPths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)
        docsDir = dirPths [0] as String
        //docsDir = "/Users/henry/mydev" 
        // have to overwrite as the default Documents folder does not work
        _dataFilePath = docsDir + _dataFilePath
        
        var fileMgr = NSFileManager.defaultManager()
        if fileMgr.fileExistsAtPath (_dataFilePath)
        {
            println ("Load data from file: \(_dataFilePath)")
            var dataArray = [String]()
            
            dataArray = NSKeyedUnarchiver.unarchiveObjectWithFile (_dataFilePath) as [String]
            println ("number of items to load: \(dataArray.count)")
            
            for itemName:String in dataArray as [String] {
                var item: NoteItem = NoteItem (name: itemName)
                noteItems.append (item)
                println ("added item: \(item.itemName)")
            }
            
        } else {
            println ("File does not exist: \(_dataFilePath)")
        }
*/
    }
    override func tableView (tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let listPropertyCell: String = "ListPrototypeCell"
        var cell: UITableViewCell = self.tableView.dequeueReusableCellWithIdentifier(listPropertyCell, forIndexPath: indexPath) as UITableViewCell
        var noteItem: NoteItem = noteItems [indexPath.row] as NoteItem
        cell.textLabel?.text = noteItem.itemName
        
        if noteItem.completed {
            cell.accessoryType = UITableViewCellAccessoryType.Checkmark
            noteItem.setCompletionDate(onDate: NSDate ())
        } else {
            cell.accessoryType = UITableViewCellAccessoryType.None
        }
        return cell
    }
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return self.noteItems.count
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        println ("didSelectRowAtIndexPath: \(indexPath.row)")
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
        let tappedItem: NoteItem = noteItems [indexPath.row] as NoteItem
        tappedItem.completed = !tappedItem.completed
        //tableView.reloadData()
        tableView.reloadRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.None)
        //reloadInputViews()
    }
}