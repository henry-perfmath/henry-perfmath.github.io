// Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

// 1. constant, variable and inferred type
let i = 5       // constant, inferred type
let j = 6       // constant inferred type
var k = i + j   // variable, inferred type

// 2. constant vs variable
i = 6               // value of a constant cannot be changede
k = i * j           // value of a variable can be changed

var m : Int = i * j // variable, explicit type, Int in this case

// 3. string interpolation
let numOfLoops = 5
println ("number of loops = \(numOfLoops)") // string interpolation

/* 4. For loop:
his will not work. Use for ... in as shown next
for (var l : Int = 0; l < numOfLoops; l++)
    println ("Loop number l = \(l,))"
*/
for index in 1 ... numOfLoops {
    println ("Loop number is \(index)")
}

// 5. blocks require use of { ... }
for index in 1 ... numOfLoops
    println ("Loop number is \(index)")

a = 1

