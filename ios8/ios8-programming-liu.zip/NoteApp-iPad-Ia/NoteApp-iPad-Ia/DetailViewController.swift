//
//  DetailViewController.swift
//  NoteApp-iPad-Ia
//
//  Created by Henry Liu on 8/28/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    @IBOutlet weak var webView: UIWebView!
                            
    @IBOutlet weak var detailDescriptionLabel: UILabel!


    var detailItem: AnyObject? {
        didSet {
            // Update the view.
            println ("\n1.: detailItem: calling configView ()")
            self.configureView()
        }
    }

    func configureView() {
        // Update the user interface for the detail item.
        if let detail: AnyObject = self.detailItem {
            /*
            if let label = self.detailDescriptionLabel {
                label.text = detail.description
            }
            */

            if let wv = webView {
                let urlString = detailItem as String
                println ("got url string for web view: \(urlString)")
                let urlPath = NSURL (string: urlString)
                let request: NSURLRequest = NSURLRequest (URL: urlPath)

                self.webView.scalesPageToFit = true
                self.webView.loadRequest(request)
            } else {
                println ("webView is nil")
            }
        }
    }

    override func viewDidLoad() {
        println ("\n2: calling deatil view controller's view didLoad")
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // do not conigure view here. Do it in configureView method
        //let url = NSURL(string: "http//www.apple.com")
        //let request = NSURLRequest(URL: url)
        //webView.loadRequest(request)
        
        
        println ("viewDidLoad: calling configView ()")
        self.configureView()
        println ("exiting detail view controller's view didLoad")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
/*
    override func splitViewController (splitController: UISplitViewController, willHideViewController viewController: UIViewController, withBarButtonItem barButtonItem: UIBarButtonItem, forPopoverController popoverController: UIPopoverController) {
        barButtonItem.title = NSLocalizedString ("My Favorite Websites")
        self.navigationItem.setLeftBarButtonItem(barButtonItem, animated: true)
    }
    func splitViewController (splitController: UISplitViewController, willShowViewController viewController: UIViewController, invalidatingBarButtonItem barButtonItem: UIBarButtonItem) {
        self.masterPopoverController = nil
    }
 */   
}

