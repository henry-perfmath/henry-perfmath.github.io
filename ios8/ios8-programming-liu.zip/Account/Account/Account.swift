//
//  Account.swift
//  Account
//
//  Created by Henry Liu on 8/19/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import Foundation
class Account {
    let accountType = "Checking"
    var monthlyServiceFee: Double
    init (freeChecking fee: Double) {
        accountType = "FreeChecking"
        monthlyServiceFee = fee
    }
    init (premiumChecking fee: Double) {
        accountType = "PremiumChecking"
        monthlyServiceFee = fee
    }
}

/*
class Account {
    let accountType = "Checking"
    var accountId: Int64?
    var balance: Double = 0.0
    var status: Int = -1
}
*/
class InterestChecking {
    let accountType = "Checking"
    var accountId: Int64?
    var balance: Double = 0.0
    var status: Int = -1
    
    var yearlyInterestRate = 0.001
    var monthlyInterestAmount: Double {
        get {
            return balance * yearlyInterestRate / 12.0
        }
        set (newYearlyInterestRate) {
            yearlyInterestRate = newYearlyInterestRate
        }
    }
    // read-only computed property
    var yearlyInterestAmount: Double {
        return balance * yearlyInterestRate
    }
}

class SavingsAccount {
    var interestRate: Double
    init () {
        interestRate = 0.001
    }
}

class CheckingAccount {
    let depositFee, withdrawFee: Double
    init(depositFee: Double, withdrawFee: Double) {
        self.depositFee   = depositFee
        self.withdrawFee = withdrawFee
    }
    init(_ flatFee: Double) {
        depositFee = flatFee
        withdrawFee = flatFee
    }
}
/*
class XAccount {
    var accountId: Int?
    var balance: Double = 0.0
    init (_ id: Int) {
        accountId = id
    }
    func deposit (amount: Double) {
        balance += amount
    }
    func showAccountInfo () {
        println ("account id: \(accountId) balance: \(balance)")
    }
}
*/


class XAccount {
    var accountId: Int?
    var balance: Double = 0.0
    init (_ accountId: Int) {
        self.accountId = accountId
    }
    func deposit(depositAmount: Double, withdraw withdrawAmount: Double) {
        balance += depositAmount - withdrawAmount
    }
    func showAccountInfo () {
        println ("account id: \(accountId) balance: \(balance)")
    }
}