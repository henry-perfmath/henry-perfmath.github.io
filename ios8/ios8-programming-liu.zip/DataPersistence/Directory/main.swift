//
//  main.swift
//  Directory
//
//  Created by Henry Liu on 8/26/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import Foundation

//1. find the Documents Directory
var dirPaths = [AnyObject] ()
var docDir: String = ""

dirPaths = NSSearchPathForDirectoriesInDomains(.DocumentationDirectory, .UserDomainMask, true)

docDir = dirPaths [0] as String

println ("docDir = \(docDir)")

for dir: String in dirPaths as [String]{
    println ("dir: \(dir)")
}

// 2. find the current working directory
var fileMgr = NSFileManager.defaultManager()
var currentPath: String = fileMgr.currentDirectoryPath
println ("current dir = \(currentPath)")

// 3.find the tmp directory
var tmpDir: String = NSTemporaryDirectory()
println ("tmp dir = \(tmpDir)")

// 4. list contents of a dir
var fileList = [AnyObject] ()
fileList = fileMgr.contentsOfDirectoryAtPath(currentPath, error: nil)

for file: String in fileList as [String] {
    println ("file: \(file)")
}

for (var i = 0; i < fileList.count; i++) {
    println ("file:\(i + 1) \(fileList[i])")
}