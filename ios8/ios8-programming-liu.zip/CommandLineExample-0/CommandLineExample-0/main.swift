//
//  main.swift
//  CommandLineExample-0
//
//  Created by Henry Liu on 8/12/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import Foundation

println("Hello, World!")

let argv = NSProcessInfo.processInfo().arguments
//let appname = (argv[0] as String).bridgeToObjectiveC().lastPathComponent
let argc = argv.count

println ("argc = ", argc)
let argv0 = argv.first
let argv1 = argv.last

println ("argv [0] = ", argv0)
println ("argv [1] = ", argv1)

func usage() {
    //println("Usage: \(appname) arguments")
    Foundation.exit(-1)
}