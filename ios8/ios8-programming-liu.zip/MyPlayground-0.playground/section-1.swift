func swapTwoInts(inout a: Int, inout b: Int) {
    let temp = a
    a = b
    b = temp
}

var int1 = 100
var int2 = 200
swapTwoInts(&int1, &int2)
println("int1 is now \(int1), and int2 is now \(int2)")


