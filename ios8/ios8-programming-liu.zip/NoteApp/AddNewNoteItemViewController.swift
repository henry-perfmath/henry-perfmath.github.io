//
//  AddNewNoteItemViewController.swift
//  NoteApp
//
//  Created by Henry Liu on 8/25/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import Foundation
import UIKit

class AddNewNoteItemViewController: UIViewController {
    
    @IBOutlet weak var textView: UITextView!
    var noteItem: NoteItem?
    @IBOutlet weak var doneButton: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func prepareForSegue(segue: UIStoryboardSegue!, sender: AnyObject!) {
        //
        if sender as? UIBarButtonItem != self.doneButton {
            return
        }
        if !self.textView.text.isEmpty {
            self.noteItem = NoteItem (name: self.textView.text)
        }
    }
    
}