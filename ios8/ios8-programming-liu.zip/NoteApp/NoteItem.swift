//
//  NoteItem.swift
//  NoteApp
//
//  Created by Henry Liu on 8/25/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import Foundation

class NoteItem {
    var itemName: String
    var completed: Bool = false
    lazy private var completionDate: NSDate = NSDate ()
    
    init (name itemName: String, isCompleted status: Bool = false) {
        self.itemName = itemName
        self.completed = status
    }
    func markAsCompleted (isComplete: Bool, onDate completionDate: NSDate) {
        self.completed = isComplete
        self.setCompletionDate (onDate: completionDate)
    }

    func setCompletionDate (onDate completionDate: NSDate) {
        if self.completed {
            //self.completionDate = NSDate ()
            self.completionDate = completionDate
            println ("completed on: \(self.completionDate)")
        }
    }
}