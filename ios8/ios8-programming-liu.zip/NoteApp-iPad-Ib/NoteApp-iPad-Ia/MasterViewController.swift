//
//  MasterViewController.swift
//  NoteApp-iPad-Ia
//
//  Created by Henry Liu on 8/28/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import UIKit
import CoreData

@objc (NoteItem1)
class NoteItem1: NSManagedObject {
    @NSManaged var itemName: String
    @NSManaged var content: String
}

class Detail {
    var noteItem: NoteItem
    var delegate: MasterViewController
    
    init (noteItem: NoteItem, delegate: MasterViewController) {
        self.noteItem = noteItem
        self.delegate = delegate
    }
}
class MasterViewController: UITableViewController, DetailViewControllerDelegate {

    var detailViewController: DetailViewController? = nil
    //var objects = NSMutableArray()
    var itemNames = NSMutableArray ()
    var itemContents = NSMutableArray ()
    var currentRowIndex: Int = -1
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.clearsSelectionOnViewWillAppear = false
        self.preferredContentSize = CGSize(width: 320.0, height: 600.0)
    }

    override func viewDidLoad() {
        println ("MVC: viewDidLoad +")
        super.viewDidLoad()

        self.navigationItem.leftBarButtonItem = self.editButtonItem()

        let addButton = UIBarButtonItem(barButtonSystemItem: .Add, target: self, action: "insertNewObject:")
        self.navigationItem.rightBarButtonItem = addButton

        if self.detailViewController == nil {
            let controllers = self.splitViewController?.viewControllers
            self.detailViewController = controllers?.last?.topViewController as? DetailViewController
        } else {
            println ("splitViewController is nil")
        }
        self.loadInitialData()
       println ("MVC: viewDidLoad -")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func insertNewObject(sender: AnyObject) {
        println ("\nMVC: insertNewObject +")
       
        if let indexPath = self.tableView.indexPathForSelectedRow() {
            self.tableView.deselectRowAtIndexPath(indexPath, animated: true)
            //println ("MVC: check index: \(self.tableView.indexPathForSelectedRow().row)")
            self.detailViewController?.textField.text = ""
            self.detailViewController?.textView.text = ""
        }

        var item = NoteItem ()
        item.itemName = "Insert item name here"
        item.content = "Insert item content here (when done, click Save)"

        
        let object = Detail (noteItem: item as NoteItem, delegate: self)
        self.detailViewController?.detailItem = object
        self.currentRowIndex = -1
        println ("MVC: insertNewObject -\n")
    }

    // MARK: - Segues

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        println ("MVC: prepareForSegue +")
        if segue.identifier == "showDetail" {
            if let indexPath = self.tableView.indexPathForSelectedRow() {
            
            println ("\nMasterView: call prepareForSegue... with index = \(indexPath.row)")
            let selectedItem = NoteItem ()
            selectedItem.itemName = itemNames [indexPath.row] as String
            selectedItem.content = itemContents [indexPath.row] as String
            let object = Detail (noteItem: selectedItem, delegate: self)
            let controller = (segue.destinationViewController as UINavigationController).topViewController as DetailViewController
            controller.detailItem = object
            self.currentRowIndex = indexPath.row
            
            controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem()
            controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
        println ("MVC: prepareForSegue -")
    }

    // MARK: - Table View

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return objects.count
        return itemNames.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        println ("MVC: cellForRowAtIndexPath +")
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath) as UITableViewCell

        //let object = objects[indexPath.row] as NSDate
        //cell.textLabel.text = object.description
        cell.textLabel?.text = itemNames[indexPath.row] as? String
        println ("MVC: cellForRowAtIndexPath -")
        return cell
    }

    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        println ("MVC: commitEditingStyle +")
        if editingStyle == .Delete {
            let selectedItemName: AnyObject! = itemNames [indexPath.row]

            itemNames.removeObjectAtIndex(indexPath.row)
            itemContents.removeObjectAtIndex(indexPath.row)
            
            //println ("deleteing data using Core Data ")
            let  appDelegate = UIApplication.sharedApplication().delegate as AppDelegate
            let context: NSManagedObjectContext = appDelegate.managedObjectContext!
            let noteEntity = NSEntityDescription.entityForName("Notes", inManagedObjectContext: context)
            
            // must include double quote escape
            var request: NSFetchRequest  = NSFetchRequest (entityName: "Notes")
            request.predicate = NSPredicate (format: "itemName == \"\(selectedItemName)\"")
            
            var error: NSError?
            var objects = context.executeFetchRequest (request, error:&error)
            
            if objects?.count == 0 {
                println ("No data in the database")
            } else {
                for foundItem: NSManagedObject in objects as [NSManagedObject] {
                    var itemName = foundItem.valueForKey("itemName") as String
                    println ("found: \(itemName) of \(objects?.count)")
            }
            // delete from database
            context.deleteObject(objects?[0] as NSManagedObject)
            context.save(&error)
            }

            // update table view
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            println ("insert ...")
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        }
        println ("MVC: commitEditingStyle -")
    }
/*
    override func tableView (tableView: UITableView!, didSelectRowAtIndexPath indexPath: NSIndexPath!) {
    println ("MVC: didSelectRowAtIndexPath +")

        let itemName: String = itemNames.objectAtIndex(indexPath.row) as String

        self.detailViewController?.currentRowIndex = indexPath.row
            let index = self.detailViewController?.currentRowIndex as Int!
            println ("index = \(index) for \(itemName)")

    println ("MVC: didSelectRowAtIndexPath -")
    }
*/
    func saveItem (item: NoteItem) {
        println ("MVC: saveItem +")
        //println ("saving note using Core Data for \(item.itemName)")
        let  appDelegate = UIApplication.sharedApplication().delegate as AppDelegate
        let context: NSManagedObjectContext = appDelegate.managedObjectContext!
        let noteEntity = NSEntityDescription.entityForName("Notes", inManagedObjectContext: context)
        
        // insert newNote into context
        var newNote = NoteItem1 (entity: noteEntity!, insertIntoManagedObjectContext: context)
     
        //set note name (don't do newNote.itemName = textView.text - crashes)
        newNote.setValue(item.itemName, forKey: "itemName")
        newNote.setValue(item.content, forKey: "content")
        println ("MVC: saveItem insertObject \(newNote.itemName)")
        context.insertObject(newNote)
        var error: NSError?
        context.save(&error)
        //println ("item \"\(item.itemName)\" saved")
        println ("MVC: saveItem -")
    }
    func deleteItem (item: NoteItem) {
        println ("MVC: deleteItem +")
        let  appDelegate = UIApplication.sharedApplication().delegate as AppDelegate
        let context: NSManagedObjectContext = appDelegate.managedObjectContext!
        let noteEntity = NSEntityDescription.entityForName("Notes", inManagedObjectContext: context)
        var request: NSFetchRequest  = NSFetchRequest (entityName: "Notes")
        request.predicate = NSPredicate (format: "itemName == \"\(item.itemName)\"")
        
        var error: NSError?
        var objects = context.executeFetchRequest (request, error:&error)
        
        if objects?.count == 0 {
            println ("No data in the database")
        } else {
            //println ("found: \(objects.count) items with search string \"\(searchString)\"")
            for foundItem: NSManagedObject in objects as [NSManagedObject] {
                var itemName = foundItem.valueForKey("itemName") as String
                println ("found: \(itemName) of \(objects?.count)")
            }
            context.deleteObject(objects?[0] as NSManagedObject)
            context.save(&error)
        }
    }

    
    func loadInitialData () {
        println ("MVC: loadInitialData +")
        //println ("loading initial data using Core Data ")
        let  appDelegate = UIApplication.sharedApplication().delegate as AppDelegate
        let context: NSManagedObjectContext = appDelegate.managedObjectContext!
        let noteEntity = NSEntityDescription.entityForName("Notes", inManagedObjectContext: context)
        
        //let searchString = textView.text
        // must include double quote escape
        var request: NSFetchRequest  = NSFetchRequest (entityName: "Notes")
        request.predicate = NSPredicate (format: "itemName != nil")
        
        var error: NSError?
        var objects = context.executeFetchRequest (request, error:&error)
        
        if objects?.count == 0 {
            println ("No data in the database")
        } else {
            for foundItem: NSManagedObject in objects as [NSManagedObject] {
                var key = foundItem.valueForKey("itemName") as String
                var value = foundItem.valueForKey("content") as String
                itemNames.addObject (key)
                itemContents.addObject(value)
                println ("\(key) - \(value)")
            }
        }
        println ("MVC: loadInitialData -")
    }
    func saveItemRequest(itemToSave: AnyObject) {
        println ("MVC: saveItemRequest +")

        var item = NoteItem ()
        item = itemToSave as NoteItem

        if self.currentRowIndex >= 0 {
            // update selected row
            println ("MVC: update calling saveItemRequest with with index = \(self.currentRowIndex)")
            let currentItem = NoteItem ()
            currentItem.itemName = itemNames [self.currentRowIndex] as String
            currentItem.content = itemContents [self.currentRowIndex] as String
            deleteItem (currentItem)
            
            //println ("MVC: replaced item \(noteItems[self.currentRowIndex].itemName)")
            itemNames.replaceObjectAtIndex(self.currentRowIndex, withObject: item.itemName)
            itemContents.replaceObjectAtIndex(self.currentRowIndex, withObject: item.content)
        } else {
            // insert a new row
            println ("MVC: add calling saveItemRequest")
            //noteItems.append (item)
            itemNames.addObject(item.itemName)
            itemContents.addObject(item.content)
            println ("MVC: insertRowsAtIndexPaths +")

            //let indexPath = self.tableView.indexPathForSelectedRow()
            //let indexPath = NSIndexPath (forRow: 0, inSection: 0)
            //self.tableView.insertRowsAtIndexPaths([indexPath], withRowAnimation: .None)
            println ("MVC: insertRowsAtIndexPaths -")
        }
       saveItem(item)
       tableView.reloadData()

        println ("MVC: saveItemRequest -")
        
    }
}

