//
//  NoteItem.swift
//  NoteApp-iPhone-I
//
//  Created by Henry Liu on 9/4/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import Foundation

class NoteItem {
    var itemName: String = ""
    var content: String = ""
}