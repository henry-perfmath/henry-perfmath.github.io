//
//  ViewController.swift
//  TapTest
//
//  Created by Henry Liu on 10/9/14.
//  Copyright (c) 2014 Henry Liu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var touchDown: NSTimeInterval?
    var touchUp: NSTimeInterval?
    
    @IBOutlet weak var methodStatus: UILabel!
    @IBOutlet weak var touchStatus: UILabel!
    @IBOutlet weak var tapStatus: UILabel!
    @IBOutlet weak var textField: UITextField!
    
    @IBAction func doneButton(sender: AnyObject) {
        exit (0)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func touchesBegan (touches: NSSet, withEvent event: UIEvent) {
        self.view.endEditing(true)
        touchDown = NSDate().timeIntervalSince1970
    }
    
    override func touchesEnded (touches: NSSet, withEvent event: UIEvent) {
        var delay: Float = (textField.text as NSString).floatValue
        let ti = NSTimeInterval (delay)
        NSThread.sleepForTimeInterval (ti)
        
        touchUp = NSDate().timeIntervalSince1970
        
        let elapsedTime = Int (touchUp! * 1000 - touchDown! * 1000)
        methodStatus.text = "\(elapsedTime) ms"
        var touchCount = touches.count
        touchStatus.text = String (touchCount)
        
        var tapCount = (touches.anyObject() as UITouch).tapCount as Int
        tapStatus.text = String (tapCount)
    }
}


