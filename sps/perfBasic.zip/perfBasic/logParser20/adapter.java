package logParser20;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import java.util.StringTokenizer;

public class adapter {
    public static PrintWriter apfWriter;
    public static String description = "test";
    public static String adapter = "standard";
    public static String logFileName = "";
    public static String inputFileDir = "";
    public static String apfInputFileName = "";
    public static String fileNamePrefix = "";
    public static String[] ignoreLinesIdentifiers;

    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();
        init();
        utility.display("convert log file: " + params.logFileName);
            if (adapter.equalsIgnoreCase("customAdapter")) {
                customAdapter.convertLogFile(getInputFilename(), apfInputFileName,
                    ignoreLinesIdentifiers);
            } else if (adapter.equalsIgnoreCase("standard")) {
                System.out.println("Error: use a non-standard adapter");
            }
        long endTime = System.currentTimeMillis();
        System.out.println("Time spent for converting custom log fie: " +
            (endTime - startTime) + " milliseconds");
    }

    public static void init () {
        InputStream adapterPropsFile;        
        InputStream logPropsFile;
        Properties adapterProps = new Properties();
        Properties logProps = new Properties();
        try {
            adapterPropsFile = new FileInputStream(System
                            .getProperty("user.dir")
                + "/adapter.properties");
            adapterProps.load(adapterPropsFile);
            adapter = adapterProps.getProperty("adapter");
            inputFileDir = System.getProperty("user.dir") + "/"
                + adapterProps.getProperty("inputFileDir");
            logFileName = adapterProps.getProperty("logFileName");
           
            logPropsFile = new FileInputStream(System
                            .getProperty("user.dir")
                + "/log.properties");
            logProps.load(logPropsFile);
            String ignoreLinesStrings = logProps
                            .getProperty("ignoreLines");
            ignoreLinesIdentifiers = getIdentifies(ignoreLinesStrings);
            String logFileNamePrefix = logFileName.substring(0,
                logFileName.indexOf("."));
            apfInputFileName = inputFileDir + "/" + logFileNamePrefix
                + ".apf";
        } catch (IOException io) {
            utility.display("Failed to read "
                + "properties file ... " + io.getMessage());
            System.exit(-1);
        }
    }

    public static String[] getIdentifies(String s) {
        String stringContent = s.substring(1, s.length() - 1);
        StringTokenizer st = new StringTokenizer(stringContent, ",");
        int tokenCount = st.countTokens();
        System.out.println ("ignoreLinesIdentifiers: " + s);
        String[] identifiers = new String[tokenCount];
        for (int i = 0; i < tokenCount; i++) {
            identifiers[i] = st.nextToken().trim();
            identifiers[i] = identifiers[i].substring(1,
                identifiers[i].length() - 1);
        }
        return identifiers;
    }

    public static String getInputFilename() {
        return inputFileDir + "/" + logFileName;
    }
}
