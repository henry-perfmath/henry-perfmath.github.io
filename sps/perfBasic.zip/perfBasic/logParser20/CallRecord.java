package logParser20;

public class CallRecord {
    int threadId;

    int hashCode;

    int elapsedTime;

    int callCount;

    String text;

    public CallRecord(int elapsedTime, int threadId, int callCount,
                    String text) {
        this.threadId = threadId;
        this.hashCode = text.hashCode();
        this.elapsedTime = elapsedTime;
        this.callCount = callCount;
        this.text = text;
    }

    public int getThreadId() {
        return threadId;
    }

    public void setThreadId(int threadId) {
        this.threadId = threadId;
    }

    public int getHashCode() {
        return hashCode;
    }

    public void setHashCode(int hashCode) {
        this.hashCode = hashCode;
    }

    public int getElapsedTime() {
        return elapsedTime;
    }

    public void setElapsedTime(int elapsedTime) {
        this.elapsedTime = elapsedTime;
    }

    public int getCallCount() {
        return callCount;
    }

    public void setCallCount(int callCount) {
        this.callCount = callCount;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
