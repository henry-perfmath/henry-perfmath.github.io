package logParser20;
/*
 * Test program designed to test the correctness of the profiling
 * enabling program perfTest.java @author henry h liu 2007
 */
public class perfLogTest {
    String desc = "Java program for testing perfLog.java";

    // This is a commment line
    /*
     * This is a comment block
     */
    // Constructor

    public perfLogTest(String desc) {
        this.desc = desc;
    }
    public void perfLogCommentTest () {
       /************************/
       /* RETRIEVE the osclass */
       /************************/
       int x = 0;
       }
    // getter - typed method
    public String getDesc() {
        return desc;
    }

    // setter - non-typed method
    public void setDesc(String s) {
        desc = s;
    }

    /*
     * keyword return contained in a String; muliple instances of the
     * keyword return in an if-return statement; last return statement
     * containing return keyword in a String
     */
    public String returnTest0() {
        String x = " split return ";
        if (x.equals(" \\ \" return" + " \\ return "))
            return "return"; // return return
        return x + " return split in two lines ";
    }

    // return in two split lines
    public String returnTest1() {
        String xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx = " split return ";
        return xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
            + " return split in two lines ";
    }

    // return in string, followed by a real return statement
    public String returnTest2() {
        String x = " return in if line";
        if (x.length() > 1)
            x = " return test 2 "; // return in string
        return x + " return in if line ";
    }

    // return in a string in a separate line of an if statement; two
    // return statements, one in an if statement and the other in a
    // block
    public String returnTest3() {
        String x = " return in comment line";
        if (x.length() > 1)
            x = " return test 3 "; // return in string
        if (x.equals("y"))
            return (x + " return and if on the same line");
        {
            return x + " return in two lines ";
        }
    }

    // inner class test
    public class inner {
        int x = 0;

        public inner(int x0) {
            x = x0;
        }

        public int getX() {
            return x;
        }

        public void setX(int i) {
            x = i;
        }
    }
}
