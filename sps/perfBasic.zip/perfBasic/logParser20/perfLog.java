package logParser20;

import java.io.*;
import java.util.*;

/**
 * This program scans java source files in sourceDir directory, adds
 * profiling start and end statements to each method , and writes
 * modified java source files to targetDir directory.
 * @author henry h. liu 2007
 */
public class perfLog {

    static String mainAddProfilingBeginAfter;

    static String mainAddProfilingEndAfter;

    static PrintWriter fileWriter;

    static String logPerfDataMethodName;

    static String createApfWriterMethodName;
    static String debug;

    public static void main(String[] args) {
        Properties apfProps = getPropertiesHandle();
        mainAddProfilingBeginAfter = apfProps
                        .getProperty("mainAddProfilingBeginAfter");
        mainAddProfilingEndAfter = apfProps
                        .getProperty("mainAddProfilingEndAfter");
        System.out.println(mainAddProfilingBeginAfter);
        System.out.println(mainAddProfilingEndAfter);
        String sourceDir = apfProps.getProperty("sourceDir");
        String targetDir = apfProps.getProperty("targetDir");
        debug = apfProps.getProperty("debug", "off");
        System.out.println("debug " + debug);
        logPerfDataMethodName = apfProps
                        .getProperty("logPerfDataMethodName");
        createApfWriterMethodName = apfProps
                        .getProperty("createApfWriterMethodName");
        ArrayList files = getFiles(new File(sourceDir));
        processFiles(files, targetDir);
    }

    /**
     * sets Properties for getting source and target directory
     * locations specified in apf.properties file.
     */
    public static Properties getPropertiesHandle() {
        Properties apfProps = new Properties();
        try {
            FileInputStream in = new FileInputStream(System
                            .getProperty("user.dir")
                + "/apf.properties");
            apfProps.load(in);
            in.close();
        } catch (IOException ioe) {
            System.out
                            .println("Error in reading apf.properties file");
        }
        return apfProps;
    }

    /**
     * creates a file writer given a file path
     */
    public static PrintWriter createWriter(String fileName) {
        PrintWriter fileWriter = null;
        try {
            fileWriter = new PrintWriter(new FileWriter(fileName),
                            true);
        } catch (IOException ioe) {
            System.out.println("Error in creating writer with "
                + fileName);
        }
        return fileWriter;
    }

    /**
     * creates a file reader given a file path
     */
    public static BufferedReader createReader(String fileName) {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(fileName));
        } catch (IOException ioe) {
            System.out.println(fileName + " not found");
        }
        return reader;
    }

    /**
     * gets a list of java source files in the specified source
     * directory
     */
    public static ArrayList getFiles(File dir) {
        String[] allFiles = dir.list();
        ArrayList files = new ArrayList();
        for (int i = 0; i < allFiles.length; i++) {
            if (allFiles[i].endsWith(".java")) {
                System.out.println(dir + "\\" + allFiles[i]);
                files.add(dir + "\\" + allFiles[i]);
            }
        }
        return files;
    }

    /**
     * gets the java class name to be appended to the method name so
     * that APIs can be easily identified in the performance log data.
     */
    public static String getClassName(String fileName) {
        int start = fileName.lastIndexOf("\\") + 1;
        int end = fileName.lastIndexOf(".");
        String className = fileName.substring(start, end);
        return className;
    }

    /**
     * reads each java source file, and inserts begin and end
     * profiling statements as appropriate
     */
    public static void processFiles(ArrayList fileNames,
                    String targetDir) {
        for (int i = 0; i < fileNames.size(); i++) {
            String fileName = fileNames.get(i).toString();
            String targetFile = targetDir
                + fileName.substring(fileName.lastIndexOf("\\") + 1);
            fileWriter = createWriter(targetFile);
            addProfiling(fileName);
            fileWriter.close();
        }
    }

    /**
     * returns true if the current statement is a class begin line,
     * false otherwise. assumes that each method is preceded with an
     * access specifier
     */
    public static boolean isClassBeginLine(String line) {
        boolean IsClassBeginLine = false;
        if (hasAccessSpecifier(line) && line.contains("class ")) {
            IsClassBeginLine = true;
        }
        return IsClassBeginLine;
    }

    /**
     * returns true if the current statement is a method begin line,
     * false otherwise. assumes that each method is preceded with an
     * access specifier
     */
    public static boolean isMethodBeginLine(String line) {
        boolean isMethodBeginLine = true;
        if (!hasAccessSpecifier(line) || !line.contains("(")
            || line.endsWith(";") || line.startsWith("//")
            || line.contains("class ") || line.length() < 3) {
            isMethodBeginLine = false;
        }
        return isMethodBeginLine;
    }

    /**
     * returns true if the current statement is a return statement,
     * false otherwise.
     */
    public static boolean isReturnStatement(String line,
                    String methodName) {
        boolean isReturnLine = false;
        String testLine = removeAppendedComment(line);
        if (testLine.trim().startsWith("return")
            && !isLiteral(testLine, "return ")) {
            isReturnLine = true;
        }
        return isReturnLine;
    }

    /**
     * returns true if the current statement is a method end line,
     * false otherwise.
     */
    public static boolean isMethodEndLine(String line,
                    String methodName, int scopeLevel, int classLevel) {
        boolean isEndLine = methodName.length() > 0
            && scopeLevel == classLevel;
        // if (isArrayInitializer (line)) {
        // isEndLine = false;
        // }
        return isEndLine;
    }

    /**
     * extracts the name of the method using "(" as token delimiter
     */
    public static String getMethodName(String line) {
        String methodName = "";
        StringTokenizer st = new StringTokenizer(line, " ");
        int numTokens = st.countTokens();
        String previousToken = st.nextToken();
        for (int i = 0; i < numTokens - 1; i++) {
            String token = st.nextToken();
            if (token.startsWith("(")) {
                methodName = previousToken;
            } else if (token.contains("(")) {
                methodName = token.substring(0, token.indexOf(("(")));
            } else {
                previousToken = token;
            }
        }

        return methodName;
    }

    /**
     * check whether delim is part of a literal
     */
    public static boolean isLiteral(String line, String delim) {
        int currentIndex = line.indexOf(delim);
        if (currentIndex == 0) {
            return false;
        }
        int leftCharIndex = currentIndex - 1;
        char leftChar = 'A';
        char rightChar = 'B';
        if (leftCharIndex > 0) {
            leftChar = line.charAt(leftCharIndex);
            while (leftChar == ' ' && leftCharIndex > 0) {
                leftChar = line.charAt(--leftCharIndex);
            }
        }
        int rightCharIndex = currentIndex + 1;
        rightChar = line.charAt(rightCharIndex);
        while (rightChar == ' ' && rightCharIndex >= 0) {
            rightChar = line.charAt(++rightCharIndex);
        }
        return (leftChar == '"' && rightChar == '"');
    }

    /**
     * counts the number of "{" or "}" to help identify at which level
     * the cuttent statement is. Those in Strings should not be
     * counted
     */
    public static int countBrackets(String line, String delim) {
        int count = 0;
        int currentIndex = line.indexOf(delim);
        while (currentIndex >= 0) {
            String checkString = line.substring(currentIndex);
            if (!isLiteral(checkString, delim)
                && !checkString.contains("\\")) {
                count++;
            }
            currentIndex = line.indexOf(delim, currentIndex + 1);
        }
        return count;
    }

    /**
     * counts the number of "{" or "}" to help identify at which level
     * the cuttent statement is. Those in Strings should not be
     * counted
     */
    public static int countStrings(String line, String delim) {
        int count = 0;
        int currentIndex = line.indexOf(delim);
        while (currentIndex >= 0) {
            count++;
            currentIndex = line.indexOf(delim, currentIndex + 1);
        }
        return count;
    }

    /**
     * counts the net number of "{" or "}" in a line
     */
    public static int countLeftBrackets(String line) {
        return (countBrackets(line, "{") - countBrackets(line, "}"));
    }

    /**
     * processes comment statements
     */
    public static String processComment(BufferedReader reader,
                    String line) {

        while (line.trim().startsWith("//")
            || line.trim().startsWith("/*")) {
            if (line.trim().startsWith("//")
                || (line.trim().startsWith("/*") && line.trim()
                                .endsWith("*/"))) {
                printSourceLine(line);
                line = readNextLine(reader);
            } else if (line.trim().startsWith("/*")) {
                while (!line.trim().endsWith("*/")) {
                    printSourceLine(line);
                    line = readNextLine(reader);
                }
                if (line.trim().endsWith("*/")) {
                    printSourceLine(line);
                    line = readNextLine(reader);
                }
            }
        }
        return line;
    }

    /**
     * returns true if is a profiled method
     */
    public static boolean isProfiledMethod(String methodName) {
        boolean isProfiled = true;
        String testString = methodName.replaceAll("_", ".");
        if (testString.contains(perfLog.createApfWriterMethodName)
            || testString.contains(perfLog.logPerfDataMethodName)) {
            isProfiled = false;
        }
        return isProfiled;
    }

    /**
     * processes method line
     */
    public static String processMethodBeginLine(
                    BufferedReader reader, String className,
                    String line) {
        String methodLine = "";
        String methodName = "";
        while (!line.contains("{")) {
            printSourceLine(line);
            methodLine = methodLine + line.trim();
            line = readNextLine(reader);
        }
        printSourceLine(line);
        methodLine = methodLine + line.trim();
        methodName = className + "_" + getMethodName(methodLine);
        if (isProfiledMethod(methodName)
            && !methodName.endsWith("main")) {
            fileWriter.println("\t\t" + logPerfDataMethodName
                + " (\"" + getLogFormat(methodName, true) + "\");");
        }
        return methodLine;
    }

    /**
     * processes if (x) return (y) statement.
     */
    public static int isIfReturnOnOneLine(String line) {
        int count = line.length();
        int i = line.indexOf("(") + 1;
        while (line.charAt(i) != ')' && i < count -1 ) {
            if (line.charAt(i) == '(') {
                count++;
            } else if (line.charAt(i) == ')') {
                count--;
            }
            i = i + 1;
        }
        return line.indexOf(" return", i);
    }

    /**
     * prints if (x) return (y) line
     */
    public static void printIfReturnLine(String line, int splitMark,
                    String methodName) {
        printSourceLine(line.substring(0, splitMark));
        printSourceLine("\t\t{");
        printSourceLine("\t\t" + logPerfDataMethodName + " (\""
            + getLogFormat(methodName, false) + "\");");
        printSourceLine(line.substring(splitMark + 1, line.length()));
        printSourceLine("\t\t}");
    }

    /**
     * prints return (y) line or split return line
     */
    public static void printReturnLine(BufferedReader reader,
                    String line, String methodName) {
        printSourceLine("\t\t{");
        printSourceLine("\t\t" + logPerfDataMethodName + " (\""
            + getLogFormat(methodName, false) + "\");");
        while (!line.contains(";")) {
            printSourceLine(line);
            line = readNextLine(reader);
        }
        printSourceLine(line);
        printSourceLine("\t\t}");
    }

    /**
     * processes return statements. test cases: 1) regular (return x;)
     * 2) split return (return x + y;) 3) (x = y; // ... return ...)
     * 4) {return x;} 5) if (x) return y;
     */
    public static boolean processReturnLine(BufferedReader reader,
                    String line, String methodName) {
        boolean isReturnProcessed = false;
        if (isProfiledMethod(methodName)) {
            printReturnLine(reader, line, methodName);
            isReturnProcessed = true;

        } else {
            printSourceLine(line);
        }
        return isReturnProcessed;
    }

    /**
     * return the type of a method
     */
    public static boolean getMethodType(String line) {
        return (!line.contains(" void "));
    }

    /**
     * processes method line
     */
    public static void processMethodEndLine(String line,
                    boolean isReturnProcessed, String methodName) {
        if (isProfiledMethod(methodName) && !isReturnProcessed) {
            printSourceLine("\t\t" + logPerfDataMethodName + " (\""
                + getLogFormat(methodName, false) + "\");");
            if (methodName.endsWith("main")) {
                fileWriter.println("\t\t"
                    + perfLog.mainAddProfilingEndAfter);
            }
        }
        printSourceLine(line);
    }

    /**
     * check if the method has execcisive exits (not well formed)
     */
    public static void checkWellFormed(boolean isTyped,
                    String methodName, int numOfReturn) {
        if (isTyped && numOfReturn > 1) {
            System.out.println(methodName
                + " not well-formed (typed: " + numOfReturn
                + " exits)");
        } else if (!isTyped && numOfReturn > 0) {
            System.out.println(methodName
                + " not well-formed (void: " + numOfReturn
                + " exits)");
        }
    }

    /**
     * removes appending comment if any
     */
    public static String removeAppendedComment(String line) {
        int indexComment = line.indexOf("//");
        String testLine = line;
        if (indexComment > 0) {
            testLine = line.substring(0, indexComment);
        }
        return testLine;
    }

    /**
     * reads the next line
     */
    public static String readNextLine(BufferedReader reader) {
        String line = "";
        try {
            line = reader.readLine();
        } catch (IOException ioe) {
            System.out.println("Error reading next line");
        }
        return line;
    }

    /**
     * returns true if the line starts with if
     */
    public static boolean isStartsWithIf(String line) {
        return (line.trim().startsWith("if")
            || line.trim().startsWith("else if") || line.trim()
                        .startsWith("} else if"));
    }

    /**
     * processes statements starting with if. type > 0: multiple
     * continuing lines
     */
    public static int processStartsWithIf(BufferedReader reader,
                    String line, String methodName) {
        int type = -1;
        ArrayList ifLines = new ArrayList(10);
        String testLine = removeAppendedComment(line).trim();
        int lineMax = 0;
        ifLines.add(line);
        while (!testLine.endsWith(";") && !testLine.endsWith("{")) {
            line = readNextLine(reader);
            lineMax++;
            ifLines.add(line);
            testLine = removeAppendedComment(line).trim();
        }

        if (testLine.endsWith(";")) {
            if (testLine.contains(" return ")
                || testLine.contains(" return;")) {
                int splitMark = isIfReturnOnOneLine(testLine);
                if (splitMark > 0) {
                    printIfReturnLine(testLine, splitMark, methodName);
                }
            } else {
                for (int i = 0; i <= lineMax; i++) {
                    printSourceLine(ifLines.get(i).toString());
                }
            }
        } else {
            for (int i = 0; i <= lineMax; i++) {
                printSourceLine(ifLines.get(i).toString());
            }
            type = lineMax;
        }
        return type;
    }

    /**
     * 
     */
    public static String getScope(BufferedReader reader, String line) {
        String scope = " ";
        String testLine = removeAppendedComment(line);
        if (testLine.trim().startsWith("if ")
            || testLine.trim().startsWith("else if")) {
            scope = "if";
        } else if (testLine.trim().startsWith("for ")) {
            scope = "for";
        } else if (testLine.trim().startsWith("while ")) {
            scope = "while";
        } else if (testLine.trim().startsWith("do ")) {
            scope = "do";
        } else if (testLine.trim().startsWith("try ")) {
            scope = "try";
        } else if (testLine.trim().startsWith("} catch (")) {
            scope = "catch";
        } else if (testLine.trim().startsWith("switch ")) {
            scope = "switch";
        } else if (testLine.trim().startsWith("static {")) {
            scope = "static";
        } else if (isArrayInitializer(reader, line) > 0) {
            scope = "array initializer";
        }
        return scope;
    }

    public static int isArrayInitializer(BufferedReader reader,
                    String line) {
        int status = -1;
        if (line.contains("[]") && line.contains("]")
            && line.contains("=") && line.contains(" {")) {
            ArrayList ifLines = new ArrayList(10);
            String testLine = removeAppendedComment(line).trim();
            int lineMax = 0;
            ifLines.add(line);
            while (!testLine.endsWith("};")) {
                line = readNextLine(reader);
                lineMax++;
                ifLines.add(line);
                testLine = removeAppendedComment(line).trim();
            }
            for (int i = 0; i <= lineMax; i++) {
                printSourceLine(ifLines.get(i).toString());
            }
            if (testLine.endsWith("};"))
                status = lineMax;
        }
        return status;
    }

    public static String getDebugInfo(Stack stack, int classLevel,
                    int scopeLevel) {
    	String debugInfo = " ";
    	if (!stack.isEmpty()) {
    		debugInfo = stack.peek().toString() + ":"
            	+ stack.size() + ":" + classLevel + ":" + scopeLevel;
    	} 
        return debugInfo;
    }

    /**
     * adds profiling statements
     */
    public static void addProfiling(String fileName) {
        BufferedReader reader = createReader(fileName);

        String line = "";
        int numOfStart = 0;
        int numOfEnd = 0;
        int numOfReturn = 0;
        int classLevel = 0;
        int scopeLevel = 0;
        String methodName = "";
        String debugInfo = "";
        boolean isTypedMethod = false;
        boolean isReturnProcessed = false;
        String className = getClassName(fileName);
        Stack scopeStack = new Stack();
        scopeStack.push("root");
        String scope = "root";
        while ((line = readNextLine(reader)) != null) {
            line = processComment(reader, line);
            int scopeLevelChange = countLeftBrackets(line);
            scopeLevel = scopeLevel + scopeLevelChange;
            scope = " ";
            if (scopeLevelChange > 0) {
                scope = getScope(reader, line);
                if (scope != " ") {
                    scopeStack.push(scope);
                }
            } else if (scopeLevelChange < 0) {
                scopeStack.pop();
            }
            if (scope.equals("array initializer")) {
                scopeStack.pop();
                scopeLevel--;
            } else if (isClassBeginLine(line)) {
                scopeStack.push("class");
                classLevel++;
                debugInfo = getDebugInfo(scopeStack, classLevel,
                    scopeLevel);
                printSourceLine(line, debugInfo);
            } else if (isStartsWithIf(line)) {
                if (processStartsWithIf(reader, line, methodName) > 0) {
                    scopeStack.push("if");
                    scopeLevel++;
                }
            } else if (isMethodBeginLine(line)) {
                scopeStack.push("method");
                isReturnProcessed = false;
                numOfReturn = 0;
                String methodLine = processMethodBeginLine(reader,
                    className, line);
                isTypedMethod = getMethodType(methodLine);
                numOfStart++;
                if (!line.trim().equalsIgnoreCase(methodLine.trim())) {
                    scopeLevel++;
                }
                methodName = className + "_"
                    + getMethodName(methodLine);
            } else if (isReturnStatement(line, methodName)) {
                isReturnProcessed = processReturnLine(reader, line,
                    methodName);
                numOfReturn++;
            } else if (isMethodEndLine(line, methodName, scopeLevel,
                classLevel)) {
                processMethodEndLine(line, isReturnProcessed,
                    methodName);
                numOfEnd++;
                checkWellFormed(isTypedMethod, methodName,
                    numOfReturn);
                methodName = "";
            } else {
                debugInfo = getDebugInfo(scopeStack, classLevel,
                    scopeLevel);
                printSourceLine(line, debugInfo);
                processMainMethodProfiling(line, methodName);
            }
        }
        try {
            reader.close();
        } catch (IOException ioe) {
        }
        System.out.println(fileName + ": numOfStart = " + numOfStart
            + " numOfEnd = " + numOfEnd + "\n");
    }

    /**
     * returns true if the line contains method access specifier,
     * false otherwise
     */
    public static boolean hasAccessSpecifier(String line) {
        String[] tokens = { "public ", "private ", "protected ",
                        "final ", "native ", "synchronized " };
        boolean hasIt = false;
        for (int i = 0; i < tokens.length; i++) {
            if (line.contains(tokens[i])) {
                hasIt = true;
            }
        }
        return hasIt;
    }

    public static void processMainMethodProfiling(String line,
                    String methodName) {
        if (line.contains(perfLog.mainAddProfilingBeginAfter)) {
            fileWriter.println(line);
            fileWriter.println("\t\t" + logPerfDataMethodName
                + " (\"" + getLogFormat(methodName, true) + "\");");
        }
    }

    /**
     * prints original source lines. do not print create and close
     * writer statements in the main program
     */
    public static void printSourceLine(String line) {
        if (!line.contains(perfLog.mainAddProfilingBeginAfter)
            && !line.contains(perfLog.mainAddProfilingEndAfter)) {
            fileWriter.println(line);
        }
    }

    public static void printSourceLine(String line, String debugInfo) {
        if (!line.contains(perfLog.mainAddProfilingBeginAfter)
            && !line.contains(perfLog.mainAddProfilingEndAfter)) {
            if (debug.equals("on")) {
                fileWriter.println(line + "//" + debugInfo);
            } else {
                fileWriter.println(line);
            }
        }
    }

    /**
     * Specifies API signature for beginning and ending profiling
     * statements to signify beginning or eneding of a method; other
     * log entries are composed in application source files
     */
    public static String getLogFormat(String methodName,
                    boolean isStart) {
        String format = "";
        if (isStart) {
            format = "+" + methodName;
        } else {
            format = "-" + methodName + " OK";
        }
        return format;
    }
}
