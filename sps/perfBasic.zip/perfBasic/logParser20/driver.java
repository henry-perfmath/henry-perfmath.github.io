package logParser20;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;

import logParser20.logReader;
import logParser20.params;
import logParser20.parser;
import logParser20.utility;

public class driver {
    public static PrintWriter apfWriter;

    public static void main(String[] args) {
        String apfLogFile = System.getProperty("apfLogFileName");
        if (apfLogFile != null) {
            createApfWriter(apfLogFile);
        }
        long startTime = System.currentTimeMillis();
        params.init();
        utility.display("parsing log file: " + params.logFileName);

        if (params.logFileIsSortedByThread) {
            utility.display("skip reading mixed data files ...");
            logReader.getThreadInfo(params.threadInfoFileName);
        } else {
            utility.display("reading raw data files ...");
            logReader.sortLogByThread();
        }
        parser Parser = new parser();
        Parser.processLogByThread();
        utility.display("Total processing time = "
            + (System.currentTimeMillis() - startTime) + " ms");
        params.sumWriter.close();
        if (apfWriter != null) {
            apfWriter.close();
        }

    }

    public static void createApfWriter(String apfFileName) {
        try {
            apfWriter = new PrintWriter(new FileWriter(apfFileName),
                            true);
        } catch (IOException ioe) {
            utility.display("Error in creating writer with "
                + apfFileName);
        }
    }
}
