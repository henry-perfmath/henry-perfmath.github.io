package logParser20;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.GregorianCalendar;
import java.util.Stack;

public class utility {
    public static String getLogDate(String arsDate) {
        int lastIndex = arsDate.lastIndexOf(" ");
        String logDate = arsDate.substring(4, lastIndex);
        return logDate;
    }

    public static String getLogTime(String arsDate) {
        int lastIndex = arsDate.lastIndexOf(" ");
        String logTimeInMS = arsDate.substring(lastIndex, arsDate
                        .length());
        return logTimeInMS;
    }

    public static boolean sameDay(String date1, String date2) {
        return (date1.equalsIgnoreCase(date2));
    }

    // calculate elapsed time given two ars time stamps
    public static long getElapsedTime(String date1, String date2) {
        long delta = 0;
        if (getLogDate(date1).equalsIgnoreCase(getLogDate(date2))) {
            delta = getLogTimeInMS(date2, true)
                            - getLogTimeInMS(date1, true);
        } else {
            delta = getLogTimeInMS(date2, false)
                            - getLogTimeInMS(date1, false);
        }
        return delta;
    }

    public static long getCombinedTimeInMS(long t1Start, long t1End,
                    long t2Start, long t2End) {
        long delta = 0;
        long delta1 = t1End - t1Start;
        long delta2 = t2End - t2Start;
        display("t1Start = " + t1Start + " t1End = " + t1End
                        + " t2Start = " + t2Start + " t2End = "
                        + t2End);
        if (delta1 * delta2 == 0 || t1End <= t2Start
                        || t2End <= t1Start) { // no overlap
            delta = delta1 + delta2;
        } else if ((t1Start <= t2Start) && (t1End >= t2End)) { // t2
                                                                // within
                                                                // t1
            delta = delta1;
        } else if (t2Start <= t1Start && t2End >= t1End) { // t1
                                                            // within
                                                            // t2
            delta = delta2;
        } else if ((t1Start <= t2Start) && (t1End > t2Start)) { // t1
                                                                // t2
                                                                // overlap
                                                                // (t1
                                                                // earlier)
            delta = t2End - t1Start;
        } else if ((t2Start <= t1Start) && (t2End > t1Start)) { // t1
                                                                // t2
                                                                // overlap
                                                                // (t2
                                                                // earlier)
            delta = t1End - t2Start;
        }
        display("delta1 = " + delta1 + " delta2 = " + delta2
                        + " delta = " + delta);
        return delta;
    }

    public static void display(String s) {
        System.out.println(s);
    }

    public static long getLogTimeInMS(String logTimeStamp,
                    boolean excludeDate) {
        long timeInMillis = 0;
        // display(arsTimeStamp + " " + arsTimeStamp.length());
        String hour = logTimeStamp.substring(16, 18);
        String minute = logTimeStamp.substring(19, 21);
        String second = logTimeStamp.substring(22, 24);
        String milliSecond = logTimeStamp.substring(25, 29);

        GregorianCalendar thisDate;
        if (excludeDate) { // return time portion only
            timeInMillis = (Integer.parseInt(hour)) * 3600000
                            + (Integer.parseInt(minute)) * 60000
                            + (Integer.parseInt(second)) * 1000;

        } else {
            String month = logTimeStamp.substring(4, 7);
            String date = logTimeStamp.substring(8, 10);
            String year = logTimeStamp.substring(11, 15);

            thisDate = new GregorianCalendar(Integer.parseInt(year),
                            getMonth(month), Integer.parseInt(date),
                            Integer.parseInt(hour), Integer
                                            .parseInt(minute),
                            Integer.parseInt(second));
            timeInMillis = thisDate.getTimeInMillis();
        }
        // display("1st part = " + timeInMillis + " 2nd part = " +
        // Integer.parseInt(milliSecond) / 10);
        timeInMillis = timeInMillis + Integer.parseInt(milliSecond)
                        / 10; // myst deivide it by 10
        return timeInMillis;
    }

    public static int getMonth(String month) {
        int monthNum = 0;
        if (month.equalsIgnoreCase("Feb")) {
            monthNum = 1;
        } else if (month.equalsIgnoreCase("Mar")) {
            monthNum = 2;
        }
        if (month.equalsIgnoreCase("Apr")) {
            monthNum = 3;
        }
        if (month.equalsIgnoreCase("May")) {
            monthNum = 4;
        }
        if (month.equalsIgnoreCase("Jun")) {
            monthNum = 5;
        }
        if (month.equalsIgnoreCase("Jul")) {
            monthNum = 6;
        }
        if (month.equalsIgnoreCase("Aug")) {
            monthNum = 7;
        }
        if (month.equalsIgnoreCase("Sep")) {
            monthNum = 8;
        }
        if (month.equalsIgnoreCase("Oct")) {
            monthNum = 9;
        }
        if (month.equalsIgnoreCase("Nov")) {
            monthNum = 10;
        }
        if (month.equalsIgnoreCase("Dec")) {
            monthNum = 11;
        }
        return monthNum;
    }

    public static PrintWriter createWriter(String fileName) {
        PrintWriter writer;
        try {
            writer = new PrintWriter(new FileWriter(fileName), true);
        } catch (IOException ioe) {
            display("cannot create writer with " + fileName);
            writer = null;
        }
        return writer;
    }

    public static void println(PrintWriter pw, String s,
                    boolean startWithBlankLine) {
        if (startWithBlankLine)
            pw.println("");
        pw.println(s);
    }

    public static BufferedReader createReader(String fileName) {
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(fileName));
        } catch (IOException ioe) {
            display("cannot create reader with" + fileName);
            reader = null;
        }
        return reader;
    }

    public static String getNamespace(Stack stack) {
        Object obj = stack.peek();
        Node n = (Node) (stack.peek());
        String namespace = n.getNamespace() + "." + n.getName();

        return namespace;
    }

    public static void logPerfData(String APISignature) {
        if (params.profilingOn) {
            driver.apfWriter.println("API" + "," + "88" + ","
                            + System.currentTimeMillis() + "," + "27"
                            + "," + "fast" + "," + "00" + ","
                            + "User" + "," + APISignature);
        }

    }
}
