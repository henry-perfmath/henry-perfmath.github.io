package logParser20;

import java.io.PrintWriter;
import logParser20.Node;
public class logWriter {
    public static void logWriteNode(PrintWriter logWriter, Node node) {
        String id = node.getId();
        String name = node.getName();
        String namespace = node.getNamespace();
        long callStartTime = node.getCallStartTime();
        long callEndTime = node.getCallEndTime();
        int timeSum = node.getElapsedTimeSum();
        int callCountSum = node.getCallCountSum();
        String nodeType = node.getType();

        logWriter.println("<treenode namespace=" + "\"" + namespace
            + "\" id=\"" + id + "\" name=\"" + name
            + "\" callStartTime=\"" + callStartTime
            + "\" callEndTime=\"" + callEndTime + "\" timeSum=\""
            + timeSum + "\" callCountSum=\"" + callCountSum
            + "\" nodeType=\"" + nodeType + "\">");
        logWriteNodeProperty(logWriter, name);
    }

    public static void logWriteNodeProperty(PrintWriter logWriter,
                    String userObject) {
        String CSSclass = "API";
        logWriter.println("<property name=\"userObject\">"
            + userObject + "</property>");
        if (userObject.contains("SQL")) {
            CSSclass = "SQL";
        } else if (userObject.contains("FLTR")) {
            CSSclass = "FLTR";
        } else if (!userObject.contains("root")) {
            CSSclass = "API";
        }

        logWriter.println("<property name=\"CSSclass\">" + CSSclass
            + "</property>");

    }

    public static void writeDotRelation(PrintWriter logWriter,
                    String fromId, String fromName,
                    String relationId, String toId, String toName,
                    int threadId, int count, int elapsedTime) {

        // logWriter.println(toId + "[label=\"" + toId + "(" +
        // elapsedTime + ")\"];");
        String color = "blue";
        String style = "filled";
        String separator1 = " (";
        String separator2 = " / ";
        String separator3 = ")";

        int percent = (int) (elapsedTime * 100 / logReader.allThreadTimeTotal);
        
        if (percent >= params.elapsedTimePercentRed) {
            color = "red";
            style = "bold";
        }

        if (!params.dotLinkLabelHorizontal) {
            separator1 = "\\n";
            separator2 = "\\n";
            separator3 = "\\n";
        } 
        String label = percent + "%" + separator2 + elapsedTime + separator2
        + count + separator3;
        if (logReader.threadIndexMax > 1) {
            label = "T" + threadId + separator1 + label;
        }
       // String nodeLabel = "\\n(" + elapsedTime + ", " + count + ")";
        logWriter.println(fromId + "[label=\"" + fromName + "\"];");
        logWriter.println(toId + "[label=\"" + toName + "\"];");
        logWriter.println(relationId + "[style=\"" + style + "\",color=\""
            + color + "\",label=\"" + label + "\"];");
    }

    public static void writeLink(PrintWriter logWriter, Link link) {

        String fromId = link.getSourceNode().getId();
        String toId = link.getDestNode().getId();
        String name = link.getName();
        String id = link.getId();
        long elapsedTime = link.getElapsedime();
        long callStartTime = link.getDestNode().getCallStartTime();
        long callEndTime = link.getDestNode().getCallEndTime();
        int callCount = link.getCallCount();
        String isLink = link.getIsLink();
        String color = link.getColor();
        if (logReader.allThreadTimeTotal != 0
            && link.getElapsedime() * 100
                / logReader.allThreadTimeTotal >= params.elapsedTimePercentRed) {
            color = "red";
        }
        logWriter.println("<treelink from=\"" + fromId + "\" id=\""
            + id + "\" name=\"" + name + "\" islink=\"" + isLink
            + "\" to=\"" + toId + "\" callStartTime=\""
            + callStartTime + "\" callEndTime=\"" + callEndTime
            + "\" callCount=\"" + callCount + "\" elapsedTime=\""
            + elapsedTime + "\" color=\"" + color + "\">");
        logWriter.println("<property name=\"edgeLabel\">("
            + elapsedTime + " / " + callCount + ")</property>");
        logWriter.println("</treelink>");
    }

    public static void writeEndNode(PrintWriter logWriter) {
        logWriter.println("</treenode>");
    }

    public static void writeLinkProperty(PrintWriter logWriter,
                    long callCount, long elapsedTime) {
        logWriter.println("<property name=\"edgeLabel\">("
            + elapsedTime + " / " + callCount + ")</property>");
    }
}
