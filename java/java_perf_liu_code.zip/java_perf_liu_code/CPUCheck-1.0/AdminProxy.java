import java.rmi.*;
import java.rmi.registry.*;
import java.net.*;

public class AdminProxy
{
    private AdminInterface adminServer;
    private String serverAddress;
    private String serverPort;
    
    public AdminProxy (String sa, String sp)
    {
       serverAddress = sa;
       serverPort = sp;
       try{
           Registry registry=LocateRegistry.getRegistry(
               serverAddress,
               (new Integer(serverPort)).intValue()
           );
           adminServer=
              (AdminInterface)(registry.lookup("AdminServer"));
       }
       catch(RemoteException e){
           e.printStackTrace();
       }
       catch(NotBoundException e){
           e.printStackTrace();
       }
    }
    public void sendCommand (String command) {
    	try{            
            adminServer.processCommand(command);
       }
       catch(RemoteException e){
           e.printStackTrace();
        }
    }
    public void sendCommand (String[] commands) {
    	try{            
            adminServer.processCommand(commands);
       }
       catch(RemoteException e){
           e.printStackTrace();
        }
    }
}

 

