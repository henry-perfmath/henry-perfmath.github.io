import java.awt.*;
import javax.swing.tree.*;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;
import java.util.*;

public class AdminConsole extends JFrame
{  
	   private DefaultMutableTreeNode root;
	   private DefaultTreeModel model;
	   private JTree tree;
	   private Hashtable items = new Hashtable (10000);
	   private static final int WIDTH = 600;
	   private static final int HEIGHT = 800;
   public AdminConsole(String rootName)
   {  
      setTitle("Service Admin Console");
      setSize(WIDTH, HEIGHT);

      // construct tree
      root = new DefaultMutableTreeNode(rootName);
      model = new DefaultTreeModel(root);
      tree = new JTree(model);
      tree.setEditable(true);

      JScrollPane scrollPane = new JScrollPane(tree);
      getContentPane().add(scrollPane, BorderLayout.CENTER);
   }
   // add a node to root
   public void addNode (String nodeName) {
	   //System.out.println ("calling addNode: " + nodeName);
	   DefaultMutableTreeNode node = new DefaultMutableTreeNode (nodeName);
	   addNode (node);
   }
   public void addNode (DefaultMutableTreeNode node) {
	   //System.out.println ("\tcalling addNode with node " + node.toString());
	   if (!isDuplicate (root, node)) {
		   int index = root.getChildCount();
		   model.insertNodeInto(node, root, index);
	   } else {
			System.out.println ("ERROR: cannot add duplicate node  " + node.toString());
	   }
   }
   public boolean isDuplicate (DefaultMutableTreeNode parent, DefaultMutableTreeNode child) {
	   Enumeration children = parent.children();
	   boolean found = false;
	   while (children.hasMoreElements()) {
		   DefaultMutableTreeNode c = (DefaultMutableTreeNode) children.nextElement();
		   if (c.toString().equals (child.toString())) {
			   found = true;
		   }
	   }
	   return found;
   }
   // get a node as a child of the root node
   public TreeNode getNode (String path) {
	   int count = root.getChildCount();
	   TreeNode child = null;
	   String nodeName = path;
	   if (path.contains("/")) {
		   nodeName = path.substring(0, path.indexOf("/") - 1);
	   }

	   for (int i = 0; i < count; i++) {
		   child = root.getChildAt (i);
		   if (child.toString().equals(nodeName)) break;
	   }
	   return child;
   }
   public TreeNode getLeafNodeByName (String name) {
	   Enumeration depth = root.depthFirstEnumeration();
	   TreeNode node = null;
	   while (depth.hasMoreElements()) {
		   node = (TreeNode) depth.nextElement();
		   if (!node.isLeaf()) continue;
		   if (node.toString().equals(name)) break; 
	   }
	   return node;
   }
   // add a new container to an existing containee node
   public void addContainer (String container, String containee) {
	   //System.out.println ("calling addContainer");
	   DefaultMutableTreeNode p = new DefaultMutableTreeNode (container);
	   addNode(p);
	   DefaultMutableTreeNode child = (DefaultMutableTreeNode) getNode (containee);
	   if (!isDuplicate(p, child)) { 
		   p.insert(child, 0); // container is new
	   } else {
		   System.out.println ("containee duplicate " + containee );
	   }
   }
   // add an existing containee node to an existing container node
   public void addContainee (String container, String containee) {
	   //System.out.println ("calling addContainee");
	   DefaultMutableTreeNode p = (DefaultMutableTreeNode) getNode (container);
	   DefaultMutableTreeNode c = (DefaultMutableTreeNode) getNode (containee);
	   int index = p.getChildCount();
	   if (!isDuplicate(p, c)) {
		   model.insertNodeInto(c, p, index);
	   } else {
		   System.out.println ("container / containee duplicate " 
				   + container + "/" + containee );
	   }
   }
   public void addEntryToLeafNode (String leaf, String entry) {
	   //System.out.println ("calling addEntryToLeafNode: " + leaf + " " + entry);
	   DefaultMutableTreeNode p = (DefaultMutableTreeNode) getLeafNodeByName (leaf);

	   if (p != null) {
		   int index = p.getChildCount();
		   TreeNode[] path = p.getPath ();
		   String pathName = path[0].toString();
		   int count = path.length;
		   for (int i = 1; i < count; i++) {
			   pathName += "/" + path[i];
		   }
		   if (!items.containsKey (pathName)) {
			   ArrayList al = new ArrayList (1000);
			   al.add(entry);
			   items.put (pathName, al);
		   } else {
			   ArrayList al = (ArrayList) items.get (pathName);
			   al.add(entry);
			   items.put (pathName, al);
		   }		   
	   } else {
		   System.out.println ("leaf node " + leaf + " doesn't exist");
	   }
   }
   public String getLeafNodeEntryCount (String path) {
	   if (items.containsKey (path)) {
		   ArrayList al = (ArrayList) items.get(path);
		   return path + " contains " + al.size() + " entries";
	   } else {
		   return path + " entered does not exist";
	   }
   }
   public int getCount () {
	   return root.getChildCount();
   }
   public int printAllContainers () {
	   Enumeration children = root.children();
	   while (children.hasMoreElements()) {
		   DefaultMutableTreeNode c = (DefaultMutableTreeNode) children.nextElement();
		   System.out.print (c.toString() + "/");
			   
		   }
	   System.out.println ("-------");
   return getCount ();
   }
   public void reload () {
	   model.reload();
   }
   public void removeNode (String nodeName) {
	   Enumeration breadth = root.breadthFirstEnumeration();
	   TreeNode node = null;
	   while (breadth.hasMoreElements()) {
		   node = (TreeNode) breadth.nextElement();
		   if (node.toString().equals(nodeName)) {
			   model.removeNodeFromParent((DefaultMutableTreeNode)node);
			   break; 
		   }
	   }
   }
   public void removeAll () {
	 root.removeAllChildren();
   }
	public static void checkMemory(String comment) {   
		int mb = 1024*1024;
		Runtime runtime = Runtime.getRuntime();
		String printString1 = comment + " Heap utilization statistics [MB]";
		//UsedFree/Total/Max memory
		String printString2 = "Used/Free/Total/Max Memory:"
		+ (runtime.totalMemory() - runtime.freeMemory()) / mb
		+ "/" + runtime.freeMemory() / mb
		+ "/" + runtime.totalMemory() / mb
		+ "/" + runtime.maxMemory() / mb; 		
		System.out.println (printString1 + '\n' + printString2);
		}
}
