import java.io.*;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.util.*;
import java.rmi.*;

public class ServiceDirectory {
	static boolean ADD_SERVICES;
	static String SERVICE_NAME_PREFIX;
	static String TOP_SERVICE_NAME;
	public static int THREAD_COUNT_DOWN;
	public static int NUM_OF_SYSTEMS;
	public static String SERVER_ADDRESS;
	public static String SERVER_PORT;
	public static boolean USE_PROXY;
	public static AdminProxy adminProxy;
	public static int SUBSERVICES_PER_NODE;
	public static int NUM_OF_LEVELS;
	public static int NUM_OF_THREADS;
	public static int SYSTEM_START_INDEX;
	public static int SYSTEM_END_INDEX;
	public static int HEART_BEAT;
	public static int ARRAY_SIZE;
	public static int LAST_BUCKET;
	public static String ALGORITHM;
	public static boolean ADD_SYSTEMS;
	public static boolean DEBUG;
	public static boolean TRACING;
	public static String SYSTEM_NAME_PREFIX;
	public static String[] commandBuffer;
	public static PrintWriter logWriter;
	public static PrintWriter commandWriter;
	public static String commandFileName;

	public static void main(String args[]) {
		delayStart();
		long startTime = System.currentTimeMillis();
		init();
		ArrayList leafSubServiceNames = dispatch();
		checkAddServices();
		checkAddSystems(leafSubServiceNames);
		// wait to exit (for having extra time to examine memory usage ...)
		checkMemory("end:");
		String printString = "total elapsed time = "
				+ (System.currentTimeMillis() - startTime) + " ms";
		System.out.println(printString);
		logWriter.println(printString);
		if (TRACING)
			printStackTrace();
		Console console = System.console();
		String exit = console.readLine("press Enter to exit: ");
		logWriter.close();
	}

	public static void delayStart() {
		Console con = System.console();
		String input = con.readLine("continue? press Enter to go ...");
		if (input.length() >= 1)
			System.exit(0);
	}

	// initialize
	public static void init() {
		checkMemory("start:");
		String parameterFile = System.getProperty("parameterFile");
		InputStream propsFile;
		Properties props = new Properties();
		try {
			propsFile = new FileInputStream(parameterFile);
			props.load(propsFile);
		} catch (IOException io) {
			System.out.println("Failed to read " + "properties file ... "
					+ io.getMessage());
			System.exit(-1);
		}
		String SYSTEM_NAME_PREFIX = props.getProperty("SYSTEM_NAME_PREFIX",
				"sys");
		SYSTEM_START_INDEX = Integer.parseInt(props
				.getProperty("SYSTEM_START_INDEX"));
		SYSTEM_END_INDEX = Integer.parseInt(props
				.getProperty("SYSTEM_END_INDEX"));
		NUM_OF_SYSTEMS = SYSTEM_END_INDEX - SYSTEM_START_INDEX;
		NUM_OF_LEVELS = Integer.parseInt(props.getProperty("NUM_OF_LEVELS"));

		SUBSERVICES_PER_NODE = Integer.parseInt(props
				.getProperty("SUBSERVICES_PER_NODE"));

		SERVICE_NAME_PREFIX = props.getProperty("SERVICE_NAME_PREFIX", "s");
		TOP_SERVICE_NAME = props.getProperty("TOP_SERVICE_NAME",
				"\"Staging Services\"").trim();
		NUM_OF_THREADS = Integer.parseInt(props.getProperty("NUM_OF_THREADS",
				"2"));
		HEART_BEAT = Integer
				.parseInt(props.getProperty("HEART_BEAT", "100000"));
		NUM_OF_THREADS = Integer.parseInt(props.getProperty("NUM_OF_THREADS",
				"2"));
		ARRAY_SIZE = Integer.parseInt(props.getProperty("ARRAY_SIZE", "1"));
		commandBuffer = new String[ARRAY_SIZE];
		LAST_BUCKET = 0;
		initCommandBuffer();
		THREAD_COUNT_DOWN = NUM_OF_THREADS;
		ADD_SERVICES = Boolean.parseBoolean(props.getProperty("ADD_SERVICES",
				"false"));
		ADD_SYSTEMS = Boolean.parseBoolean(props.getProperty("ADD_SYSTEMS",
				"false"));
		DEBUG = Boolean.parseBoolean(props.getProperty("DEBUG", "false"));
		TRACING = Boolean.parseBoolean(props.getProperty("TRACING", "false"));
		ALGORITHM = props.getProperty("ALGORITHM", "dynamic");
		// added on 2/10/2009
		SERVER_ADDRESS = props.getProperty("SERVER_ADDRESS", "192.168.1.100");
		SERVER_PORT = props.getProperty("SERVER_PORT", "9999");
		USE_PROXY = Boolean
				.parseBoolean(props.getProperty("USE_PROXY", "true"));
		boolean CLEAR_SERVICE_TREE = Boolean.parseBoolean(props.getProperty(
				"CLEAR_SERVICE_TREE", "true"));
		if (USE_PROXY) {
			adminProxy = new AdminProxy(SERVER_ADDRESS, SERVER_PORT);
			System.out.println("admin proxy created with address and port:"
					+ SERVER_ADDRESS + ":" + SERVER_PORT);
			if (CLEAR_SERVICE_TREE) {
				adminProxy.sendCommand("removeAll");
			}
		} else {
			commandFileName = "commandFile_" + getFileNameSuffix();
			commandWriter = createWriter(commandFileName);
		}
		if (ADD_SYSTEMS) {
			createSystemFile(SYSTEM_NAME_PREFIX, SYSTEM_START_INDEX,
					SYSTEM_END_INDEX);
		}
		// calculate total # of services to create with given level and base
		System.out.println("started at " + (new Date()).toString());
		System.out.println("create a service directory tree of (l, m) = " + "("
				+ NUM_OF_LEVELS + ", " + SUBSERVICES_PER_NODE + ") with "
				+ +(1 + findEndIndex(NUM_OF_LEVELS - 1, SUBSERVICES_PER_NODE))
				+ " service nodes ");
		String logFileName = "ServiceDirectory_" + getFileNameSuffix();
		logWriter = createWriter(logFileName);
		logWriter.println("SYSTEM_NAME_PREFIX=" + SYSTEM_NAME_PREFIX);
		logWriter.println("SYSTEM_START_INDEX=" + SYSTEM_START_INDEX);
		logWriter.println("SYSTEM_END_INDEX=" + SYSTEM_END_INDEX);
		logWriter.println("TOP_SERVICE_NAME=" + TOP_SERVICE_NAME);
		logWriter.println("SERVICE_NAME_PREFIX=" + SERVICE_NAME_PREFIX);
		logWriter.println("NUM_OF_LEVELS=" + NUM_OF_LEVELS);
		logWriter.println("SUBSERVICES_PER_NODE" + SUBSERVICES_PER_NODE);
		logWriter.println("NUM_OF_THREADS=" + NUM_OF_THREADS);
		logWriter.println("ARRAY_SIZE=" + ARRAY_SIZE);
		logWriter.println("ADD_SERVICES=" + ADD_SERVICES);
		logWriter.println("ADD_SYSTEMS=" + ADD_SYSTEMS);
		logWriter.println("DEBUG=" + DEBUG);
		logWriter.println("ALGORITHM=" + ALGORITHM);
		logWriter.println("SERVER_ADDRESS=" + SERVER_ADDRESS);
		logWriter.println("SERVER_PORT=" + SERVER_PORT);
		logWriter.println("USE_PROXY=" + USE_PROXY);
		logWriter.println("clearServiceTree=" + CLEAR_SERVICE_TREE);
		logWriter.println("HEART_BEAT=" + HEART_BEAT);
	}

	public static ArrayList dispatch() {
		// add a service directory in a single thread and return names of all
		// leaf sub Services
		ArrayList leafSubServiceNames = new ArrayList(1000);
		long startTime = System.currentTimeMillis();
		if (ALGORITHM.equals("static")) {
			add5LevelServices(NUM_OF_LEVELS, SUBSERVICES_PER_NODE,
					SERVICE_NAME_PREFIX);
			System.out.println("static (total): "
					+ (System.currentTimeMillis() - startTime) + " ms");
		} else if (ALGORITHM.equals("recursive")) {
			Stack services = new Stack();
			Stack trace = new Stack();
			recur(0, NUM_OF_LEVELS, SERVICE_NAME_PREFIX, SUBSERVICES_PER_NODE,
					services, trace, leafSubServiceNames);
			String printString1 = "recursive ALGORITHM: "
					+ (System.currentTimeMillis() - startTime) + " ms";
			String printString2 = "Recursive call service tree size = "
					+ services.size();
			System.out.println(printString1 + '\n' + printString2);
			logWriter.println(printString1 + '\n' + printString2);
			processServiceTree(services, SUBSERVICES_PER_NODE);
			String printString3 = "recursive (ALGORITHM + processServiceTree): "
					+ (System.currentTimeMillis() - startTime) + " ms";
			System.out.println(printString3);
			logWriter.println(printString3);

		} else if (ALGORITHM.equals("dynamic")) {
			leafSubServiceNames = createServiceDirectory(NUM_OF_LEVELS,
					SUBSERVICES_PER_NODE, SERVICE_NAME_PREFIX);
			System.out.println("dynamic: "
					+ (System.currentTimeMillis() - startTime) + " ms");
		} else {
			System.out.println("ALGORITHM " + ALGORITHM + " doesn't exist");
			System.exit(0);
		}
		return leafSubServiceNames;
	}

	public static void checkAddServices() {
		if (ADD_SERVICES && !USE_PROXY) {
			System.out.println("adding service directory ...");
			long startTime = System.currentTimeMillis();
			executeCommand();
			System.out.println("Adding service directory: "
					+ (System.currentTimeMillis() - startTime) + " ms");
		}
	}

	public static void checkAddSystems(ArrayList leafSubServiceNames) {
		if (ADD_SYSTEMS) {
			System.out.println("adding systems to "
					+ leafSubServiceNames.size() + " leaf node services ...");
			int ServiceStartIndex = 0;
			int ServiceEndIndex = leafSubServiceNames.size() - 1;

			int systemsPerThread = (int) ((SYSTEM_END_INDEX
					- SYSTEM_START_INDEX + 1 + 0.5 * NUM_OF_THREADS) / NUM_OF_THREADS);
			int ServicesPerThread = (int) ((ServiceEndIndex - ServiceStartIndex
					+ 1 + 0.5 * NUM_OF_THREADS) / NUM_OF_THREADS);
			if (systemsPerThread < 1) {
				System.out
						.println("# of systems per thread must be larger than one");
				System.exit(0);
			}
			if (ServicesPerThread < 1) {
				System.out
						.println("# of Services per thread must be larger than one");
				System.exit(0);
			}
			// use multi-threading to add systems to existing Services
			PrintWriter[] writer = new PrintWriter[20];
			long startTime = System.currentTimeMillis();
			AdminProxy[] proxies = new AdminProxy[NUM_OF_THREADS];
			if (USE_PROXY) {
				for (int i = 0; i < NUM_OF_THREADS; i++) {
					if (USE_PROXY) {
						proxies[i] = new AdminProxy(SERVER_ADDRESS, SERVER_PORT);
					} else {
						proxies[i] = null;
					}
				}
			}
			for (int i = 0; i < NUM_OF_THREADS; i++) {
				int systemStart = SYSTEM_START_INDEX + i * systemsPerThread;
				int systemEnd = SYSTEM_START_INDEX + (i + 1) * systemsPerThread
						- 1;
				int ServiceStart = ServiceStartIndex + i * ServicesPerThread;
				int ServiceEnd = ServiceStartIndex + (i + 1)
						* ServicesPerThread - 1;
				if (i == (NUM_OF_THREADS - 1)) {
					systemEnd = SYSTEM_END_INDEX;
					ServiceEnd = ServiceEndIndex;
				}
				String threadFileName = "Thread_" + i + "_"
						+ getFileNameSuffix();
				writer[i] = createWriter(threadFileName);
				ServiceThread deviceThread = new ServiceThread(proxies[i],
						SYSTEM_NAME_PREFIX, systemStart, systemEnd,
						ServiceStart, ServiceEnd, ADD_SYSTEMS, threadFileName,
						writer[i], leafSubServiceNames, "Thread_" + i);
				deviceThread.start();
				System.out.println("Thread " + i
						+ " started with leaf node services " + ServiceStart
						+ "-" + ServiceEnd + " and systems " + systemStart
						+ "-" + systemEnd);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException ie) {
					System.out.println(ie.toString());
				}
			}
		}
	}

	// create directory by calculating path
	public static ArrayList createServiceDirectory(int levelMax, int base,
			String SERVICE_NAME_PREFIX) {
		long startTime = System.currentTimeMillis();
		int count = 0;
		ArrayList leafSubServiceNames = new ArrayList(1000);
		int level = levelMax; // change to zero-based indexing
		int numOfServices = (int) Math.pow(base, level);
		System.out.println("number of leaf node sub Services to be created = "
				+ " at level " + level + " (0-based) : " + numOfServices);
		String containerServiceName = "";
		String serviceName = "";
		int beginIndex = 0;
		int endIndex = 0;
		// exclude level 0
		for (int i = level; i > 0; i--) {
			beginIndex = findBeginIndex(i - 1, base);
			endIndex = beginIndex + (int) Math.pow(base, i) - 1;
			for (int j = endIndex; j >= beginIndex; j--) {
				containerServiceName = getContainerServiceName(j, base);
				serviceName = getServiceName(containerServiceName, j, base);
				String path = findPath(j, base);
				if (i == level) {
					// leafSubServiceNames.add ("/" + path + serviceName);
					leafSubServiceNames.add(serviceName);
					if (ADD_SERVICES)
						writeService(" addNode " + serviceName);
					// count++;
					// checkHeartBeat (count, startTime);
				}
				if ((j % base) == 0) {
					if (ADD_SERVICES)
						writeService(" addContainer " + containerServiceName
								+ " " + serviceName);
				} else {
					if (ADD_SERVICES)
						writeService(" addContainee " + containerServiceName
								+ " " + serviceName);
				}
				count++;
				checkHeartBeat(count, startTime);
				// writeNode (i, base, j , containerServiceName, serviceName);
			}
		}
		String printString = "dynamic total: " + count + " nodes/"
				+ (System.currentTimeMillis() - startTime) + " ms = "
				+ (count * 1000 / (System.currentTimeMillis() - startTime))
				+ " nodes/second";
		System.out.println(printString);
		logWriter.println(printString);
		return leafSubServiceNames;
	}

	public static void writeNode(int level, int base, int j,
			String containerServiceName, String serviceName) {
		int index = (j - 1) % base;
		if (index == 0) {
			System.out.println(" | <f" + index + "> " + serviceName + " \"];");
			int parentIndex = findParentIndex(j, base);
			parentIndex = base * ((parentIndex + base - 1) / base);
			System.out.println(" \"node_" + (level - 1) + "_" + parentIndex
					+ "\":f1 -> " + " \"node_" + level + "_" + (j + base - 1)
					+ "\":f1;");
		} else if (index == (base - 1)) {
			System.out.print(" node_" + level + "_" + j + " [label = \"<f"
					+ index + "> " + serviceName);
		} else {
			System.out.print(" | <f" + index + "> " + serviceName);
		}
	}

	public static int findLevel(int m0, int base) {
		int level = 0;
		int m = 0;
		while (m < m0) {
			level++;
			m = m + (int) Math.pow(base, level);
		}
		return level;
	}

	public static int findParentIndex(int m, int base) {
		int blockNumber = findBlockNumber(m, base);
		int level = findLevel(m, base) - 1;
		int parentIndex = findBeginIndex(level - 1, base) + (blockNumber - 1);
		return parentIndex;
	}

	public static String getContainerServiceName(int m, int base) {
		String containerServiceName = "";
		if (m > base) {
			containerServiceName = SERVICE_NAME_PREFIX
					+ findParentIndexChain(m, base);
		} else if (m == 0) {
			containerServiceName = "";
		} else {
			containerServiceName = TOP_SERVICE_NAME;
		}
		// System.out.println ("m = " + m + " container = " +
		// containerServiceName + " service = " + serviceName);
		return containerServiceName;
	}

	public static String getServiceName(String containerServiceName, int m,
			int base) {
		String serviceName = "";
		serviceName = containerServiceName + (((m - 1) % base) + 1); // base = 3
		if (m > 0 && m <= base) {
			serviceName = SERVICE_NAME_PREFIX + m;
		}
		return serviceName;
	}

	public static String findParentIndexChain(int index, int base) {
		// given current index
		int i = index;
		String name = "";
		while (i > base) {
			i = findParentIndex(i, base);
			if (i > base) {
				name = (((i - 1) % base) + 1) + name;
			} else {
				name = i + name;
			}
			// System.out.println ("index = " + index + " i = " + i + " name = "
			// + name);
		}

		return name;
	}

	public static String findPath(int m, int base) {
		// given current index m
		int n = m;
		String path = "";
		String containerServiceName = "Test";
		while (!(containerServiceName = getContainerServiceName(n, base))
				.equals("")) {
			path = containerServiceName + "/" + path;
			n = findParentIndex(n, base);
		}
		return path;
	}

	public static int findBlockNumber(int m, int base) {
		int level = findLevel(m, base) - 1;
		int beginIndex = findBeginIndex(level, base);
		int blockNumber = (m - beginIndex) / base + 1;
		return blockNumber;
	}

	public static int findBeginIndex(int level, int base) {
		int beginIndex = 0;
		for (int i = 0; i <= level; i++) {
			beginIndex = beginIndex + (int) Math.pow(base, i);
		}

		return beginIndex;
	}

	public static int findEndIndex(int level, int base) {
		int endIndex = findBeginIndex(level, base)
				+ (int) Math.pow(base, level + 1) - 1;
		return endIndex;
	}

	public static String converter(int m0, int base) {
		int ak = m0 % base;
		int m = m0;
		String result = "" + ak;
		String temp = "";
		while (m > 0) {
			ak = (m / base) % base;
			if (m >= base) {
				temp = ak + temp;
			}
			m = m / base;
		}
		result = temp + result;
		return result;
	}

	public static void recur(int level, int levelMax,
			String SERVICE_NAME_PREFIX, int SUBSERVICES_PER_NODE,
			Stack services, Stack trace, ArrayList leafSubServiceNames) {
		String serviceName = "";
		String parentService = "";
		String path = "";
		level++;
		if (level >= levelMax) {
			path = getPath(trace, level);
			parentService = getParentService(path);
			String prefix = path + "/" + parentService;
			for (int j = 1; j <= SUBSERVICES_PER_NODE; j++) {
				serviceName = SERVICE_NAME_PREFIX + prefix + j;
				writeDot(parentService, parentService + j);
				leafSubServiceNames.add("" + j);
				services.push(serviceName);
			}
			trace.pop();
			return;
		} else {
			// System.out.println (" ++level = " + level + " serviceName = " +
			// serviceName);
			for (int i = 1; i <= SUBSERVICES_PER_NODE; i++) {
				path = getPath(trace, level);
				parentService = getParentService(path);
				if (level == 1) {
					parentService = SERVICE_NAME_PREFIX + "0";
					serviceName = SERVICE_NAME_PREFIX + i;
					writeDot(parentService, serviceName);
				} else {
					serviceName = path + "/" + parentService + i;
					writeDot(parentService, parentService + i);
				}
				services.push(serviceName);
				trace.push(serviceName);
				recur(level, levelMax, SERVICE_NAME_PREFIX,
						SUBSERVICES_PER_NODE, services, trace,
						leafSubServiceNames);
			}
			return;
		}
	}

	public static void writeDot(String parent, String child) {
		// System.out.println (parent + " -> " + child + ";");
	}

	public static String getPath(Stack p, int level) {
		while (p.size() >= level) {
			p.pop();
		}
		if (p.size() == 0) {
			return "";
		} else {
			return p.peek().toString();
		}
	}

	public static String getParentService(String path) {
		if (path.contains("/")) {
			return path.substring(path.lastIndexOf("/") + 1);
		} else {
			return path;
		}
	}

	public static void processServiceTree(Stack serviceTree,
			int SUBSERVICES_PER_NODE) {
		String currentService = "";
		int currentLevel = 1;
		int previousLevel = 0;
		String serviceName = "";
		String parentServiceName = "";
		Hashtable parentIdTable = new Hashtable();
		long startTime = System.currentTimeMillis();
		long keepTime = System.currentTimeMillis();
		int count = 0;
		String commandArray = "";
		while (!serviceTree.empty()) {
			currentService = serviceTree.peek().toString();
			currentLevel = getServiceLevel(currentService);
			if (currentLevel < previousLevel) { // parent
				serviceName = getServiceName(serviceTree.pop().toString());
				parentServiceName = getParentServiceName(currentService);
				String COMMAND_DIRective = checkParentNameTable(parentIdTable,
						parentServiceName);
				writeService(COMMAND_DIRective + parentServiceName + " "
						+ serviceName);
				count++;
				checkHeartBeat(count, startTime);
				previousLevel = currentLevel;
			} else {
				// process all sibling child services
				currentService = serviceTree.pop().toString();
				serviceName = getServiceName(currentService);
				parentServiceName = getParentServiceName(currentService);

				writeService(" addNode " + serviceName);
				writeService(" addContainer " + parentServiceName + " "
						+ serviceName);
				count += 1;
				checkHeartBeat(count, startTime);
				for (int i = 1; i < SUBSERVICES_PER_NODE; i++) {
					currentService = serviceTree.pop().toString();

					writeService(" addNode " + getServiceName(currentService));
					writeService(" addContainee " + parentServiceName + " "
							+ getServiceName(currentService));
					count += 1;
					checkHeartBeat(count, startTime);
				}
				previousLevel = getServiceLevel(currentService);
			}

		}
		// need to flush for batch processing
		if (USE_PROXY) {
			writeService("");
			adminProxy.sendCommand("reload");
		}
		String printString = "processing service tree: " + count + " nodes/"
				+ (System.currentTimeMillis() - startTime) + " ms = "
				+ (count * 1000 / (System.currentTimeMillis() - startTime))
				+ " nodes/second";
		System.out.println(printString);
		logWriter.println(printString);
	}

	public static void checkHeartBeat(int count, long startTime) {
		if ((count % HEART_BEAT) == 0) {
			long currentTime = System.currentTimeMillis();
			System.out.println(count + " items processed over "
					+ (currentTime - startTime) + " ms "
					+ (count * 1000.0 / (currentTime - startTime))
					+ " items / s");
		}
	}

	public static String checkParentNameTable(Hashtable ht, String name) {
		if (!ht.containsKey(name)) {
			ht.put(name, new Integer(0));
			return " addContainer ";
		} else {
			int value = ((Integer) ht.get(name)).intValue() + 1;
			ht.put(name, new Integer(value));
			return " addContainee ";
		}
	}

	public static String getServiceName(String path) {
		StringTokenizer st = new StringTokenizer(path, "/");
		String name = path;
		while (st.hasMoreTokens()) {
			name = st.nextToken();
		}
		return name;
	}

	public static String getParentServiceName(String path) {
		StringTokenizer st = new StringTokenizer(path, "/");
		String name = TOP_SERVICE_NAME;
		int count = st.countTokens();
		int index = 1;
		while (index < count) {
			name = st.nextToken();
			index++;
		}
		return name;
	}

	public static int getServiceLevel(String path) {
		StringTokenizer st = new StringTokenizer(path, "/");
		return st.countTokens();
	}

	public static void writeService(String command) {
		if (TRACING)
			printStackTrace();
		if (LAST_BUCKET == (ARRAY_SIZE - 1) || command.equals("")) {
			commandBuffer[LAST_BUCKET] = command;
			if (ADD_SERVICES && USE_PROXY) {
				adminProxy.sendCommand(commandBuffer);
			} else {
				command = ".\\sd.bat " + command;
				commandWriter.println(command);
			}
			LAST_BUCKET = 0;
			initCommandBuffer();
		} else {
			commandBuffer[LAST_BUCKET] = command;
			LAST_BUCKET++;
		}
	}

	public static void initCommandBuffer() {
		for (int i = 0; i < ARRAY_SIZE; i++) {
			commandBuffer[i] = "";
		}
	}

	public static void executeCommand() {
		commandWriter.close(); // must be closed otherwise system cannot find
								// the file
		String s = null;
		String command = "./runSd.bat ./output/" + commandFileName;
		try {
			Process p = Runtime.getRuntime().exec(command);
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(
					p.getInputStream()));
			BufferedReader stdError = new BufferedReader(new InputStreamReader(
					p.getErrorStream()));
			while ((s = stdInput.readLine()) != null) {
				if (!s.trim().startsWith("Warning"))
					System.out.println(s);
			}
			while ((s = stdError.readLine()) != null) {
				System.out.println(s);
			}
			p.destroy();
		} catch (IOException e) {
			System.out.println("exception happened with reading " + command
					+ " - here's what I know: ");
			System.out.println("exception happened - here's what I know: ");
			e.printStackTrace();
			System.exit(-1);
		}
	}

	public static String getFileNameSuffix() {
		String fileNameSuffix = (new Date().toString()).replace(' ', '_');
		fileNameSuffix = fileNameSuffix.replace(':', '_') + ".txt";
		return fileNameSuffix;
	}

	public static PrintWriter createWriter(String fileName) {
		PrintWriter Writer = null;
		File file = new File("output");
		if (!file.exists()) {
			String logsDir = "output";
			boolean success = (new File(logsDir)).mkdir();
			if (success)
				System.out.println("folder output has been created");
		}
		try {
			Writer = new PrintWriter(new FileWriter("./output/" + fileName),
					true);
		} catch (IOException ioe) {
			System.out.println("Error in creating writer with " + fileName);
		}
		return Writer;
	}

	public static void createSystemFile(String SYSTEM_NAME_PREFIX,
			int SYSTEM_START_INDEX, int SYSTEM_END_INDEX) {
		String fileName = "system_" + getFileNameSuffix();
		PrintWriter writer = createWriter(fileName);
		for (int i = SYSTEM_START_INDEX; i <= SYSTEM_END_INDEX; i++) {
			writer.println(SYSTEM_NAME_PREFIX + i);
		}
		writer.close();
	}

	// for verifying recursive algorithm
	public static ArrayList add5LevelServices(int level,
			int SUBSERVICES_PER_NODE, String SERVICE_NAME_PREFIX) {
		ArrayList leafSubServiceNames = new ArrayList(1000);
		int numOfServices = (int) Math.pow(SUBSERVICES_PER_NODE, level);
		System.out.println("number of leaf node sub Services to be created = "
				+ numOfServices);
		long startTime = System.currentTimeMillis();
		Stack services = new Stack();
		for (int i1 = 1; i1 <= SUBSERVICES_PER_NODE; i1++) {
			String s1 = SERVICE_NAME_PREFIX + i1;
			services.push(s1);
			for (int i2 = 1; i2 <= SUBSERVICES_PER_NODE; i2++) {
				String s2 = s1 + i2;
				services.push(s1 + "/" + s2);
				for (int i3 = 1; i3 <= SUBSERVICES_PER_NODE; i3++) {
					String s3 = s2 + i3;
					services.push(s1 + "/" + s2 + "/" + s3);
					for (int i4 = 1; i4 <= SUBSERVICES_PER_NODE; i4++) {
						String s4 = s3 + i4;
						services.push(s1 + "/" + s2 + "/" + s3 + "/" + s4);
						// leafSubServiceNames.add(s4);
						for (int i5 = 1; i5 <= SUBSERVICES_PER_NODE; i5++) {
							String s5 = s4 + i5;
							services.push(s1 + "/" + s2 + "/" + s3 + "/" + s4
									+ "/" + s5);
							leafSubServiceNames.add(s5);
						}
					}
				}
			}
		}
		System.out.println("totalNumOfServices =" + services.size());
		System.out.println("totalNumOfLeafServices ="
				+ leafSubServiceNames.size());
		System.out.println("static (ALGORITHM): "
				+ (System.currentTimeMillis() - startTime) + " ms");
		processServiceTree(services, SUBSERVICES_PER_NODE);
		return leafSubServiceNames;
	}

	public static void checkMemory(String comment) {
		int mb = 1024 * 1024;
		Runtime runtime = Runtime.getRuntime();
		String printString1 = comment + " Heap utilization statistics [MB]";
		// UsedFree/Total/Max memory
		String printString2 = "Used/Free/Total/Max Memory:"
				+ (runtime.totalMemory() - runtime.freeMemory()) / mb + "/"
				+ runtime.freeMemory() / mb + "/" + runtime.totalMemory() / mb
				+ "/" + runtime.maxMemory() / mb;
		System.out.println(printString1 + '\n' + printString2);
		if (logWriter != null) {
			logWriter.println(printString1 + '\n' + printString2);
		}
	}

	public static void printStackTrace() {
		ThreadMXBean bean = ManagementFactory.getThreadMXBean();
		ThreadInfo[] threads = bean.dumpAllThreads(true, true);
		logWriter.println(System.currentTimeMillis() + ",bean,"
				+ bean.getCurrentThreadCpuTime() + ","
				+ bean.getCurrentThreadUserTime() + bean.toString());
		for (ThreadInfo thread : threads) {
			logWriter.println(System.currentTimeMillis() + ",thread,"
					+ thread.getThreadId() + "," + thread.getThreadName() + ","
					+ thread.getThreadState() + "," + thread.toString());
			StackTraceElement[] elements = thread.getStackTrace();
			for (StackTraceElement ste : elements) {
				logWriter.println(System.currentTimeMillis() + ",trace,"
						+ ste.getClassName() + ',' + ste.getMethodName() + ','
						+ ste.toString());
			}
		}
	}
}

class ServiceThread extends Thread {
	AdminProxy adminProxy;
	int SYSTEM_START_INDEX;
	int SYSTEM_END_INDEX;
	int serviceStartIndex;
	int serviceEndIndex;
	String SYSTEM_NAME_PREFIX;
	String fileName;
	PrintWriter writer;
	String name;
	boolean ADD_SYSTEMS;
	ArrayList leafSubServiceNames;

	public ServiceThread(AdminProxy proxy, String SYSTEM_NAME_PREFIX,
			int SYSTEM_START_INDEX, int SYSTEM_END_INDEX,
			int ServiceStartIndex, int ServiceEndIndex, boolean ADD_SYSTEMS,
			String FileName, PrintWriter Writer, ArrayList LeafSubServiceNames,
			String Name) {
		adminProxy = proxy;
		SYSTEM_START_INDEX = SYSTEM_START_INDEX;
		SYSTEM_END_INDEX = SYSTEM_END_INDEX;
		serviceStartIndex = ServiceStartIndex;
		serviceEndIndex = ServiceEndIndex;
		SYSTEM_NAME_PREFIX = SYSTEM_NAME_PREFIX;
		leafSubServiceNames = LeafSubServiceNames;
		fileName = FileName;
		writer = Writer;
		name = Name;
		ADD_SYSTEMS = ADD_SYSTEMS;
	}

	public void run() {
		long startTime = System.currentTimeMillis();
		addSystemToServices();
		writer.close();
		if (ADD_SYSTEMS && adminProxy == null) {
			executeAllCommands();
		}
		long endTime = System.currentTimeMillis();
		ServiceDirectory.THREAD_COUNT_DOWN--;
		double throughput = 1000.0
				* (SYSTEM_END_INDEX - SYSTEM_START_INDEX + 1)
				/ (endTime - startTime);
		System.out.println(getThreadName() + " adding "
				+ (SYSTEM_END_INDEX - SYSTEM_START_INDEX + 1) + " systems: "
				+ (endTime - startTime) + " ms " + " (" + throughput
				+ " systems / sec)");
		if (ServiceDirectory.THREAD_COUNT_DOWN < 1) {
			System.out.println(new Date().toString() + ": system throughput = "
					+ (1000 * ServiceDirectory.NUM_OF_SYSTEMS)
					/ (endTime - startTime) + " systems / sec ("
					+ ServiceDirectory.NUM_OF_SYSTEMS + " systems / "
					+ (endTime - startTime) + " ms)");
		}
	}

	public void addSystemToServices() {

		int numOfServices = serviceEndIndex - serviceStartIndex + 1;
		int numberOfsystemsPerService = (int) ((SYSTEM_END_INDEX
				- SYSTEM_START_INDEX + 1 + 0.5 * numOfServices) / numOfServices);
		// for each subService add assigned systems with random system type
		for (int i = serviceStartIndex; i <= serviceEndIndex; i++) {
			int systemStart = SYSTEM_START_INDEX + (i - serviceStartIndex)
					* numberOfsystemsPerService;
			int systemEnd = SYSTEM_START_INDEX + (i - serviceStartIndex + 1)
					* numberOfsystemsPerService - 1;
			if ((i == serviceEndIndex)) {
				systemEnd = SYSTEM_END_INDEX;
			}
			for (int j = systemStart; j <= systemEnd; j++) {
				String addSystemCommand = "addEntry "
						+ leafSubServiceNames.get(i).toString() + " "
						+ SYSTEM_NAME_PREFIX + j;
				if (adminProxy != null) {
					adminProxy.sendCommand(addSystemCommand);
				} else {
					addSystemCommand = ".\\sd.bat addEntry "
							+ leafSubServiceNames.get(i).toString() + " "
							+ SYSTEM_NAME_PREFIX + j;
					writer.println(addSystemCommand);
				}
			}
		}
	}

	public void executeAllCommands() {
		String s = null;
		System.out.println(name + " adding systems ... from file " + fileName);
		try {
			String command = ".\\runSd.bat .\\output\\" + fileName;
			Process p = Runtime.getRuntime().exec(command);
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(
					p.getInputStream()));
			BufferedReader stdError = new BufferedReader(new InputStreamReader(
					p.getErrorStream()));

			while ((s = stdInput.readLine()) != null) {
				if (!s.trim().startsWith("Warning"))
					System.out.println(s);
			}
			while ((s = stdError.readLine()) != null) {
				System.out.println(s);
			}
			p.destroy();
		} catch (IOException e) {
			System.out.println("exception happened - here's what I know: ");
			e.printStackTrace();
			System.exit(-1);
		}
	}

	public String getThreadName() {
		return name;
	}
}
