1) Download and unzip DiskCheck-1.0.zip to a folder on the system you intend to run.
2) Make sure it's located on the drive you want to test.
3) Open a command prompt and run "java -classpath . DiskCheck ioTest1.txt" where ioTest1.txt is a file included in the donwloaded DiskCheck-1.0.zip file. You can replace it with a different text file with a different size to suit your needs.
4) Total execution time at the end of console output is what you would use to quickly check if your IO subsystem is okay, based on known total execution time obtained on a known-to-be-good IO susbsystem. Use other more sophisticated disk io benchmark tools if you want to have more elaborate and characteristic measurement on your IO subsystem.

Some reference data: refer to Table B.1 in the book.
