package jcp.ch3.map;
import java.util.*;

public class LinkedHashMapDemo {
	public static void main (String args[]) {
		// 1. create a hash map
		LinkedHashMap<String, String> linkedHashMap = new LinkedHashMap<String, String> ();
		
		// 2. put key-value pairs to the map
		linkedHashMap.put("Virginia", "VA");
		linkedHashMap.put("Washington", "WA");
		linkedHashMap.put("California", "CA");
		linkedHashMap.put("Distric of Columbia", "DC");
		linkedHashMap.put("Massachusetts", "MA");
		linkedHashMap.put("New Jersey", "NJ");
		
		// 3. get map's entrySet
		Set<Map.Entry<String, String>> set = linkedHashMap.entrySet();
		
		// 4. Display the entry set
		for (Map.Entry<String, String> entry : set) {
			System.out.print (entry.getKey() + ": ");
			System.out.println (entry.getValue());
		}
		
		// 5. get state abbreviation by key
		String caAbbr = linkedHashMap.get("California");
		System.out.println ("state abbreviation for California: " + caAbbr);
	}
}
