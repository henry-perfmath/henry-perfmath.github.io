package jcp.ch3.map;
import java.util.*;

public class TreeMapDemo {
	public static void main (String args[]) {
		// 1. create a tree map
		TreeMap<String, String> treeMap = new TreeMap<String, String> ();
		
		// 2. put key-value pairs to the map
		treeMap.put("Virginia", "VA");
		treeMap.put("Washington", "WA");
		treeMap.put("California", "CA");
		treeMap.put("Distric of Columbia", "DC");
		treeMap.put("Massachusetts", "MA");
		treeMap.put("New Jersey", "NJ");
		
		// 3. get map's entrySet
		Set<Map.Entry<String, String>> set = treeMap.entrySet();
		
		// 4. Display the entry set
		for (Map.Entry<String, String> entry : set) {
			System.out.print (entry.getKey() + ": ");
			System.out.println (entry.getValue());
		}
		
		// 5. get state abbreviation by key
		String caAbbr = treeMap.get("California");
		System.out.println ("state abbreviation for California: " + caAbbr);
	}
}
