package jcp.ch3.algorithms;

import java.util.*;

public class SingletonListDemo {
	public static void main(String args[]) {
		// 1. create a String obj
		String obj = "a";

		// 2. create a singleton (set)
		Set<String> set = Collections.singleton (obj);
		set.add ("b"); // will throw an exception
		
		// 3. create a singleton list and map
		List<String> list = Collections.singletonList(obj);
		Map<String, Integer> map = Collections.singletonMap(obj, 1);
		
		// 4. print out
		System.out.println("singleon(Set): " + set);
		System.out.println("singleonList: " + list);
		System.out.println("singleonMap: " + map);
	}
}
