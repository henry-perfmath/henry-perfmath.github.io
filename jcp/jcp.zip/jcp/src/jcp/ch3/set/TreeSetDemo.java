package jcp.ch3.set;
import java.util.*;

public class TreeSetDemo {
	public static void main (String args[]) {
		// create a tree set
		TreeSet<String> ts = new TreeSet<String> ();
		
		// add elements
		ts.add ("f");
		ts.add ("a");
		ts.add ("e");
		ts.add ("c");
		ts.add ("b");
		ts.add ("d");		
		System.out.println (ts);
		System.out.println (ts.subSet ("b", "e"));
	}
}
