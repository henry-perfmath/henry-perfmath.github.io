package jcp.ch3.set;
import java.util.*;

public class HashSetDemo {
	public static void main (String args[]) {
		// create a hash set
		HashSet<String> hs = new HashSet<String> ();
		
		// add elements
		hs.add ("This ");
		hs.add ("is ");
		hs.add (" a");
		hs.add (" HashSet ");
		hs.add ("demo");
		System.out.println (hs);
	}
}
