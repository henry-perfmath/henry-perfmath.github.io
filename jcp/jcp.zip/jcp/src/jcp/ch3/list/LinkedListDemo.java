package jcp.ch3.list;
import java.util.*;

public class LinkedListDemo {
	public static void main (String args[]) {
		// create a LinkedList collection
		LinkedList<String> ll = new LinkedList<String> ();
		System.out.println ("Initill size of ll: " + ll.size());
		
		// add elements
		ll.add ("This ");
		ll.add ("is ");
		ll.add ("an ");
		ll.add ("ArrayList ");
		ll.add ("demo");
		System.out.println (ll);	
		System.out.println ("Size after adding 5 elements: " + ll.size());
		System.out.println ("Index for the \"simple \" string: " + ll.indexOf ("simple "));
		
		// update "ArrayList" with "LinkedList"
		ll.set(3, "LinkedList ");
		
		// add an element at index = 3
		ll.add(3, "simple ");
		System.out.println (ll);	
		System.out.println ("Size after adding an element at index = 3: " + ll.size());
		
		// add an element at index = 5
		ll.add(5, "simple ");
		System.out.println (ll);	
		System.out.println ("Size after adding an element at index = 5 again: " + ll.size());
		
		// indexOf and lastIndexOf
		System.out.println ("Index for the \"simple \" string: " + ll.indexOf ("simple "));
		System.out.println ("Index for the last \"simple \" string: " + ll.lastIndexOf ("simple "));
		// remove the "simple" string
		ll.remove("simple ");
		System.out.println (ll);	
		System.out.println ("Size after removing an element: " + ll.size());
	}
}
