package jcp.ch3.queue;
import java.util.*;

public class ArrayDequeDemo {
	public static void main (String args[]) {
		// create an ArrayDeque collection
		ArrayDeque<String> adq = new ArrayDeque ();
		System.out.println ("Initiadq size of adq: " + adq.size());
		
		// add elements
		adq.push ("This");
		adq.push ("is");
		adq.push ("an");
		adq.push ("ArrayDeque");
		adq.push ("demo");
		System.out.println (adq);	
		System.out.println ("Size after adding 5 elements: " + adq.size());
		
		System.out.print ("Popping the array deque: "); 
		while (adq.peek() != null) {
			System.out.print (adq.pop() + " ");
		}
		System.out.println ();
	}
}
