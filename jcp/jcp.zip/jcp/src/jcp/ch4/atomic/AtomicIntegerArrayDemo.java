package jcp.ch4.atomic;

import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// test driver
public class AtomicIntegerArrayDemo {

	public static void main(String[] args) throws InterruptedException {
		
		final PermitArray permitArray = new PermitArray();
		permitArray.setPermits (0, 9);
		permitArray.setPermits (1, 99);
		permitArray.setPermits (2, 999);
		
		// 1. Create a newFixedThreadPool using the Executors utility class
		ExecutorService executorService = Executors.newFixedThreadPool(100);

		// 2. launch 100 drawers
		for (int i = 0; i < 100; i++) {
			executorService.execute (new Drawers (i, permitArray));
		}

		// 3. wait 5000 ms for all drawers to complete
		Thread.sleep(5000);
		for (int i = 0; i < 3; i++) {
			System.out.println("# of permits: " + permitArray.getPermits(i));
		}
		
		// 4. shut down executorService to avoid resource leak
		executorService.shutdown();
	}
}

// Thread class: a drawer increments/decrements permits if id is even/odd.
class Drawers extends Thread {
	int id;
	PermitArray permitArray;

	Drawers(int id, PermitArray permitArray){
		this.id = id;
		this.permitArray = permitArray;
	}
	public void run() {
		for (int i = 0; i < 100; i++) {
			if ((this.id % 2) == 0) {
				for (int j = 0; j < permitArray.length(); j++) {
					permitArray.incrementPermits(j);
				}
			} else {
				for (int j = 0; j < permitArray.length(); j++) {
					permitArray.decrementPermits(j);
				}
			}
		}
	}
}

// Shared resource: AtomicIntegerArray synchronizes permitArray
class PermitArray {
	// AtomicIntegerArray with 3 elements
	private AtomicIntegerArray permitArray = new AtomicIntegerArray(3);

	public int getPermits(int i) {
		return permitArray.get(i);
	}
	
	public void setPermits(int i, int newValue) {
		permitArray.set(i, newValue);
	}
	
	public void incrementPermits(int i) {
		permitArray.incrementAndGet(i);
	}
	
	public void decrementPermits(int i) {
		permitArray.decrementAndGet(i);
	}
	
	public int length () {
		return permitArray.length();
	}
}
