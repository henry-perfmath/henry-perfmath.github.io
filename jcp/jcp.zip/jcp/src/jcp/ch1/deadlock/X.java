package jcp.ch1.deadlock;

public class X {
	public synchronized void callMe(Y y, long sleepTime) {
		String name = Thread.currentThread().getName();
		System.out
				.println(name + " entered x thread class's callMe (Y y) method");

		try {
			Thread.sleep(sleepTime);
		} catch (Exception e) {
			System.out.println("Thread x interrupted");
		}

		System.out.println(name
				+ " attempting to call x thread class's Y.hangUp () method");
		y.hangUp();
	}

	public synchronized void hangUp() {
		System.out.println("Inside x thread class's X.hangUp ()");
	}
}
