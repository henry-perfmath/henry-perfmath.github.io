package jcp.ch1.deadlock;

public class DeadlockDemo2 implements Runnable {
	X x = new X();
	Y y = new Y();

	DeadlockDemo2() {
		Thread.currentThread().setName("Parent Thread");
		(new Thread(this, "Child Thread")).start();
		x.callMe(y);
	}

	public void run() {
		y.callMe(x);
	}

	public static void main(String args[]) {
		new DeadlockDemo2();
	}

	class X {
		public synchronized void callMe(Y y) {
			System.out.println("Inside x thread class's Y.hangUp ()");
			y.hangUp();
		}

		public synchronized void hangUp() {
		}
	}

	class Y {
		public synchronized void callMe(X x) {
			System.out.println("Inside y thread class's x.hangUp ()");
			x.hangUp();
		}

		public synchronized void hangUp() {
		}
	}
}