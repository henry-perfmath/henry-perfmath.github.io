package jcp.ch1.deadlock;

public class DeadlockDemo1 implements Runnable {
	X x = new X();
	Y y = new Y();

	DeadlockDemo1() {
		Thread.currentThread().setName("Parent Thread");
		Thread t = new Thread(this, "Child Thread");
		t.start();

		x.callMe(y, 1000);
		System.out.println("Back in Parent thread");
	}

	public void run() {
		y.callMe(x, 0);
		System.out.println("Back in Parent thread");
	}

	public static void main(String args[]) {
		new DeadlockDemo1();
	}
}
