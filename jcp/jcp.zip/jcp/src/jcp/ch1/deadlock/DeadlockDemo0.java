package jcp.ch1.deadlock;

public class DeadlockDemo0 {
	public static void main(String args[]) {
		X x = new X();
		Y y = new Y();

		x.callMe(y, 0);
		System.out.println("Back in Main thread after x.callMe\n---");

		y.callMe(x, 0);
		System.out.println("Back in Main thread after y.callMe");
	}
}
