package jcp.ch1.buffer.v2;

class Producer implements Runnable {
	SimpleBuffer simpleBuffer;

	Producer(SimpleBuffer simpleBuffer) {
		this.simpleBuffer = simpleBuffer;
		new Thread(this, "Producer").start();
	}

	public void run() {
		int i = 0;

		while (true) {
			simpleBuffer.put(i++);
		}
	}
}
