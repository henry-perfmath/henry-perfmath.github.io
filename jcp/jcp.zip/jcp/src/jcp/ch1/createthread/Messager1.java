package jcp.ch1.createthread;

public class Messager1 {
	void sendMessage (String msg) {
		System.out.print("<" + msg);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			System.out.println("Interrupted: " + e.getStackTrace());
		}
		System.out.println(">");
	}
}