package jcp.ch1.createthread;

public class SynchTest1 {
	public static void main(String args[]) {
		Messager1 target = new Messager1();
		MessageThread1 messager1 = new MessageThread1(target, "Java");
		MessageThread1 messager2 = new MessageThread1(target, "Concurrent");
		MessageThread1 messager3 = new MessageThread1(target, "Programming");

		// wait for threads to end
		try {
			messager1.t.join();
			messager2.t.join();
			messager3.t.join();
		} catch (InterruptedException e) {
			System.out.println("Interrupted");
		}
	}
}
