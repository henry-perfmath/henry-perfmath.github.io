package jcp.ch1.createthread;

class MessageThread implements Runnable {
	String msg;
	Messager target;
	Thread t;

	public MessageThread(Messager targ, String s) {
		target = targ;
		msg = s;
		t = new Thread(this);
		t.start();
	}

	public void run() {
		target.sendMessage (msg);
	}
}
