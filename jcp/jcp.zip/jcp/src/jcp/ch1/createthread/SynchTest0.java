package jcp.ch1.createthread;

public class SynchTest0 {
	public static void main(String args[]) {
		Messager target = new Messager();
		MessageThread messager1 = new MessageThread(target, "Java");
		MessageThread messager2 = new MessageThread(target, "Concurrent");
		MessageThread messager3 = new MessageThread(target, "Programming");

		// wait for threads to end
		try {
			messager1.t.join();
			messager2.t.join();
			messager3.t.join();
		} catch (InterruptedException e) {
			System.out.println("Interrupted");
		}
	}
}
