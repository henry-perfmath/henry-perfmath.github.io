package jcp.ch6.synchronizers;

public class BarrierAction implements Runnable {
	public void run() {
		// action to perform when threads reach the barrier:
		System.out.println ("reached the barrier");
	}
}
