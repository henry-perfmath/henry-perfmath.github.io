package jcp.ch6.synchronizers;

import java.util.Random;
import java.util.concurrent.Exchanger;

public class ExchangerDemo2 {
	public static void main(String args[]) {
		// 1. create an exchanger
		Exchanger<Integer> exchanger = new Exchanger<Integer>();

		// 2. create three threads for exchanging data
		new ThreadA(1, exchanger);
		new ThreadB(2, exchanger);
		new ThreadC(3, exchanger);
	}
}

class ThreadA implements Runnable {
	int id;
	Exchanger<Integer> exchanger;

	ThreadA(int id, Exchanger<Integer> exchanger) {
		this.id = id;
		this.exchanger = exchanger;
		new Thread(this).start();
	}

	public void run() {
		Integer buffer = new Random().nextInt(999);
		try {
			System.out.println("Thread " + id + " send: " + buffer);
			buffer = exchanger.exchange(buffer);
			System.out.println("Thread " + id + " receive: " + buffer);
		} catch (InterruptedException ie) {
			System.out.println(ie);
		}
	}
}

class ThreadB implements Runnable {
	int id;
	Exchanger<Integer> exchanger;

	ThreadB(int id, Exchanger<Integer> exchanger) {
		this.id = id;
		this.exchanger = exchanger;
		new Thread(this).start();
	}

	public void run() {
		Integer buffer = new Random().nextInt(999);
		try {
			System.out.println("Thread " + id + " send: " + buffer);
			buffer = exchanger.exchange(buffer);
			System.out.println("Thread " + id + " receive: " + buffer);
		} catch (InterruptedException ie) {
			System.out.println(ie);
		}
	}
}

class ThreadC implements Runnable {
	int id;
	Exchanger<Integer> exchanger;

	ThreadC(int id, Exchanger<Integer> exchanger) {
		this.id = id;
		this.exchanger = exchanger;
		new Thread(this).start();
	}

	public void run() {
		Integer buffer = new Random().nextInt(999);
		try {
			System.out.println("Thread " + id + " send: " + buffer);
			buffer = exchanger.exchange(buffer);
			System.out.println("Thread " + id + " receive: " + buffer);
		} catch (InterruptedException ie) {
			System.out.println(ie);
		}
	}
}