package jcp.ch6.synchronizers;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;

public class CyclicBarrierDemo {
	public static void main(String[] args) throws InterruptedException {
		CyclicBarrier cyclicBarrier = new CyclicBarrier(3, new BarrierAction());
		int POOL_SIZE = 3;
		// 1. Create a newFixedThreadPool using the Executors utility class
		ExecutorService executorService = Executors
				.newFixedThreadPool(POOL_SIZE);

		// 2. launch 3 counters
		for (int i = 0; i < POOL_SIZE; i++) {
			executorService.execute(new MyThread(i, cyclicBarrier));
		}

		// 3. wait 5000 ms for all threads to complete
		Thread.sleep(5000);

		// 4. shut down executorService to avoid resource leak
		executorService.shutdown();
	}
}

// Thread class: Prints ID and calls await() method before proceeding
class MyThread extends Thread {
	int id;
	CyclicBarrier cyclicBarrier;

	MyThread(int id, CyclicBarrier cyclicBarrier) {
		this.id = id;
		this.cyclicBarrier = cyclicBarrier;
	}

	public void run() {
		System.out.println ("This is thread " + id);
		try {
			cyclicBarrier.await();
		} catch (BrokenBarrierException bbe) {
			System.out.println("BrokenBarrierException: " + bbe);
		} catch (InterruptedException ie) {
			System.out.println("InterruptedException: " + ie);
		}
	}
}


