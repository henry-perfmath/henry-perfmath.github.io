package jcp.ch6.synchronizers;

import java.util.Random;
import java.util.concurrent.Exchanger;

public class ExchangerDemo {
	public static void main(String args[]) {
		// 1. create an exchanger
		Exchanger<Integer> exchanger = new Exchanger<Integer>();

		// 2. create two threads for exchanging data
		new Thread1(1, exchanger);
		new Thread2(2, exchanger);
	}
}

class Thread1 implements Runnable {
	int id;
	Exchanger<Integer> exchanger;

	Thread1(int id, Exchanger<Integer> exchanger) {
		this.id = id;
		this.exchanger = exchanger;
		new Thread(this).start();
	}

	public void run() {
		try {
			//while (true) {
				Integer buffer = new Random().nextInt(999);
				System.out.println("Thread " + id + " send: " + buffer);
				buffer = exchanger.exchange(buffer);
				System.out.println("Thread " + id + " receive: " + buffer);
			//}
		} catch (InterruptedException ie) {
			System.out.println(ie);
		}
	}
}

class Thread2 implements Runnable {
	int id;
	Exchanger<Integer> exchanger;

	Thread2(int id, Exchanger<Integer> exchanger) {
		this.id = id;
		this.exchanger = exchanger;
		new Thread(this).start();
	}

	public void run() {
		try {
			//while (true) {
				Integer buffer = new Random().nextInt(999);
				System.out.println("Thread " + id + " send: " + buffer);
				buffer = exchanger.exchange(buffer);
				System.out.println("Thread " + id + " receive: " + buffer);
			//}
		} catch (InterruptedException ie) {
			System.out.println(ie);
		}
	}
}
