package jcp.ch6.synchronizers;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CountDownLatchDemo2 {
	public static void main(String args[]) {

		// 1. create a latch
		int EVENT_COUNT = 3;
		CountDownLatch latch = new CountDownLatch(EVENT_COUNT);

		// 2. Create a newFixedThreadPool using the Executors utility class
		int POOL_SIZE = 2;
		ExecutorService executorService = Executors
				.newFixedThreadPool(POOL_SIZE);

		// 3. launch 2 latch threads
		for (int i = 0; i < POOL_SIZE; i++) {
			executorService.execute(new LatchThread2(i, latch));
		}

		// 4. wait
		try {
			latch.await();
		} catch (InterruptedException ie) {
			System.out.println(ie);
		}
		System.out.println("done");

		// 5. shut down executorService to avoid resource leak
		executorService.shutdown();
	}
}

class LatchThread2 implements Runnable {
	int id;
	CountDownLatch latch;
	long count;

	LatchThread2(int id, CountDownLatch latch) {
		this.id = id;
		this.latch = latch;
		count = latch.getCount();
	}

	public void run() {
		for (int i = 0; i < count; i++) {
			System.out.println("LatchThread " + id + " counting down: " + i);
			latch.countDown();
		}
	}
}