package jcp.ch6.synchronizers;

import java.util.concurrent.Phaser;

public class PhaserDemo {
	public static void main(String args[]) {
		Phaser phaser = new Phaser(1);
		System.out.println("Initial phase ...");

		new ThreadN(1, phaser);
		new ThreadN(2, phaser);
		new ThreadN(3, phaser);

		int currPhase = phaser.getPhase();
		phaser.arriveAndAwaitAdvance();
		System.out.println("Phaser completed phase " + currPhase);
		
		currPhase = phaser.getPhase();
		phaser.arriveAndAwaitAdvance();
		System.out.println("Phaser completed phase " + currPhase);

		currPhase = phaser.getPhase();
		phaser.arriveAndAwaitAdvance();
		System.out.println("Phaser completed phase " + currPhase);

		phaser.arriveAndDeregister();
	}
}

class ThreadN implements Runnable {
	int id;
	Phaser phaser;

	ThreadN(int id, Phaser phaser) {
		this.id = id;
		this.phaser = phaser;
		phaser.register();
		new Thread(this).start();
	}

	public void run() {

		System.out.println("Thread " + id + " completed phase 0");
		phaser.arriveAndAwaitAdvance();
		
		try {
			Thread.sleep(20);
		} catch (InterruptedException ie) {
			System.out.println(ie);
		}
		
		System.out.println("Thread " + id + " completed phase 1");
		phaser.arriveAndAwaitAdvance();
		
		try {
			Thread.sleep(20);
		} catch (InterruptedException ie) {
			System.out.println(ie);
		}
		
		System.out.println("Thread " + id + " completed phase 2");
		phaser.arriveAndDeregister();
	}
}
