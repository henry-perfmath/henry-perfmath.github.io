package jcp.ch2.executorservice.example1;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class SimpleESDemo1 {
	public static void main(String args[]) {
		// 1. Create a newFixedThreadPool using the Executors utility class
		ExecutorService executorService = Executors.newFixedThreadPool(5);

		// 2. Execute an anonymous thread/task asynchronously
		Future future = executorService.submit(new Runnable() {
			public void run() {
				System.out.println("Execute a Runnable with " +
				  "a Future object returned");

				Thread.currentThread().stop();
			}
		});
		
		try {
			if (future.get() == null) {
				System.out.println ("task was completed successfully");
			} else {
				System.out.println ("task was not completed successfully");
			}
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
		
		// 3. shut down executorService to avoid resource leak
		executorService.shutdown();
	}
}