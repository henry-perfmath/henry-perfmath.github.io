package jcp.ch2.executorservice.example0;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SimpleESDemo0 {
	public static void main(String args[]) {
		// 1. Create a newFixedThreadPool using the Executors utility class
		ExecutorService executorService = Executors.newFixedThreadPool(5);

		// 2. Execute an anonymous thread/task asynchronously
		executorService.execute(new Runnable() {
			public void run() {
				System.out
						.println("Execute a Runnable with no result returned");
			}
		});
		// 3. shut down executorService to avoid resource leak
		executorService.shutdown();
	}
}