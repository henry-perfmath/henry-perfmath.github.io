package jcp.ch5.locks;

import java.util.concurrent.locks.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ReentrantReadWriterLockDemo {
	public static void main(String[] args) throws InterruptedException {
		ReentrantReadWriteLock rwLock = new ReentrantReadWriteLock();

		// 1. Create a newFixedThreadPool using the Executors utility class
		ExecutorService executorService = Executors.newFixedThreadPool(100);

		// 2. launch 100 workers
		for (int i = 0; i < 100; i++) {
			String name = "reader-" + i;
			if ((i % 10 == 0)) name = "writer-" + i;
			executorService.execute(new Worker(name, rwLock));
		}

		// 3. wait 5000 ms for all drawers to complete
		Thread.sleep(5000);
		System.out.println("Number of permits: " + Resource.permits);

		// 4. shut down executorService to avoid resource leak
		executorService.shutdown();
	}
}

// Thread class: a worker reads/writes permits based on name prefix
class Worker extends Thread {
	String id;
	ReentrantReadWriteLock rwLock;

	Worker(String id, ReentrantReadWriteLock rwLock) {
		this.id = id;
		this.rwLock = rwLock;
	}

	public void run() {
			if (id.contains ("reader")) {
				try {
					rwLock.readLock().lock();
					System.out.println (id + " reading " + Resource.permits);
				} finally {
					rwLock.readLock().unlock();
				}
			} else if (id.contains ("writer")){
				try {
					rwLock.writeLock().lock();
					System.out.println (id + " writing " + Resource.permits);
					Resource.permits++;
				} finally {
					System.out.println (id + " written " + Resource.permits);
					rwLock.writeLock().unlock();
				}
			} else {
				
			}
	}
}

// Shared resource: number of permits
class Resource {
	static int permits = 0;
}
