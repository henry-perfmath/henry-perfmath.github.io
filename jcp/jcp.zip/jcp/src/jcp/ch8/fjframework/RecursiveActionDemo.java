package jcp.ch8.fjframework;

import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import java.util.concurrent.TimeUnit;

class SortTask extends RecursiveAction {

	final int THRESHOLD = 1000000;
	final long[] array;
	final int start;
	final int end;

	SortTask(long[] array, int start, int end) {
		this.array = array;
		this.start = start;
		this.end = end;
	}

	SortTask(long[] array) {
		this(array, 0, array.length);
	}

	protected void compute() {
		if (end - start < THRESHOLD)
			sortSequentially(start, end);
		else {
			int middle = (start + end) >>> 1;
			invokeAll(new SortTask(array, start, middle), 
					  new SortTask(array, middle, end));
			merge(start, middle, end);
		}
	}

	void sortSequentially(int start, int end) {
		Arrays.sort(array, start, end);
	}

	void merge(int start, int middle, int end) {
		long[] buffer = Arrays.copyOfRange(array, start, middle);
		for (int i = 0, j = start, k = middle; i < buffer.length; j++)
			array[j] = (k == end || buffer[i] < array[k]) ? buffer[i++]
					: array[k++];
	}
}

public class RecursiveActionDemo {
	public static void main(String[] args) {

		// 1. create a long array
		int ARRAY_SIZE = 10000000;
		long[] longArray = new long[ARRAY_SIZE];

		Random random = new Random();
		System.out.println ("A portion of the initial long array");
		for (int i = 0; i < ARRAY_SIZE; i++) {
			longArray[i] = Math.abs(random.nextLong());
			if ((i % ARRAY_SIZE / 10) == 0) {
				System.out.println ("i = " + i + " longArray[i] = " + longArray[i]);
			}
		}
		
		// 2. create the FJ pool and task object 
		ForkJoinPool forkJoinPool = new ForkJoinPool();
		SortTask task = new SortTask (longArray, 0, ARRAY_SIZE);
		
		// 3. start the task
		long startTime = System.currentTimeMillis();
		forkJoinPool.invoke(task);
		long endTime = System.currentTimeMillis();
		System.out.println ("\nElapsed time (ms): " + (endTime - startTime));

		// 4. check a portion of the sorted longArray
		System.out.println ("\nA portion of the sorted long array");
		for (int i = 0; i < 10; i++) {
			System.out.println ("i = " + i + " longArray[i] = " + longArray[i]);
		}
	}
}
