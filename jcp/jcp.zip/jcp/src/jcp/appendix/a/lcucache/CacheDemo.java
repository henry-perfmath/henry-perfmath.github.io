/**
 * A LinkedHashMap based Cache
 * LRU provided with the access-order attribute
 * both get and set are O(1)
 */
package jcp.appendix.a.lcucache;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

class Cache <K, V> extends LinkedHashMap<K, V>{
	private int capacity;
	
	public Cache (int capacity) {
		super (capacity, 1.0f, true); // true access-order false insertion-order
		this.capacity = capacity;
	}
	
	protected boolean removeEldestEntry (Entry entry) {
		return (size() > this.capacity);
	}
}

public class CacheDemo {

	public static void main(String[] args) {
		Cache cache = new Cache (9);
		
		cache.put(1, "One");
		cache.put(2, "Two");
		cache.put(3, "Three");
		
		System.out.println (cache.toString());
		
		cache.get(2);
		System.out.println (cache.toString());
		
		cache.get(3);
		System.out.println (cache.toString());
		
		cache.get(1);
		System.out.println (cache.toString());
	}

}
