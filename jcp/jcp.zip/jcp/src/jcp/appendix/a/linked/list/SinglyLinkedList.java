package jcp.appendix.a.linked.list;

public class SinglyLinkedList {
	public int size;
	public ListNode head;
	
	public SinglyLinkedList() {
		size = 0;
		head = null;
	}
	
	public SinglyLinkedList(int size, ListNode head) {
		super();
		this.size = size;
		this.head = head;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public ListNode getHead() {
		return head;
	}
	public void setHead(ListNode head) {
		this.head = head;
	}
	
	public void insert (int data) {
		ListNode node = new ListNode (data);
		if (head == null) {
			head = node;
		} else {
			// prepend:
			node.setNext(head);
			head = node;
			// append
			/*
			ListNode currentNode = head;
			while (currentNode.getNext() != null) {
				currentNode = currentNode.getNext();
			}
			currentNode.setNext(node);
			node.setNext(null);
			*/
		}
		size++;
	}
	
	public void printList () {
		ListNode currentNode = head;
		while (currentNode != null) {
			System.out.println(currentNode.getData());
			currentNode =currentNode.getNext();
		}
	}
	
	public void reverse () {
		ListNode current = head;
		ListNode prev = null;
		ListNode next = null;
		
		while (current != null) {
			next = current.getNext();
			current.setNext(prev);
			prev = current;
			current = next;
		}
		head = prev;
	}
}
