package jcp.appendix.a.linked.list;

public class DetectCircularList {

	public static void main(String[] args) {
		LinkedList list = new LinkedList ();
		
		for (int i = 0; i < 19; i++) {
			list.addLast(i + 1);
		}
		
		int position = 11;
		list.fold (position);
		
		System.out.println ("size = " + list.size);
		System.out.println ("fold at " + position + " " + list.get(position));
		
		printAll (list);
		
		checkCircularLinkedList (list);

	}

	public static void printAll (LinkedList list) {
		System.out.println ();
		
		for (int i = 0; i < list.size; i++) {
			System.out.println ("i = " + i + " " + list.get (i));
		}
		
	}
	
	public static void checkCircularLinkedList (LinkedList list) {
		// start at the same initial point
		ListNode slow = list.first;
		ListNode fast = list.first;
		
		do {
			slow = slow.getNext();
			fast = fast.getNext ().getNext();
			System.out.println ("slow fast: " + slow.getData() + " " + fast.getData());
			if (fast == null || slow == fast) break;
		} while (true);
		
		// no loop if fast or fast.next null
		if (fast == null || fast.getNext() == null) {
			System.out.println ("No circular list");
			return;
		} else {
			System.out.println ("circular linked list meeting point: " 
					+ slow.getData());
		}
		
		// find entry point for circular linked list
		slow = list.first;
		while (slow != fast) {
			slow = slow.getNext();
			fast = fast.getNext ();
		}
		System.out.println ("circular linked list entry point: " 
				+ slow.getData());
	}
}
