package jcp.appendix.a.misc;

import java.util.Random;

public class ArraySubProducts {

	public static void main(String[] args) {
		final int MAX_ARRAY_SIZE = 10;
		int[] a = new int[MAX_ARRAY_SIZE];

		long seed = 1415157213700L;

		Random rnd = new Random(seed);
		for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
			a[i] = 5 - (int) (rnd.nextDouble() * MAX_ARRAY_SIZE * 1.0);
			System.out.print(a[i] + " ");
		}

		System.out.println();

		int product = total(a);
		System.out.println("\ntotal = " + product);

		if (product != 0) {
			int[] b = new int[MAX_ARRAY_SIZE];

			for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
				b[i] = 1;
			}
			products2(a, b);
			for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
				System.out.println("i = " + i + ": " + b[i] + " = " + product
						/ a[i] + " ");
			}
			System.out.println();
		}
	}

	public static int total(int[] a) {
		int total = 1;
		for (int i = 0; i < a.length; i++) {
			total = total * a[i];
		}
		return total;
	}

	// approach from both ends
	public static void products2(int[] a, int[] b) {
		int n = a.length;

		// first part
		int firstPart = 1;
		for (int i = 1; i < n; i++) {
			firstPart *= a[i - 1];
			b[i] = firstPart;
		}

		// second part
		int secondPart = 1;
		for (int i = n - 1; i > 0; i--) {
			secondPart *= a[i];
			b[i - 1] = b[i - 1] * secondPart;
		}
	}
}