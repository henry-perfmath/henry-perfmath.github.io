package jcp.appendix.a.misc;

public class MaxSubSeq {
	public static void main(String[] args) {

		int[] a = { -5, 15, -1, 9, -2, -5, -8 };
		int max = maxSubseqSum3(a);
		System.out.println ("max sum = " + max);
	}

	public static int maxSubseqSum1(int[] a) {
		int maxSum = 0;

		int n = a.length;
		for (int i = 0; i < n; i++)
			for (int j = i; j < n; j++) {
				int sum = 0;
				for (int k = i; k <= j; k++)
					sum += a[k];
				if (sum > maxSum) {
					maxSum = sum;
				}
			}

		return maxSum;
	}

	public static int maxSubseqSum2(int[] a) {
		int maxSum = 0;

		int n = a.length;
		for (int i = 0; i < n; i++) {
			int sum = 0;
			for (int j = i; j < n; j++) {
				sum += a[j];
				if (sum > maxSum) {
					maxSum = sum;
				}
			}
		}

		return maxSum;
	}

	public static int maxSubseqSum3(int[] a) {
		int maxSum = 0;
		int sum = 0;

		int n = a.length;
		for (int j = 0; j < n; j++) {
			sum += a[j];
			if (sum < 0) {
				sum = 0;
			} else if (sum > maxSum) {
				maxSum = sum;
			}
		}
		
		return maxSum;
	}
}