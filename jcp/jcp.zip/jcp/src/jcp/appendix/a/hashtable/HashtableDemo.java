package jcp.appendix.a.hashtable;

class Entry {
	private int key;
	private int value;

	Entry(int key, int value) {
		this.key = key;
		this.value = value;
	}

	public int getKey() {
		return key;
	}

	public int getValue() {
		return value;
	}
}

class Hashtable {
	private final static int TABLE_SIZE = 512;

	Entry[] table;

	Hashtable() {
		table = new Entry[TABLE_SIZE];
		for (int i = 0; i < TABLE_SIZE; i++) {
			table[i] = null;
		}
	}

	public int get(int key) {
		// 1. calculate hash
		int hash = key % TABLE_SIZE;

		// 2. find the key
		while (table[hash] != null && table[hash].getKey() != key) {
			hash = (hash + 1) % TABLE_SIZE;
		}

		// 3. return -1 if not found
		return (table[hash] == null) ? -1 : table[hash].getValue();
	}

	public void put(int key, int value) {
		int hash = key % TABLE_SIZE;

		while (table[hash] != null && table[hash].getKey() != key) {
			hash = (hash + 1) % TABLE_SIZE;
		}
		// either null or key exists (same key will be overwritten)
		table[hash] = new Entry(key, value);
	}
}

public class HashtableDemo {

	public static void main(String[] args) {
		Hashtable hashtable = new Hashtable();

		hashtable.put(1, 100);
		hashtable.put(2, 200);

		System.out.println(hashtable.get(1));
		System.out.println(hashtable.get(3));
		System.out.println(hashtable.get(2));
	}
}