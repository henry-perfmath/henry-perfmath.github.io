package jcp.appendix.a.hashtable;

class LinkedEntry {
	private int key;
	private int value;
	private LinkedEntry next;

	LinkedEntry(int key, int value) {
		this.key = key;
		this.value = value;
		this.next = null;
	}

	public int getKey() {
		return key;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public LinkedEntry getNext() {
		return this.next;
	}

	public void setNext(LinkedEntry next) {
		this.next = next;
	}
}

class LinkedHashTable {
	private final static int TABLE_SIZE = 64;

	LinkedEntry[] table;

	LinkedHashTable() {
		table = new LinkedEntry[TABLE_SIZE];
		for (int i = 0; i < TABLE_SIZE; i++) {
			table[i] = null;
		}
	}

	public int get(int key) {
		
		int hash = key % TABLE_SIZE; // calculate hash
		
		if (table[hash] == null) { // check if entry exists
			return -1;
		} else {
			LinkedEntry entry = table[hash]; // current entry
			while (entry != null && entry.getKey() != key) {
				entry = entry.getNext();
			}
			
			if (entry == null) { // return -1 if not found
				return -1;
			} else {
				return entry.getValue(); // key found
			}
		}
	}

	public void put(int key, int value) {
		int hash = key % TABLE_SIZE;

		LinkedEntry entry = new LinkedEntry(key, value);

		if (table[hash] == null) { // first element
			table[hash] = entry;
		} else { // insert into the list
			LinkedEntry currEntry = table[hash];

			while (currEntry.getNext() != null
					&& currEntry.getNext().getKey() != key) { // check next
				currEntry = currEntry.getNext();
			}

			if (currEntry.getNext() == null) { // new entry does not exist
				currEntry.setNext(entry);
			} else { // entry exists. update the value
				currEntry.setValue(value);
			}
		}
	}

	public void remove(int key) {
		int hash = key % TABLE_SIZE;

		if (table[hash] != null) { // exists
			LinkedEntry entry = table[hash];
			LinkedEntry prevEntry = null;
			while (entry != null && entry.getKey() != key) {
				prevEntry = entry;
				entry = entry.getNext();
			}
			if (entry.getKey() == key) { // key found
				if (prevEntry == null) { // first node to delete
					table[hash] = entry.getNext();
				} else {
					prevEntry.setNext(entry.getNext());
				}
				entry = null;
			} else {
				System.out.println("key " + key + " not found!");
			}
		}

	}
}

public class LinkedHashTableDemo {

	public static void main(String[] args) {

		LinkedHashTable linkedHashTable = new LinkedHashTable();
		linkedHashTable.put(8, 80);
		linkedHashTable.put(16, 160);
		linkedHashTable.put(24, 240);

		System.out.println(linkedHashTable.get(8));
		System.out.println(linkedHashTable.get(16));
		System.out.println(linkedHashTable.get(24));

		linkedHashTable.remove(9);
		linkedHashTable.remove(8);

		System.out.println(linkedHashTable.get(8));
		System.out.println(linkedHashTable.get(16));
		System.out.println(linkedHashTable.get(24));
	}
}