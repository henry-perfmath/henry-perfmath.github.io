package jcp.ch7.synchedcollections;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.LinkedTransferQueue;
import java.util.concurrent.TimeUnit;

class LTQThread extends Thread {
	int id;
	Random random;
	LinkedTransferQueue<String> linkedTransferQueue;

	LTQThread(int id, LinkedTransferQueue<String> linkedTransferQueue) {
		this.id = id;
		this.random = new Random();
		this.linkedTransferQueue = linkedTransferQueue;
	}

	public void run() {
		int IMAX = 10000;
		for (int i = 0; i < IMAX; i++) {
			boolean output = (i % (IMAX / 10)) == 0;
			if ((id % 2) == 0) {
				try {
					String item = id + "_" + random.nextInt(IMAX);
					linkedTransferQueue.transfer(item);
					if (output)
						System.out.println ("Thread " + id + " transfer: " + item);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			} else {
				try {
					String value = linkedTransferQueue.take();
					if (output)
						System.out.println ("Thread " + id + " take: " + value);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
}

public class LinkedTransferQueueDemo {

	public static void main(String[] args) {

		int POOL_SIZE = 8;
		
		// 1. create a concurrent linked queue
		LinkedTransferQueue<String> linkedTransferQueue = 
				new LinkedTransferQueue<String> ();

		// 2. create a newFixedThreadPool using the ExecutorService class
		ExecutorService executorService = Executors
				.newFixedThreadPool(POOL_SIZE);

		// 3. launch worker threads
		for (int i = 0; i < POOL_SIZE; i++) {
			executorService.execute(new LTQThread(i, linkedTransferQueue));
		}

		// 4. shut down executorService to avoid resource leak
		executorService.shutdown();
		
		// 5. wait until all threads are done
		try {
			executorService.awaitTermination(Integer.MAX_VALUE, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println ("size = " + linkedTransferQueue.size());
	}
}
