package jcp.ch7.synchedcollections;

import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed; 
import java.util.concurrent.TimeUnit; 

class DelayObject implements Delayed {
	private Integer id;
	private long startTime;

	public DelayObject(Integer id, long delay) {
		this.id = id;
		this.startTime = System.currentTimeMillis() + delay;
	}

	public long getDelay(TimeUnit unit) {
		long diff = startTime - System.currentTimeMillis();
		return unit.convert(diff, TimeUnit.MILLISECONDS);
	}

	public int compareTo(Delayed obj) {
		long objStartTime = ((DelayObject) obj).startTime;
		if (this.startTime == objStartTime) return 0;
		return (this.startTime < objStartTime) ? -1 : 1;
	}

	public String toString() {
		return "DelayObject: id = " + id + ", delay = " + getDelay(TimeUnit.MILLISECONDS);
	}
}

class DelayQueueProducer implements Runnable {
	BlockingQueue<DelayObject> queue;

	DelayQueueProducer (BlockingQueue<DelayObject> queue) {
		this.queue = queue;
		new Thread(this, "DelayQueueProducer").start();
	}

	public void run() {

		Random random = new Random();
		for (int i = 0; i < 10; i++) {
			try {
				// 1. create a delayed object 
				int delay = random.nextInt(10000); 
				DelayObject object = new DelayObject(new Integer(random.nextInt(Integer.MAX_VALUE)), delay); 
				
				// 2. put delayed object into queue
				queue.put(object);
				System.out.println("producer put " + object.toString());
			} catch (InterruptedException ie) {
				System.out.println("producer interrupted");
			}
		}
	}
}

class DelayQueueConsumer implements Runnable {
	BlockingQueue<DelayObject> queue;

	DelayQueueConsumer (BlockingQueue<DelayObject> queue) {
		this.queue = queue;
		new Thread(this, "DelayQueueConsumer").start();
	}

	public void run() {
		for (int i = 0; i < 10; i++) {
			try {
				DelayObject delayObject = queue.take();
				System.out.println("consumer get " + delayObject.toString());
			} catch (InterruptedException ie) {
				System.out.println("consumer interrupted");
			}
		}
	}
}

public class DelayQueueDemo {
	public static void main(String args[]) {

		// 1. create a delay queue
		DelayQueue<DelayObject> delayQueue = new DelayQueue<DelayObject>();

		// 2. pass delay queue to producer and consumer
		new DelayQueueProducer(delayQueue);
		new DelayQueueConsumer(delayQueue);
	}
}
