package jcp.ch7.synchedcollections;

import java.util.concurrent.SynchronousQueue;

public class SynchronousQueueDemo {
	public static void main(String args[]) {

		SynchronousQueue<Integer> syncrhonousQueue = new SynchronousQueue<Integer>();
		new Producer2(syncrhonousQueue);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new Consumer2(syncrhonousQueue);
	}
}

class Consumer2 implements Runnable {
	private SynchronousQueue<Integer> syncrhonousQueue;

	Consumer2(SynchronousQueue<Integer> syncrhonousQueue) {
		this.syncrhonousQueue = syncrhonousQueue;
		new Thread(this, "Consumer").start();
	}

	public void run() {
		while (true) {
			try {
				int number = (Integer) syncrhonousQueue.take();
				System.out.println("consumer got " + number);
				Thread.sleep(2000);
			} catch (InterruptedException ie) {
				System.out.println("consumer interrupted");
			}
		}
	}
}

class Producer2 implements Runnable {
	SynchronousQueue<Integer> syncrhonousQueue;

	Producer2(SynchronousQueue<Integer> syncrhonousQueue) {
		this.syncrhonousQueue = syncrhonousQueue;
		new Thread(this, "Producer").start();
	}

	public void run() {
		int i = 0;

		while (true) {
			try {
				syncrhonousQueue.put(new Integer(i));
				System.out.println("producer put " + i);
				Thread.sleep(2000);
				i++;
			} catch (InterruptedException ie) {
				System.out.println("producer interrupted");
			}
		}
	}
}