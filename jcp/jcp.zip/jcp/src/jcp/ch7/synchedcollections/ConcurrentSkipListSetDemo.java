package jcp.ch7.synchedcollections;

import java.util.Iterator;
import java.util.NavigableSet;
import java.util.Random;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

class SkipListSetThread extends Thread {
	int id;
	Random random;
	ConcurrentSkipListSet<Integer> concurrentSkipListSet;

	SkipListSetThread(int id, ConcurrentSkipListSet<Integer> concurrentSkipListSet) {
		this.id = id;
		this.random = new Random();
		this.concurrentSkipListSet = concurrentSkipListSet;
	}

	public void run() {
		int IMAX = 10000;
		for (int i = 0; i < IMAX; i++) {
			Integer element = random.nextInt(IMAX);
			boolean output = (i % (IMAX / 10)) == 0;
			if ((id % 4) == 0) {
				concurrentSkipListSet.add(element);
				if (output)
					System.out.println ("Thread " + id + " add: " + element);
			} else {
				element = concurrentSkipListSet.pollFirst();
				if (output)
					System.out.println ("Thread " + id + " pollFirst: " + element);
			}
		}
	}
}

public class ConcurrentSkipListSetDemo {

	public static void main(String[] args) {

		int POOL_SIZE = 8;
		ConcurrentSkipListSet<Integer> concurrentSkipListSet = 
				new ConcurrentSkipListSet<Integer> ();

		// 1. Create a newFixedThreadPool using the Executors utility class
		ExecutorService executorService = Executors
				.newFixedThreadPool(POOL_SIZE);

		// 2. launch skip list skip list set threads
		for (int i = 0; i < POOL_SIZE; i++) {
			executorService.execute(new SkipListSetThread(i, concurrentSkipListSet));
		}

		// 3. shut down executorService to avoid resource leak
		executorService.shutdown();
		
		// 4. wait until all threads are done
		try {
			executorService.awaitTermination(Integer.MAX_VALUE, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println ("size = " + concurrentSkipListSet.size());
		
		// 5. check iterator, subSet, headSet and tailSet
		System.out.println ("\ncall checkIterator: ");
		checkIterator (concurrentSkipListSet);
		
		System.out.println ("\ncall checkSubSet: ");
		checkSubSet (concurrentSkipListSet);
		
		System.out.println ("\ncall checkHeadSet: ");
		checkHeadSet (concurrentSkipListSet);
		
		System.out.println ("\ncall checkTailSet: ");
		checkTailSet (concurrentSkipListSet);
	}
	
	public static void checkIterator (ConcurrentSkipListSet<Integer> concurrentSkipListSet) {

		Iterator<Integer> iterator = concurrentSkipListSet.iterator();
		int i = 0;
		while (i < 5 && iterator.hasNext()) {
			Integer element = iterator.next();
			System.out.println("element = " + element); 
			i++;
		}
	}
	
	public static void checkSubSet (ConcurrentSkipListSet<Integer> concurrentSkipListSet) {
		NavigableSet<Integer> subSet = concurrentSkipListSet.subSet(20, 50); 
		printSet (subSet);
	}
		
	public static void checkHeadSet (ConcurrentSkipListSet<Integer> concurrentSkipListSet) {
		NavigableSet<Integer> headSet = concurrentSkipListSet.headSet(5); 
		printSet (headSet);
	}

	public static void checkTailSet (ConcurrentSkipListSet<Integer> concurrentSkipListSet) {
		NavigableSet<Integer> tailSet = concurrentSkipListSet.tailSet(100); 
		printSet (tailSet);
	}
	
	public static void printSet (NavigableSet<Integer> set) {
		Iterator<Integer> iterator = set.iterator();
		int i = 0;
		while (i < 5 && iterator.hasNext()) {
			Integer element = iterator.next();
			System.out.println("element = " + element); 
			i++;
		}
	}
}