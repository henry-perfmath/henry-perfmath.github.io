package jcp.ch7.synchedcollections;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;

class LBDThread extends Thread {
	int id;
	Random random;
	LinkedBlockingDeque<String> linkedBlockingDeque;

	LBDThread(int id, LinkedBlockingDeque<String> linkedBlockingDeque) {
		this.id = id;
		this.random = new Random();
		this.linkedBlockingDeque = linkedBlockingDeque;
	}

	public void run() {
		int IMAX = 10000;
		for (int i = 0; i < IMAX; i++) {
			String item = id + "_" + random.nextInt(IMAX);
			boolean output = (i % (IMAX / 10)) == 0;
			if ((id % 2) == 0) {
				linkedBlockingDeque.push(item);
				if (output)
					System.out.println ("Thread " + id + " push: " + item);
			} else if (!linkedBlockingDeque.isEmpty()) {
				String value = linkedBlockingDeque.pop();
				if (output)
					System.out.println ("Thread " + id + " pop: " + value);
			}
		}
	}
}

public class LinkedBlockingDequeDemo {

	public static void main(String[] args) {

		int POOL_SIZE = 8;
		
		// 1. create a concurrent linked queue
		LinkedBlockingDeque<String> linkedBlockingDeque = 
				new LinkedBlockingDeque<String> ();

		// 2. create a newFixedThreadPool using the ExecutorService class
		ExecutorService executorService = Executors
				.newFixedThreadPool(POOL_SIZE);

		// 3. launch worker threads
		for (int i = 0; i < POOL_SIZE; i++) {
			executorService.execute(new LBDThread(i, linkedBlockingDeque));
		}

		// 4. shut down executorService to avoid resource leak
		executorService.shutdown();
		
		// 5. wait until all threads are done
		try {
			executorService.awaitTermination(Integer.MAX_VALUE, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println ("size = " + linkedBlockingDeque.size());
	}
}
