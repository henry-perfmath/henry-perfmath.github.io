package jcp.ch7.synchedcollections;

import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

class COWArrayListThread extends Thread {
	int id;
	Random random;
	CopyOnWriteArrayList<String> cowArrayList;

	COWArrayListThread(int id, CopyOnWriteArrayList<String> cowArrayList) {
		this.id = id;
		this.random = new Random();
		this.cowArrayList = cowArrayList;
	}

	public void run() {
		int IMAX = 10000;
		for (int i = 0; i < IMAX; i++) {
			boolean output = (i % (IMAX / 10)) == 0;
			if (id == 0) {
				String item = id + "_" + i + "_" + random.nextInt(IMAX);
				cowArrayList.add(item);
				if (output)
					System.out.println("Thread " + id + " add: " + item);
			} else if(!cowArrayList.isEmpty()) {
				int n = cowArrayList.size();
				int index = random.nextInt(n);
				String value = index + "_" + cowArrayList.get(index);
				if (output)
					System.out.println("Thread " + id + " get: " + value);
			}
		}
	}
}

public class COWArrayListDemo {

	public static void main(String[] args) {

		int POOL_SIZE = 8;

		// 1. create a COW array list
		CopyOnWriteArrayList<String> cowArrayListThread = new CopyOnWriteArrayList<String>();

		// 2. create a newFixedThreadPool using the ExecutorService class
		ExecutorService executorService = Executors
				.newFixedThreadPool(POOL_SIZE);

		// 3. launch COW array list threads
		for (int i = 0; i < POOL_SIZE; i++) {
			executorService.execute(new COWArrayListThread(i,
					cowArrayListThread));
		}

		// 4. shut down executorService to avoid resource leak
		executorService.shutdown();

		// 5. wait until all threads are done
		try {
			executorService.awaitTermination(Integer.MAX_VALUE,
					TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("size = " + cowArrayListThread.size());
	}
}
