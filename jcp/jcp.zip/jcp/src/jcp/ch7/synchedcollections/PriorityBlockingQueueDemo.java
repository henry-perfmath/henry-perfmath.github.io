package jcp.ch7.synchedcollections;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.PriorityBlockingQueue;

class Scheduler extends Thread {
	int id;
	Random random;
	PriorityBlockingQueue<Integer> priorityBlockingQueue;

	Scheduler(int id, PriorityBlockingQueue<Integer> priorityBlockingQueue) {
		this.id = id;
		this.random = new Random();
		this.priorityBlockingQueue = priorityBlockingQueue;
	}

	public void run() {
		for (int i = 0; i < 5; i++) {
			priorityBlockingQueue.add(random.nextInt(100));
		}
	}
}

public class PriorityBlockingQueueDemo {

	public static void main(String[] args) {
		PriorityBlockingQueue<Integer> pbq = new PriorityBlockingQueue<Integer>();

		int POOL_SIZE = 3;
		// 1. Create a newFixedThreadPool using the Executors utility class
		ExecutorService executorService = Executors
				.newFixedThreadPool(POOL_SIZE);

		// 2. launch schedulers
		for (int i = 0; i < POOL_SIZE; i++) {
			executorService.execute(new Scheduler(i, pbq));
		}

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		// 3. shut down executorService to avoid resource leak
		executorService.shutdown();

		for (int i = 0; i < 3; i++) {
			// 4. check queue and size
			System.out.println("current pbq = " + pbq + " (size = "
					+ pbq.size() + ")");

			// 5. peek the highest priority
			System.out.println("after peek: " + pbq.peek() + ", pq = " + pbq
					+ " (size = " + pbq.size() + ")");

			// 6. return highest priority and remove it from the queue
			System.out.println("after poll: " + pbq.poll() + ", pq = " + pbq
					+ " (size = " + pbq.size() + ")\n");
		}
	}
}
