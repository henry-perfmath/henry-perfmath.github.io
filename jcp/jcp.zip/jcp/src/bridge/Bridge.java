package bridge;
/**
 * Author: Henry H Liu Date: 11/02/13
 */
public class Bridge {

	private static Bridge instance = null;
	public static final int maxCars = 3;  // max # of cars permitted on the bridge
	private static int[] numCarsCrossing; // # of cars on the bridge in a given direction
	private static int[] numCarsCrossed;  // # of cars crossed the bridge in a given direction
	private static int[] numCarsWaiting;  // # of cars waiting in a given direction
	
	public static Bridge getInstance () {
		// for better performance, do not synchronize the method 
		if (instance == null) {
			synchronized (Bridge.class) {
				instance = new Bridge();
			}
		}
		return instance;
	}

	protected Bridge() {
		numCarsCrossing = new int[2];
		numCarsCrossing[0] = 0;
		numCarsCrossing[1] = 0;

		numCarsCrossed = new int[2];
		numCarsCrossed[0] = 0;
		numCarsCrossed[1] = 0;

		numCarsWaiting = new int[2];
		numCarsWaiting[0] = 0;
		numCarsWaiting[1] = 0;
	}
	public synchronized static int getNumCarsCrossing(int dir) {
		return numCarsCrossing [dir];
	}
	public synchronized static int getNumCarsCrossed(int dir) {
		return numCarsCrossed [dir];
	}
	public synchronized static int getNumCarsWaiting(int dir) {
		return numCarsWaiting [dir];
	}
	
	// to be called when a car exits the bridge
	public synchronized static void setExit(int dir) {
		numCarsCrossing[dir]--;
		if (numCarsCrossed[dir] < maxCars) {
			numCarsCrossed[dir]++;
		} else {
			numCarsCrossed[dir] = 0;
		}
	}

	// to be called when a car starts to cross the bridge
	public synchronized static boolean setCrossing(int dir) {
		// check current direction if more than maxCars on the bridge
		boolean success =  (numCarsCrossing[dir] < maxCars);
		if (success) numCarsCrossing[dir]++;
		if (success && numCarsWaiting[dir] > 0) {
			numCarsWaiting[dir]--;
			return true;
		} else {
			return false;
		}
	}
	
	// to be called when a car arrives at the entarnce to the bridge
	public synchronized static void setWaiting(int dir) {
		numCarsWaiting[dir]++;
	}
	
	// to be called when max # of cars have crossed the bridge
	public synchronized static void clearCrossed(int dir) {
		numCarsCrossed[dir] = 0;
	}
	
	// to be called for checking whther a car can get on the brdige
	public synchronized static boolean canGo(int direction) {
		boolean okToGo = false;
		int otherDirection = 1 - direction;
		// on the other side: max cars have crossed or less than max cars
		// crossed but no cars waiting => FAIRNESS imposed here
		if ((getNumCarsCrossed(otherDirection) == maxCars)
				|| ((getNumCarsCrossed(otherDirection) > 0) && (getNumCarsWaiting(otherDirection) == 0))) {
			clearCrossed(otherDirection);
			okToGo = true;
			// on the other side, no cars on the bridge AND
			// on this side: less than max cars crossed
		} else if ((getNumCarsCrossing(otherDirection) + getNumCarsCrossed(otherDirection)) == 0
				&& (getNumCarsCrossing(direction) + getNumCarsCrossed(direction)) < maxCars) {
			okToGo = true;
			// other side empty
		} else if ((getNumCarsCrossing(otherDirection)
				+ getNumCarsCrossed(otherDirection) + getNumCarsWaiting(otherDirection)) == 0) {
			okToGo = true;
		}
		if (okToGo) {
			if (!setCrossing(direction)) {
				okToGo = false;
			}
		}
		return okToGo;
	}

	// to be called to check the # of cars "waiting" "crossing" "crossed" for each direction
	public synchronized static String checkStatus() {
		return " " + getNumCarsWaiting(0) + " " + getNumCarsCrossing(0)
				+ " " + getNumCarsCrossed(0) + " : "
				+ getNumCarsWaiting(1) + " " + getNumCarsCrossing(1)
				+ " " + getNumCarsCrossed(1);
	}
}