package bridge;

/**
 * Author: Henry H Liu Date: 11/02/13
 */
public class Car extends Thread {
	private String name;
	private int direction;
	private boolean crossed;

	public Car(String name, int direction) {
		super(name);
		this.name = name;
		this.direction = direction;
		this.crossed = false;
	}

	public void run() {
		while (!crossed) {
			if (Bridge.canGo(direction)) {
				go();
			} else {
				waiting(1000); // waiting an arbitrary period of 1000 ms
			}
		}
	}

	public void go() {
		System.out.println(getCarName()
				+ " is crossing the bridge to direction " + direction + " "
				+ Bridge.checkStatus());

		crossing(1500); // to simulate crossing bridge time
		exitBridge();
	}

	public void crossing(long waitTime) {
		try {
			sleep(waitTime);
		} catch (InterruptedException ie) {
			System.out.println(getCarName() + " sleeping interrupted ...");
		}
	}

	public void waiting(long waitTime) {
		/*
		System.out.println("\t" + getCarName()
				+ " is waiting to cross the bridge to direction " + direction
				+ " " + Bridge.checkStatus());
				*/
		try {
			sleep(waitTime);
		} catch (InterruptedException ie) {
			System.out.println(getCarName() + " sleeping interrupted ...");
		}
	}

	public void exitBridge() {
		Bridge.setExit(direction);
		System.out.println("\t\t..." + getCarName()
				+ " crossed the bridge to direction " + direction + " "
				+ Bridge.checkStatus());
		crossed = true;
	}

	public String getCarName() {
		if (direction == 0) {
			return name + " (->) ";
		} else {
			return name + " (<-) ";
		}
	}
}