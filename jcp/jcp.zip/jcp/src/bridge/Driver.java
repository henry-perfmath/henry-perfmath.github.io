package bridge;

/**
 * Author: Henry H Liu Date: 11/02/13
 */
public class Driver {
	private static int numCars;

	public static void main(String[] args) throws InterruptedException {
		if (args.length > 1) {
			System.out.println("usage: java Driver numCars");
			System.exit(-1);
		} else if (args.length == 1) {
			numCars = Integer.parseInt(args[0]);
			System.out.println("total # of cars on both ends: " + numCars);
		}
		
		// prepare the bridge
		Bridge.getInstance();
		
		// make and start cars
		for (int i = 0; i < numCars; i++) {
			int direction = ((int) (Math.random() * numCars) % 2);
			// int direction = i % 2;
			String name = "car" + i;
			Car car = new Car(name, direction);
			Bridge.setWaiting(direction);
			car.start();
		}
	}
}
