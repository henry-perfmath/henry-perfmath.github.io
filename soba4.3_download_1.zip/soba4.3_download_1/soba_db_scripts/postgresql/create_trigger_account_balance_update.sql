CREATE OR REPLACE FUNCTION account_balance_update () RETURNS trigger AS $$

  DECLARE account_new_balance decimal(10,2);
  BEGIN
	SELECT ACCOUNT.BALANCE INTO account_new_balance FROM ACCOUNT WHERE ACCOUNT.ACCOUNT_ID = new.ACCOUNT_ID;
	account_new_balance := account_new_balance + new.AMOUNT;
  UPDATE ACCOUNT SET BALANCE = account_new_balance WHERE ACCOUNT.ACCOUNT_ID = new.ACCOUNT_ID;
  new.balance := account_new_balance;
  RETURN NEW;
  END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER account_balance_update
  BEFORE INSERT on BANKINGTX

  FOR EACH ROW EXECUTE PROCEDURE account_balance_update ();
