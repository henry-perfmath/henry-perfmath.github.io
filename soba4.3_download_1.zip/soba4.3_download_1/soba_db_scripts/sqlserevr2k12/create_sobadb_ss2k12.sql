CREATE DATABASE soba;
GO

CREATE LOGIN sobaadmin 
    WITH PASSWORD = 'sobaadmin',
    DEFAULT_DATABASE = soba;
USE soba;
GO
CREATE USER sobaadmin FOR LOGIN sobaadmin;
GO 
EXEC sp_addrolemember 'db_owner', 'sobaadmin';
GO

 
