DELIMITER //
CREATE TRIGGER account_balance_update
  BEFORE INSERT  on BANKINGTX

  FOR EACH ROW
  BEGIN
  DECLARE account_new_balance DECIMAL (10,2);
	SELECT BALANCE INTO account_new_balance FROM ACCOUNT WHERE ACCOUNT.ACCOUNT_ID = new.ACCOUNT_ID;
	SET account_new_balance = account_new_balance + new.AMOUNT;
  UPDATE ACCOUNT SET BALANCE = account_new_balance WHERE ACCOUNT.ACCOUNT_ID = new.ACCOUNT_ID;
  SET new.balance = account_new_balance;
  END//
  DELIMITER ;
