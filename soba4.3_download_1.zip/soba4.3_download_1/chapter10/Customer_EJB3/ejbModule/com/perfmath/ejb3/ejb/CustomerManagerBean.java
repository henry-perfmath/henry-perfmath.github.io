package com.perfmath.ejb3.ejb;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.*;

import org.jboss.ejb3.annotation.LocalBinding;
import org.jboss.ejb3.annotation.RemoteBinding;

import com.perfmath.ejb3.jpa.*;

@Stateless

@RemoteBinding(jndiBinding="CustomerManagerEJB3/remote")
@LocalBinding(jndiBinding="CustomerManagerEJB3/local")

public  class CustomerManagerBean implements CustomerManagerLocal,
                                          CustomerManagerRemote {
	@PersistenceContext(unitName="CustomerEJB3")   
	private EntityManager em;

	public void createCustomer(String name, String password, String email, boolean locked) {
		Customer customer = new Customer();   
		customer.setName(name);
		customer.setPassword(password);
		customer.setEmail(email);
		customer.setLocked(locked);
		em.persist(customer);                
	}
	public void saveTxs(int customerId, BigDecimal amount,
			String description, String type) {		
		Customer customer = findCustomerById(customerId);
		
		BankingTx bankingTx = new BankingTx();
		bankingTx.setCustomer(customer);
		bankingTx.setAmount(amount);
		bankingTx.setDescription(description);
		bankingTx.setType(type);
		em.persist(bankingTx);
	}

	public List<BankingTx> findAllTxs(int customerId)  
	{ 
		Query query = em.createQuery("FROM Customer where id=:id");  
		query.setParameter("id", customerId);  
		Customer customer = (Customer)query.getSingleResult();

		List <BankingTx>bankingTxs = customer.getBankingTxs();

		return bankingTxs;      	 
	}
	public Customer findCustomerByName(String customerName)
	{
		Query query = em.createQuery("FROM Customer where name=:name");  
		query.setParameter("name", customerName);  
		Customer customer = (Customer)query.getSingleResult();

		return customer;      	 
	}

	public Customer findCustomerById(int customerId)
	{
		Query query = em.createQuery("FROM Customer where id=:id");  
		query.setParameter("id", customerId);  
		Customer customer = (Customer)query.getSingleResult();

		return customer;      	 
	}
	public List<Customer> findAllCustomers() {
		Query query = em.createQuery("FROM Customer");
		List<Customer> customerList = query.getResultList();

		return customerList;      	 
	}

}
