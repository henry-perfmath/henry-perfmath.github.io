package com.ejb2.test;
import javax.ejb.*;
import java.rmi.*;

public interface CustomerSessionHome extends EJBHome{
	CustomerSession create () throws RemoteException, CreateException;
}
