package com.ejb2.test;

import java.util.Collection;
import javax.ejb.CreateException;

public interface CustomerDAO {

	public String dbGetKey();

	public void dbInsertCustomer(CustomerModel data) throws CreateException;

	public boolean dbSelectByPrimaryKey(String primaryKey)
			throws CustomerDAOSysException;

	public Collection dbSelectByCustomerName(String name)
			throws CustomerDAOSysException;

	public Collection dbSelectAll() throws CustomerDAOSysException;

	public CustomerModel dbLoadCustomer(String primaryKey)
			throws CustomerDAOSysException;

	public void dbStoreCustomer(CustomerModel data)
			throws CustomerDAOSysException;

	public void dbRemoveCustomer(String primaryKey)
			throws CustomerDAOSysException;

	public int dbCountTotalCustomers() throws CustomerDAOSysException;
}
