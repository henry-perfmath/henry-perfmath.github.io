package com.ejb2.test;

import javax.ejb.*;
import java.rmi.*;

public interface Customer extends EJBObject
{
    public String getCustomerID () throws RemoteException;
    public String getName () throws RemoteException;
    public void setName (String newName) throws RemoteException;
    public String getPassword () throws RemoteException;
    public void setPassword (String newPassword) throws RemoteException;
    public String getEmail () throws RemoteException;
    public void setEmail (String newEmail) throws RemoteException;
    public boolean getLocked () throws RemoteException;
    public void setLocked (boolean locked) throws RemoteException;
}
