package com.ejb2.test;
import java.util.*;

import javax.ejb.*;
import javax.naming.*;
import javax.sql.DataSource;
import java.sql.*;

public class CustomerDAOMySQL implements CustomerDAO{
	private Connection con = null;
	private DataSource dataSource = null;
	
	public CustomerDAOMySQL () throws CustomerDAOSysException {
		String dbName = "java:DefaultDS";
		try {
			InitialContext ic = new InitialContext ();
			dataSource = (DataSource) ic.lookup(dbName);		
		} catch (NamingException ex) {
			throw new CustomerDAOSysException (
					"Cannot connect to database: " +
			dbName + ":\n" + ex.getMessage ());
		}
	}
	@Override
	public String dbGetKey() {
		return (new RandomID(10)).getId();
	}
	private void getConnection () throws CustomerDAOSysException {

		try {
			con = dataSource.getConnection();		
		} catch (SQLException ex) {
			throw new CustomerDAOSysException (
				"Exception during db connection: " +
				":\n" + ex.getMessage ());
		}
	}
	private void disConnect  () throws CustomerDAOSysException {
		try {
			if (con != null) con.close();			
		} catch (SQLException ex) {
			throw new CustomerDAOSysException (
				"Exception during db close connection: " +
				":\n" + ex.getMessage ());
		}
	}
	private void closeStatement  (PreparedStatement s) throws CustomerDAOSysException {
		try {
			if (s != null) s.close();			
		} catch (SQLException ex) {
			throw new CustomerDAOSysException (
				"Exception during db statement close: " +
				":\n" + ex.getMessage ());
		}
	}
	private void closeResultSet  (ResultSet rs) throws CustomerDAOSysException {
		try {
			if (rs != null) rs.close();			
		} catch (SQLException ex) {
			throw new CustomerDAOSysException (
				"Exception during result set close: " +
				":\n" + ex.getMessage ());
		}
	}
	@Override
	public void dbInsertCustomer(CustomerModel data) throws CreateException {
		String insertStatement = "INSERT INTO customer (customerID, name, " +
		" password, email, locked) VALUES " +
				"( ?, ?, ?, ?, ?) ";
		PreparedStatement prepStmt = null;
		try {
			getConnection ();
			prepStmt = con.prepareStatement(insertStatement);
			prepStmt.setString(1, data.getCustomerID());
			prepStmt.setString(2, data.getName());
			prepStmt.setString(3, data.getPassword());
			prepStmt.setString(4, data.getEmail());
			prepStmt.setBoolean(5, data.getLocked());
			prepStmt.executeUpdate();
		} catch (SQLException ex) {
			throw new CreateException (ex.getMessage());
		} finally {
			closeStatement (prepStmt);
			disConnect ();
		}	
	}

	@Override
	public boolean dbSelectByPrimaryKey(String primaryKey)
			throws CustomerDAOSysException {
		String selectStatement = "select CustomerID " +
			"from customer where CustomerID = ?";
		PreparedStatement prepStmt = null;
		ResultSet rs = null;
		boolean result = false;
		try {
			getConnection ();
			prepStmt = con.prepareStatement(selectStatement);
			prepStmt.setString(1, primaryKey);
			rs = prepStmt.executeQuery();
			result= rs.next ();
		} catch (SQLException ex) {
			throw new CustomerDAOSysException (
					"dbSelectByPrimaryKey: SQL Exception caught\n" + ex.getMessage());
		} finally {
			closeResultSet (rs);
			closeStatement (prepStmt);
			disConnect ();
		}	
		return result;
	}

	@Override
	public Collection dbSelectByCustomerName(String name)
			throws CustomerDAOSysException {
			String selectStatement = "select distinct CustomerID " +
				"from customer where name = ?";
			PreparedStatement prepStmt = null;
			ResultSet rs = null;
			ArrayList a = null;
			try {
				getConnection ();
				prepStmt = con.prepareStatement(selectStatement);
				prepStmt.setString(1, name);
				rs = prepStmt.executeQuery();
				a= new ArrayList ();
				
				while (rs.next ()) {
					a.add (new String (rs.getString((1))));
				}
			} catch (SQLException ex) {
				throw new CustomerDAOSysException (
						"dbSelectByCustomerName: SQL Exception caught\n" + ex.getMessage());
			} finally {
				closeResultSet (rs);
				closeStatement (prepStmt);
				disConnect ();
			}	
			return a;
	}

	@Override
	public Collection dbSelectAll() throws CustomerDAOSysException {
		String selectStatement = "select distinct CustomerID " +
				"from customer ";
			PreparedStatement prepStmt = null;
			ResultSet rs = null;
			ArrayList a = null;
			try {
				getConnection ();
				prepStmt = con.prepareStatement(selectStatement);
				rs = prepStmt.executeQuery();
				a= new ArrayList ();
				
				while (rs.next ()) {
					a.add (new String (rs.getString((1))));
				}
			} catch (SQLException ex) {
				throw new CustomerDAOSysException (
						"dbSelectAll: SQL Exception caught\n" + ex.getMessage());
			} finally {
				closeResultSet (rs);
				closeStatement (prepStmt);
				disConnect ();
			}	
			return a;
	}

	@Override
	public CustomerModel dbLoadCustomer(String primaryKey)
			throws CustomerDAOSysException,
			NoSuchEntityException {
		String selectStatement = "select name, password, email, locked " +
				"from customer where CustomerID = ?";
			PreparedStatement prepStmt = null;
			ResultSet rs = null;
			String name = null;
			String password = null;
			String email = null;
			boolean locked = false;
			try {
				getConnection ();
				prepStmt = con.prepareStatement(selectStatement);
				prepStmt.setString (1, primaryKey);
				rs = prepStmt.executeQuery();
								
				if (rs.next ()) {
					name = rs.getString(1);
					password = rs.getString(2);
					email = rs.getString(3);
					locked = rs.getBoolean(4);
				} else {
					throw new NoSuchEntityException (
							"Row for customerID " + primaryKey +
							" not found in database");
				}
				return new CustomerModel (primaryKey, name, password, email, locked);
			} catch (SQLException ex) {
				throw new CustomerDAOSysException (
						"dbLoadCustomer: SQL Exception caught\n" + ex.getMessage());
			} finally {
				closeResultSet (rs);
				closeStatement (prepStmt);
				disConnect ();
			}	
	}

	@Override
	public void dbStoreCustomer(CustomerModel data)
			throws CustomerDAOSysException {
		String updateStatement = "update customer set " +
			"Name = ?, " + " Password = ? ," + " Email = ? , " +
			" locked = ? " + "where CustomerID = ?";
			PreparedStatement prepStmt = null;
			ResultSet rs = null;
			String name = null;
			String password = null;
			String email = null;
			boolean locked = false;
			try {
				getConnection ();
				prepStmt = con.prepareStatement(updateStatement);
				prepStmt.setString(1, data.getName());
				prepStmt.setString(2, data.getPassword());
				prepStmt.setString(3, data.getEmail());
				prepStmt.setBoolean(4, data.getLocked());
				prepStmt.setString(5, data.getCustomerID());
				int rowCount = prepStmt.executeUpdate();
								
				if (rowCount == 0) {
					throw new SQLException (
							"Storing row for customerID " + data.getCustomerID() +
							" failed");
				}
			} catch (SQLException ex) {
				throw new CustomerDAOSysException (
						"dbStoreCustomer: SQL Exception caught\n" + ex.getMessage());
			} finally {
				closeStatement (prepStmt);
				disConnect ();
			}	
		}

	@Override
	public void dbRemoveCustomer(String primaryKey)
			throws CustomerDAOSysException {
		String removeStatement = "delete from customer where CustomerID = ?";
				PreparedStatement prepStmt = null;
				try {
					getConnection ();
					prepStmt = con.prepareStatement(removeStatement);
					prepStmt.setString(1, primaryKey);
					int result = prepStmt.executeUpdate();
									
					if (result == 0) {
						throw new SQLException (
								"Remove for customerID " + primaryKey +
								" failed");
					}
				} catch (SQLException ex) {
					throw new CustomerDAOSysException (
							"dbRemoveCustomer: SQL Exception caught\n" + ex.getMessage());
				} finally {
					closeStatement (prepStmt);
					disConnect ();
				}	
		
	}

	@Override
	public int dbCountTotalCustomers() throws CustomerDAOSysException {
		String selectStatement = "select distinct CustomerID from customer";
				PreparedStatement prepStmt = null;
				ResultSet rs = null;
				int count =0;
				try {
					getConnection ();
					prepStmt = con.prepareStatement(selectStatement,
							ResultSet.TYPE_SCROLL_INSENSITIVE,
							ResultSet.CONCUR_UPDATABLE);
					rs = prepStmt.executeQuery();
					rs.last ();
					count = rs.getRow();	
				} catch (SQLException ex) {
					throw new CustomerDAOSysException (
							"dbCountTotalCustomers: SQL Exception caught\n" + ex.getMessage());
				} finally {
					closeResultSet (rs);
					closeStatement (prepStmt);
					disConnect ();
				}	
		return count;
	}

}
