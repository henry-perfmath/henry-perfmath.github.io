import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class StorePartitioner extends Partitioner <Text, IntWritable>{
	@Override
	public int getPartition (Text key, IntWritable count, int numPartitions) {
		int index = key.toString ().indexOf (" ");
		String storePrefix = key.toString ();
		if ( index > 0) {
			storePrefix = storePrefix.substring (0, index);
		} 
		return Math.abs(storePrefix.hashCode ()) % numPartitions;
	}
}
