import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;
public class SpendingPatternMapper1b extends  MapReduceBase
  implements Mapper<LongWritable, Text, Text, FloatWritable> {
  
  @Override
  public void map(LongWritable key, Text value, OutputCollector <Text, FloatWritable> output, Reporter reporter)
      throws IOException {
    
    String line = value.toString();
    if (!line.contains ("PAYMENT")) {
    	StringTokenizer st = new StringTokenizer (line, "\t");
    	String tranxDate = st.nextToken();
    	String description = st.nextToken();
    	float amount = Float.parseFloat(st.nextToken());
    	output.collect(new Text(description), new FloatWritable(amount));
    }
  }
}
