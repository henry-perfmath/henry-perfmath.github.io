import java.io.*;

public class Lucky5WritableDriver {
	public static void main(String[] args) throws IOException {

		testLucky5Writable();
		testLucky5WritableComparable();

	}

	public static void testLucky5Writable() throws FileNotFoundException {
		DataInputStream dis = new DataInputStream(new FileInputStream(
				"writable.txt"));
		DataOutputStream dos = new DataOutputStream(new FileOutputStream(
				"writeOut.txt"));
		try {

			Lucky5Writable writable = Lucky5Writable.read(dis);

			writable.write(dos);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (dis != null)
					dis.close();
				if (dos != null)
					dos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void testLucky5WritableComparable()
			throws FileNotFoundException {
		DataInputStream dis1 = new DataInputStream(new FileInputStream(
				"writable.txt"));
		DataInputStream dis2 = new DataInputStream(new FileInputStream(
				"writeOut1.txt"));
		DataOutputStream dos = new DataOutputStream(new FileOutputStream(
				"writeOut2.txt"));
		try {
			Lucky5WritableComparable writableComparable1 = Lucky5WritableComparable
					.read(dis1);
			System.out.println(writableComparable1.toString());
			Lucky5WritableComparable writableComparable2 = Lucky5WritableComparable
					.read(dis2);
			System.out.println(writableComparable2.toString());

			int result1 = writableComparable1.compareTo(writableComparable1);
			int result2 = writableComparable2.compareTo(writableComparable1);
			System.out.println("result1 = " + result1);
			System.out.println("result2 = " + result2);
			writableComparable2.write(dos);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (dis1 != null)
					dis1.close();
				if (dis2 != null)
					dis2.close();
				if (dos != null)
					dos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
