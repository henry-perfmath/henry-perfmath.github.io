

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapred.FileInputFormat;
//import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.TextInputFormat;
import org.apache.hadoop.mapred.TextOutputFormat;

import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.lib.ChainMapper;
import org.apache.hadoop.mapred.lib.ChainReducer;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.hadoop.conf.*;

public class SpendingPattern1i {

	public static void main (String[] args) throws Exception {
		Configuration conf = new Configuration();


		//String remainingArgs[] = new GenericOptionsParser(conf, args).getRemainingArgs();
		//JobConf job = JobInit1.init (this, getConf (), args);
	    if (args.length != 2) {
	        //printUsage(tool, "<input> <output>");
	        System.exit (-1);
	      }
	      JobConf jobConf = new JobConf(conf);
	      jobConf.setJarByClass(SpendingPattern1h.class);
	      FileInputFormat.addInputPath(jobConf, new Path(args[0]));
	      FileOutputFormat.setOutputPath(jobConf, new Path(args[1]));
	      
		//if (job == null) {
		////	return -1;
		//}
	      jobConf.setJobName("Spending Pattern ChainMapper");
	      jobConf.setInputFormat(TextInputFormat.class);
	      jobConf.setOutputFormat(TextOutputFormat.class);

		JobConf map0Conf = new JobConf (false);
		ChainMapper.addMapper(jobConf, SpendingPatternMapper1b.class, 
				LongWritable.class, Text.class, Text.class, 
				FloatWritable.class, true, map0Conf);

		JobConf map1Conf = new JobConf (false);
		ChainMapper.addMapper(jobConf, SpendingPatternMapper1c.class, 
				Text.class, FloatWritable.class, Text.class, 
				FloatWritable.class, false, map1Conf);
		JobConf reduceConf = new JobConf (false);
		ChainReducer.setReducer (jobConf, SpendingPatternReducer1a.class, 
				Text.class, FloatWritable.class, Text.class, 
				FloatWritable.class,true, reduceConf);
		//job.setOutputKeyClass(Text.class);
		//job.setOutputValueClass(FloatWritable.class);
		 JobClient.runJob (jobConf);
		//return job.waitForCompletion(true) ? 0 : 1;
	}

}
