import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.StringTokenizer;
import java.io.File;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.Path;

public class MapIncrease1 {
	public static PrintWriter writer = null;
	public static BufferedReader reader = null;
	public static String dataFileIn = "credit_card_tx_0.txt";
	public static String dataFileOut;
	public static ArrayList<String> keys = new ArrayList<String>();
	public static int numOfKeys = 0;

	public static void main(String[] args) throws IOException {
		Configuration conf = new Configuration();
		FileSystem fs = FileSystem.get(conf);

		String line = "";
		dataFileIn = args[0];
		dataFileOut = dataFileIn.substring(0, dataFileIn.lastIndexOf("."))
				+ "_out.txt";
		long numOfTxs = Long.parseLong(args[1]);

		Path inputFilePath = new Path(dataFileIn);
		Path outputFilePath = new Path(dataFileOut);

		try {
			FSDataInputStream in = fs.open(inputFilePath);
			reader = new BufferedReader(new InputStreamReader(in));
			while ((line = reader.readLine()) != null) {
				if (line.trim().contains("/") && !line.trim().isEmpty()
						&& !line.trim().startsWith("//")) {
					addKeys(line);
				}
			}
		} catch (IOException ioe) {
			System.out.println(dataFileIn + " not found");
		}
		FSDataOutputStream out = fs.create(outputFilePath, true);
		writer = createWriter(out);
		long startTime = System.currentTimeMillis();

		numOfKeys = keys.size();
		System.out.println("number of keys: " + numOfKeys);
		for (long i = 0; i < numOfTxs; i++) {
			String key = getKey();
			writeTx(key);
			if (i % 100000 == 0) {
				System.out.println("number of Txs written: " + i);
			}
		}
		writer.close();
		out.close();
		long totalTimeInSec = (System.currentTimeMillis() - startTime) / 1000;
		System.out.println("Total time in seconds: " + totalTimeInSec);
		if (totalTimeInSec > 60) {
			long totalTimeInMin = totalTimeInSec / 60;
			System.out.println("Total time in minutes: " + totalTimeInMin);
		}
		if (totalTimeInSec > 0) {
			System.out.println("Tx writing rate = "
					+ (numOfTxs / totalTimeInSec) + "/sec");
		}
	}

	public static PrintWriter createWriter(FSDataOutputStream out) {
		PrintWriter writer = null;

		writer = new PrintWriter(new OutputStreamWriter(out));

		return writer;
	}

	public static String getKey() {
		int index = (int) (Math.random() * numOfKeys);
		return keys.get(index);
	}

	public static void writeTx(String key) {
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		DecimalFormat myFormatter = new DecimalFormat("###.##");

		long offset = (long) (1000 * 3600 * Math.random()) * 24 * 365 * 5;
		long currTime = System.currentTimeMillis();
		String txDate = df.format(new Date(currTime - offset));
		float amount = (float) (99.99 * Math.random());
		if (key.contains("PAYMENT"))
			amount = -amount;
		writer.println(txDate + "\t" + key + "\t" + myFormatter.format(amount));
	}

	public static void addKeys(String line) {
		StringTokenizer st = new StringTokenizer(line, "\t");
		String txDate = st.nextToken();
		String description = st.nextToken();
		String amount = st.nextToken();
		if (!keys.contains(description)) {
			System.out.println("added key: " + description);
			keys.add(description);
		}
	}

}
