import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SpendingPatternMapper1 extends
		Mapper<Text, Text, Text, FloatWritable> {

	@Override
	public void map(Text key, Text value, Context context) throws IOException,
			InterruptedException {
		if (!key.toString().contains("PAYMENT")) {
			float amount = Float.parseFloat(value.toString());
			context.write(key, new FloatWritable(amount));
		} 
	}
}
