import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

public class SpendingPatternMapper1c extends MapReduceBase implements Mapper<Text, FloatWritable, Text, FloatWritable> {

	@Override
	public void map(Text key, FloatWritable value, OutputCollector <Text, FloatWritable> output, Reporter reporter) throws IOException{

		if (!key.toString().contains("PAYMENT")) {
			float amount = Float.parseFloat(value.toString());
			output.collect (key, new FloatWritable(amount));
		} 
	}
}
