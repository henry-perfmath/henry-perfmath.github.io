import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.StringTokenizer;

import java.io.File;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.Path;

public class HelloHDFS {
	
public static final String theFileName = "hello.txt";
public static final String message ="Hello, HDFS!\n";
	public static void main(String[] args) throws IOException {
		Configuration conf = new Configuration ();
		FileSystem fs = FileSystem.get (conf);
		
		Path fileNamePath = new Path (theFileName);
		
		try {
			if (fs.exists (fileNamePath)) {
				fs.delete (fileNamePath);
			}
			FSDataOutputStream out = fs.create (fileNamePath);
			out.writeUTF (message);
			out.close ();
			
			FSDataInputStream in = fs.open (fileNamePath);
			String messageIn= in.readUTF ();
			System.out.print(messageIn);
			in.close ();
			

		} catch (IOException ioe) {
			System.err.println ("IOException during operation: " + ioe.toString ());
			System.exit(1);
		}
	}
}