import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapreduce.lib.chain.ChainMapper;
import org.apache.hadoop.mapreduce.lib.chain.ChainReducer;

import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.hadoop.conf.*;

public class SpendingPattern1i {

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();

		String remainingArgs[] = new GenericOptionsParser(conf, args)
				.getRemainingArgs();
		Job job = Job.getInstance();
		if (args.length != 2) {
			System.err.println("Usage: program <input> <output>");
			System.exit(-1);
		}
		JobConf jobConf = new JobConf(conf);
		jobConf.setJarByClass(SpendingPattern1h.class);
		FileInputFormat.addInputPath(jobConf, new Path(args[0]));
		FileOutputFormat.setOutputPath(jobConf, new Path(args[1]));

		job.setJobName("Spending Pattern ChainMapper");
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		Configuration map0Conf = new Configuration(false);
		ChainMapper.addMapper(job, SpendingPatternMapper1b.class,
				LongWritable.class, Text.class, Text.class,
				FloatWritable.class, map0Conf);

		Configuration map1Conf = new Configuration(false);
		ChainMapper.addMapper(job, SpendingPatternMapper1c.class, Text.class,
				FloatWritable.class, Text.class, FloatWritable.class, map1Conf);
		Configuration reduceConf = new Configuration(false);
		ChainReducer.setReducer(job, SpendingPatternReducer1a.class,
				Text.class, FloatWritable.class, Text.class,
				FloatWritable.class, reduceConf);
		job.setReducerClass (SpendingPatternReducer1a.class);
		JobClient.runJob(jobConf);
	}

}
