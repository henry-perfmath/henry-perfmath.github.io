import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SpendingPatternMapper1g extends Mapper<LongWritable, Text, Text, Text> {

@Override
public void map(LongWritable key, Text value, Context context)
    throws IOException, InterruptedException {
  
  String line = value.toString();
  if (!line.contains ("PAYMENT")) {
  	StringTokenizer st = new StringTokenizer (line, "\t");
  	String tranxDate = st.nextToken();
  	String description = st.nextToken();
	String amount = st.nextToken ();
	context.write(new Text(description), new Text (amount));
  }
}

}
