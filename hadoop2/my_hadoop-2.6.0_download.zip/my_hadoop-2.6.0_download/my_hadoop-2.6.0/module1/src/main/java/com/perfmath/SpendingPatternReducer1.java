import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class SpendingPatternReducer1 extends
		Reducer<Text, FloatWritable, BytesWritable, BytesWritable> {

	@Override
	public void reduce(Text key, Iterable<FloatWritable> values,
			Context context) throws IOException, InterruptedException {

		float maxValue = Float.MIN_VALUE;
		for (FloatWritable value : values) {
			maxValue = Math.max(maxValue, value.get());
		}
		byte[] newKey = key.toString().getBytes();
		byte[] newMaxValue = Float.toString(maxValue).getBytes();
		context.write(new BytesWritable(newKey), new BytesWritable(newMaxValue));
	}
}
